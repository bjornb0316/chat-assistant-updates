// Adapter: OperatorPanel NL — zie docs/02-ADAPTER-CONTRACT.md
//
// Server-gerenderd (Bootstrap), geen SPA: de pagina herlaadt na elke verzending.
// De content_scripts-injectie van Chrome gebeurt automatisch per paginalaad,
// dus daar hoeft niets extra's voor te gebeuren — de adapter start gewoon
// opnieuw op de nieuwe pagina.
//
// Selectors geverifieerd tegen de live site op 17-08-2026, ingelogd op
// operatorpanelnl.com/messages. Wat daar bleek en waar de logica hieronder op
// steunt:
//
//   * De geschiedenis is een <dl> waarin dt de kop is ("Rood_9999 op
//     17-08-2026 om 11:13") en de dd erna de berichttekst. Een dt is dus GEEN
//     bericht — de vorige versie telde ze mee en schoof daardoor alle rollen op.
//   * De geschiedenis staat NIEUWSTE BOVENAAN. Het contract wil oud -> nieuw,
//     dus draaien we hem om. Zonder dat leest de trigger het oudste bericht als
//     het nieuwste en vuurt hij nooit op wat er net binnenkwam.
//   * De rol staat nergens als class. De enige betrouwbare bron is de naam in
//     de dt, vergeleken met de gebruikersnaam in de panelkop.
//   * Twee profielpanelen, herkenbaar aan hun kop: "Operator: <naam> (ID: n)"
//     is het profiel waarachter we zitten, "Bezoeker: <naam> (ID: n)" is de
//     klant. Let op de naamgeving: "Operator" is hier het NEPPROFIEL, niet het
//     ingelogde account.
//   * Het ingelogde account staat rechtsboven in de navbar, als los tekstknoop-
//     je achter het poppetje-icoon: "Anouk (3483 )". Dat is de operatorName
//     waar de accountherkenning aan hangt.

window.ChatAssistant = window.ChatAssistant || {};
ChatAssistant._factories = window.ChatAssistant._factories || [];

(function () {
  const { setNativeValue, qs, qsa, text, safe, emptyProfile } = ChatAssistant.dom;

  const SEL = {
    input: '#message_sender textarea.form-control',
    messageIdField: '#message_sender input[name="message_id"]',
    sendButton: '#message_sender input[type="submit"], #message_sender button[type="submit"]',
    charCounter: '#message_sender .charactercount',
    history: 'dl.chat_history',
    // Profielpanelen: één blok per veld, dt = label, dd = waarde.
    panel: 'div.panel',
    panelHeading: '.panel-heading',
    panelField: 'div.panel-body div.row div.col-lg-6 dl',
    // Navbar rechtsboven; de naam is het tekstknoopje achter dit icoon.
    accountLink: 'ul.nav.navbar-nav.navbar-right a',
    // Logboek. Twee formulieren op de pagina; de zichtbare hoort bij de klant.
    logbookForm: 'form.log_book_post',
    logbookCategory: 'select[name="log_book_category_id"]',
    logbookText: 'textarea[name="log_book_text"]',
    logbookSubmit: 'button[type="submit"]',
    logbookEntry: '.log-book-text',
    profileColumnWide: 'div.col-lg-3',
    accountIcon: 'span.glyphicon-user',
    // De gekleurde balk boven de wachtrij. Gemeten 19-08-2026:
    //   <div class="alert" style="background-color:yellow;color:black">
    //     <span><i class="glyphicon glyphicon-envelope"></i>
    //     24 berichten beschikbaar</span> ...
    // De kleur staat als inline stijl, dus die is rechtstreeks uit te lezen.
    // Zie src/stage.js voor wat geel, rood en blauw betekenen.
    stageBar: 'div.alert[style*="background-color"]',
  };

  // Panelkop, bijv. "Bezoeker: xackery2720 (ID: 47700480) $" -> "xackery2720".
  const HEADING_RE = /^(Operator|Bezoeker):\s*(.+?)\s*\(ID:\s*(\d+)\s*\)/;
  // dt-kop, bijv. "Rood_9999 op 17-08-2026 om 11:13" -> naam, datum, tijd.
  const HEADER_RE = /^(.+?)\s+op\s+(\d{2})-(\d{2})-(\d{4})\s+om\s+(\d{2}:\d{2})/;
  // Navbar, bijv. "Anouk (3483 )" -> naam, id.
  const ACCOUNT_RE = /^(.+?)\s*\(\s*(\d+)\s*\)\s*$/;
  // De tekenteller is bij het laden nog een leeg sjabloon ("Ontbrekend:lengte
  // karakters") en krijgt pas een getal zodra er een input-gebeurtenis is
  // geweest. Zolang dat zo is gebruiken we deze gemeten waarde; heeft de teller
  // wél een getal, dan wint die altijd.
  // Gemeten 18-08-2026 op een live gesprek: 1+170, 10+161, 30+141, 120+51 —
  // steeds 171.
  const MIN_CHARS_FALLBACK = 171;

  // Eigen huisregel bovenop wat de site eist: 200 tot 500 tekens.
  // De 200 is strenger dan de 171 van de site; de 500 is een bovengrens die de
  // site zelf niet kent. Eist de site ooit méér dan 200, dan wint de site —
  // vandaar de Math.max hieronder in plaats van een vaste waarde.
  const POLICY_MIN_CHARS = 200;
  const POLICY_MAX_CHARS = 500;

  // Losse regel met land, regio, plaats: "Nederland, Noord-Holland, AMSTERDAM".
  const PLACE_RE = /^([^,]+),\s*([^,]+),\s*([^,]+)$/;

  function createOperatorPanelAdapter() {
    // ---- panelen -----------------------------------------------------------

    // Geeft { username, id, panel } van het paneel met deze kop, of null.
    function findPanel(kind) {
      const panels = qsa(document, SEL.panel);
      for (const panel of panels) {
        const heading = qs(panel, SEL.panelHeading);
        if (!heading) continue;
        const m = HEADING_RE.exec(text(heading));
        if (m && m[1] === kind) return { username: m[2], id: m[3], panel };
      }
      return null;
    }

    // Alle "label -> waarde"-paren uit een profielpaneel.
    function panelFields(panel) {
      const fields = {};
      for (const dl of qsa(panel, SEL.panelField)) {
        const label = text(dl.children[0]);
        const value = text(dl.children[1]);
        if (label) fields[label] = value || null;
      }
      return fields;
    }

    // Een leeg veld op deze site is een lege string; het contract wil null.
    function value(fields, label) {
      const v = fields[label];
      return v ? v : null;
    }

    function number(fields, label) {
      const v = value(fields, label);
      if (!v) return null;
      const m = /(\d+)/.exec(v);
      return m ? Number(m[1]) : null;
    }

    function buildProfile(found) {
      const profile = emptyProfile();
      if (!found) return profile;

      const fields = panelFields(found.panel);
      profile.nickname = value(fields, 'Gebruiker') || found.username || null;
      profile.name = value(fields, 'Naam');
      profile.gender = value(fields, 'Geslacht');
      profile.hairColour = value(fields, 'Haarkleur');
      profile.eyeColour = value(fields, 'Kleur ogen');
      profile.bodyType = value(fields, 'Lichaamsbouw');
      profile.height = number(fields, 'Lengte (cm)');
      profile.heightLabel = value(fields, 'Lengte (cm)');
      profile.weight = number(fields, 'Gewicht (kg)');
      profile.smoker = value(fields, 'Roker');
      profile.maritalStatus = value(fields, 'Burgerlijke staat');
      profile.sexualPreference = value(fields, 'Op zoek naar');
      profile.age = number(fields, 'Leeftijd');

      // "30 (03-03-1996)" — de geboortedatum staat alleen bij het nepprofiel.
      const ageRaw = value(fields, 'Leeftijd');
      const birth = ageRaw && /\((\d{2}-\d{2}-\d{4})\)/.exec(ageRaw);
      profile.birthdate = birth ? birth[1] : null;

      // Plaats en omschrijving staan als losse regels onder de veldenlijst,
      // niet in een dl. Daarom via de regels van het paneel.
      const lines = (found.panel.innerText || '')
        .split('\n')
        .map((line) => line.trim())
        .filter(Boolean);

      for (const line of lines) {
        const place = PLACE_RE.exec(line);
        if (place) {
          profile.country = place[1].trim();
          profile.region = place[2].trim();
          profile.location = place[3].trim();
          break;
        }
      }

      const omschrijving = lines.indexOf('Omschrijving');
      if (omschrijving !== -1 && omschrijving + 1 < lines.length) {
        profile.aboutMe = lines.slice(omschrijving + 1).join(' ') || null;
      }

      // Vangnet uit het contract: alles wat we niet apart uitlezen hoort hier
      // alsnog in te staan.
      profile.raw = text(found.panel);
      return profile;
    }

    // ---- adapter -----------------------------------------------------------

    const adapter = {
      id: 'operatorpanel-nl',
      label: 'OperatorPanel NL',
      matches: ['*://operatorpanelnl.com/*', '*://*.operatorpanelnl.com/*'],

      allowsDraftInsert: true,

      // Op dit platform zijn emoji verboden. Platformregel, dus hier en niet
      // in de accountinstellingen — zo kan geen vinkje hem omzetten.
      allowsEmoji: false,

      // Hier hangt het van de gekleurde balk af, en dat is de enige adapter
      // waarvoor dat geldt. Deze vlag betekent daarom "het platform staat het
      // in principe toe"; of het nú mag beslist src/stage.js aan de hand van
      // de kleur.
      //
      // Op 19-08-2026 opgegeven door het bureau: bij een blauwe balk heeft de
      // klant geen credits meer, en dan is datinggericht schrijven juist de
      // bedoeling — nummer, mailadres, een voorstel voor het weekend. De site
      // maskeert die gegevens zelf met sterretjes.
      //
      // Wordt de balk niet gevonden, dan geeft stage.js de strengste stand
      // terug en gedraagt dit zich precies als de `false` die hier stond.
      allowsContactOrDates: true,

      // Aangezet op 18-08-2026, nadat bevestigd was dat automatisch verzenden
      // hier is toegestaan. Anders dan bij ChatHomeBase valt er op deze site
      // niets te ontwijken: de extensie schrijft gewoon in het veld en drukt op
      // dezelfde knop die Ctrl+Enter ook indrukt.
      allowsAutoSend: true,

      isChatPage() {
        return safe(() => !!qs(document, SEL.input), false);
      },

      isReady() {
        return safe(() => !!qs(document, SEL.input) && !!qs(document, SEL.history), false);
      },

      getConversationId() {
        return safe(() => {
          const field = qs(document, SEL.messageIdField);
          if (field && field.value) return String(field.value);
          const m = location.pathname.match(/(\d{4,})/);
          return m ? m[1] : null;
        }, null);
      },

      getMessages() {
        return safe(() => {
          const historyEl = qs(document, SEL.history);
          if (!historyEl) return [];

          // Zonder de gebruikersnaam van het nepprofiel is de rol niet vast te
          // stellen. Een verkeerde rol is erger dan geen bericht: de trigger
          // zou dan op ons eigen bericht vuren. Dus liever niets teruggeven.
          const persona = findPanel('Operator');
          if (!persona || !persona.username) return [];
          const customer = findPanel('Bezoeker');

          const messages = [];
          for (const dt of qsa(historyEl, 'dt')) {
            const dd = dt.nextElementSibling;
            if (!dd || dd.tagName !== 'DD') continue;

            const header = HEADER_RE.exec(text(dt));
            if (!header) continue;

            const sender = header[1].trim();
            // Alleen twee deelnemers in dit gesprek: is het het nepprofiel
            // niet, dan is het de klant.
            const isOperator = sender === persona.username;
            if (!isOperator && customer && customer.username && sender !== customer.username) {
              continue; // onbekende afzender — niet gokken
            }

            const body = text(dd);
            const hasImage = !!qs(dd, 'img');
            if (!body && !hasImage) continue;

            messages.push({
              role: isOperator ? 'operator' : 'customer',
              text: body,
              // "17-08-2026 om 11:13" -> 2026-08-17T11:13. De site geeft geen
              // tijdzone, dus die laten we eraf.
              timestamp: `${header[4]}-${header[3]}-${header[2]}T${header[5]}`,
              hasImage,
            });
          }

          // De site zet het nieuwste bericht bovenaan; het contract wil
          // oud -> nieuw. Dit is geen sortering op inhoud — het is dezelfde
          // DOM-volgorde, omgedraaid.
          return messages.reverse();
        }, []);
      },

      getCustomer() {
        return safe(() => buildProfile(findPanel('Bezoeker')), emptyProfile());
      },

      getPersona() {
        return safe(() => buildProfile(findPanel('Operator')), emptyProfile());
      },

      getAttachments() {
        // v2-scope — v1 stuurt altijd attachmentsLoaded: false.
        return safe(() => [], []);
      },

      // Het ingelogde account, niet het nepprofiel. Staat rechtsboven als los
      // tekstknoopje achter het poppetje-icoon, in de vorm "Anouk (3483 )".
      getOperatorName() {
        return safe(() => {
          const link = qs(document, SEL.accountLink);
          if (!link) return null;
          const icon = qs(link, SEL.accountIcon);
          if (!icon) return null;

          let node = icon.nextSibling;
          while (node) {
            if (node.nodeType === Node.TEXT_NODE) {
              const raw = (node.textContent || '').replace(/\s+/g, ' ').trim();
              const m = ACCOUNT_RE.exec(raw);
              if (m) return { name: m[1].trim(), id: m[2] };
              if (raw) return { name: raw, id: null };
            }
            node = node.nextSibling;
          }
          return null;
        }, null);
      },

      getContext() {
        return safe(() => {
          const account = adapter.getOperatorName();
          const persona = findPanel('Operator');
          const customer = findPanel('Bezoeker');
          const counter = qs(document, SEL.charCounter);
          const counterText = text(counter);
          // LET OP: de teller meldt hoeveel tekens er nog ONTBREKEN ("Er
          // ontbreken 170 tekens."), niet wat de ondergrens is. De grens is dus
          // wat er nu staat plus wat er ontbreekt. Dit las de adapter eerder
          // fout: hij nam het tekort voor de grens.
          const missing = /(\d+)/.exec(counterText);
          const inputEl = adapter.getInputElement();
          const typed = inputEl ? String(inputEl.value || '').length : 0;

          // Alleen de kleur uitlezen; wat hij betekent bepaalt src/stage.js.
          // De adapter blijft daarmee een vertaler zonder eigen mening, zoals
          // de rest van het contract.
          //
          // Twee bronnen, in deze volgorde: de inline stijl (wat de site nu
          // doet) en anders de berekende stijl (voor als de opmaak ooit naar
          // een stylesheet verhuist). Vinden we niets, dan null — en dan valt
          // het beleid terug op de strengste stand.
          let stageColour = null;
          const bar = qs(document, SEL.stageBar);
          if (bar) {
            stageColour =
              (bar.style && bar.style.backgroundColor) ||
              (window.getComputedStyle
                ? window.getComputedStyle(bar).backgroundColor
                : null) ||
              null;
          }

          return {
            conversationId: adapter.getConversationId(),
            platform: 'operatorpanel-nl',
            attachmentsLoaded: false,
            operatorName: account ? account.name : null,
            stageColour,
            extra: {
              operatorId: account ? account.id : null,
              personaUsername: persona ? persona.username : null,
              personaId: persona ? persona.id : null,
              customerUsername: customer ? customer.username : null,
              customerId: customer ? customer.id : null,
              minChars: Math.max(
                POLICY_MIN_CHARS,
                missing ? typed + Number(missing[1]) : MIN_CHARS_FALLBACK
              ),
              maxChars: POLICY_MAX_CHARS,
              // Wat de site zelf minimaal eist, los van onze huisregel — handig
              // bij het uitzoeken waarom een bericht geweigerd wordt.
              siteMinChars: missing ? typed + Number(missing[1]) : MIN_CHARS_FALLBACK,
              charCounterText: counterText || null,
            },
          };
        }, null);
      },

      // ---- logboek ---------------------------------------------------
      //
      // Twee identieke formulieren op de pagina: een verborgen voor het
      // nepprofiel en een zichtbare voor de klant. Filteren op zichtbaarheid
      // in plaats van op volgorde, want de vololgorde in de DOM is niet
      // gegarandeerd.
      //
      // Het profiel van de persona heeft zijn eigen dossier met dezelfde
      // categorieën. Dat is om twee redenen nodig: het bureau houdt het bij
      // zoals ze het klantdossier bijhouden, én het is de enige plek waar
      // staat wat er eerder over deze persona is verzonnen. Zonder dat schrijft
      // het model in elk gesprek een ander beroep en een andere woonsituatie.

      _logbookForm(target) {
        const forms = qsa(document, SEL.logbookForm);
        return target === 'persona'
          ? forms.find((f) => !f.offsetParent) || null
          : forms.find((f) => f.offsetParent) || null;
      },

      getLogbook(target) {
        return safe(() => {
          const form = adapter._logbookForm(target);
          if (!form) return null;

          const select = qs(form, SEL.logbookCategory);
          const categories = select
            ? Array.from(select.options)
                .filter((o) => o.value)
                .map((o) => ({ id: String(o.value), label: text(o) }))
            : [];

          // Wat er al gelogd is staat in de accordeon onder het formulier,
          // gegroepeerd per categorie. Nodig om niet dubbel te loggen.
          const column = form.closest(SEL.profileColumnWide) || document;
          const existing = qsa(column, SEL.logbookEntry)
            .map((el) => ({ text: text(el) }))
            .filter((e) => e.text);

          return { categories, existing };
        }, null);
      },

      setLogbookEntry(entry) {
        return safe(() => {
          if (!entry || !entry.categoryId || !entry.text) return false;
          const form = adapter._logbookForm(entry.target);
          if (!form) return false;

          const select = qs(form, SEL.logbookCategory);
          const field = qs(form, SEL.logbookText);
          if (!select || !field) return false;

          const option = Array.from(select.options).find(
            (o) => String(o.value) === String(entry.categoryId)
          );
          if (!option) return false;

          select.value = option.value;
          select.dispatchEvent(new Event('change', { bubbles: true }));
          return setNativeValue(field, entry.text);
        }, false);
      },

      // Alleen teruggeven, nooit zelf indrukken — zelfde regel als bij
      // getSendButton. content.js drukt hem in.
      getLogbookSubmitButton(target) {
        return safe(() => {
          const form = adapter._logbookForm(target);
          return form ? qs(form, SEL.logbookSubmit) : null;
        }, null);
      },

      getInputElement() {
        return safe(() => qs(document, SEL.input), null);
      },

      // Alleen teruggeven, nooit zelf indrukken — zie contractregel in
      // docs/02-ADAPTER-CONTRACT.md. content.js drukt hem in, en alleen na
      // een echte toetsaanslag van de gebruiker.
      getSendButton() {
        return safe(() => qs(document, SEL.sendButton), null);
      },

      setDraft(replyText) {
        return safe(() => setNativeValue(adapter.getInputElement(), replyText), false);
      },

      getStatusAnchor() {
        return safe(() => document.body, null);
      },
    };
    return adapter;
  }

  ChatAssistant._factories.push(createOperatorPanelAdapter);
})();
