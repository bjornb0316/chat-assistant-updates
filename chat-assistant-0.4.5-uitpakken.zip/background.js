// Service worker. Praat rechtstreeks met de Anthropic API — geen backend.
// Zie docs/03-PROJECT.md "Geen backend" voor de reden.

importScripts(
  './src/config/defaults.js',
  './src/config/schema.js',
  './src/services/configService.js',
  './src/blocklist.js',
  './src/style.js',
  './src/autosend.js',
  './src/logbook.js',
  './src/memory.js'
);

const API_URL = 'https://api.anthropic.com/v1/messages';
const API_VERSION = '2023-06-01';
const DEFAULT_MODEL = 'claude-sonnet-5';

// WELKE MODELLEN DEZE EXTENSIE MAG GEBRUIKEN.
//
// Niet alleen een lijstje voor de popup: hier wordt hij ook afgedwongen. Op
// 19-08-2026 is Claude Opus 5 uit de keuze gehaald omdat hij vijf keer zo duur
// is als Haiku en de winst dat niet waard bleek.
//
// Alleen de optie weghalen is niet genoeg. De keuze staat in chrome.storage,
// en die verdwijnt niet doordat het uitklapmenu hem niet meer toont. Wie op
// Opus stond, bleef dus op Opus draaien terwijl de popup Sonnet liet zien —
// een verschil dat je pas op de rekening ziet. Vandaar de controle hieronder.
const ALLOWED_MODELS = ['claude-sonnet-5', 'claude-haiku-4-5'];

// Eerste poging plus twee herkansingen. Daarna gaat het laatste voorstel toch
// naar het invoerveld, met een waarschuwing — liever iets om aan te passen dan
// een leeg veld en eindeloos doorproberen op jouw kosten.
const MAX_ATTEMPTS = 3;

// Een bericht van hooguit 500 tekens is rond de 150 tokens. Komt het logboek
// erbij in dezelfde call, dan is er ruimte nodig voor acht korte feiten in
// JSON — vandaar het ruimere budget zodra dat gevraagd wordt. Te krap
// betekent een afgekapt antwoord halverwege een zin.
const REPLY_MAX_TOKENS = 1024;
const REPLY_WITH_LOGBOOK_MAX_TOKENS = 1536;

// Onder deze grens beschouwen we het eigen dossier van de persona als leeg en
// laten we het aanvullen. Erboven staat er genoeg om consistent mee te
// blijven, en is aanvullen alleen maar ruis in een derde blok dat een klein
// model toch al moet zien vol te houden.
const PERSONA_LOGBOOK_MIN_ENTRIES = 4;

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message && message.type === 'generate-reply') {
    handleGenerate(message.payload)
      .then((result) => sendResponse(result))
      .catch((err) => sendResponse({ error: err.message || String(err) }));
    return true; // async — houd het kanaal open
  }

  // Config geforceerd opnieuw ophalen — voor de knop in de popup.
  if (message && message.type === 'refresh-config') {
    ChatAssistant.configService
      .refresh({ force: true })
      .then((r) => sendResponse(r))
      .catch((err) => sendResponse({ status: 'error', error: err.message || String(err) }));
    return true;
  }

  // Wat er nu geldt, zonder het net op te gaan. content.js gebruikt dit voor
  // de afteller, de schakelaars en de onderhoudsmelding.
  if (message && message.type === 'get-config') {
    ChatAssistant.configService
      .current()
      .then((config) => sendResponse({ config }))
      .catch(() => sendResponse({ config: ChatAssistant.configDefaults }));
    return true;
  }

  // Een verstuurd bericht onthouden voor volgende keren. Zie src/memory.js:
  // een klein model imiteert voorbeelden beter dan het instructies volgt.
  if (message && message.type === 'remember-sent') {
    handleRememberSent(message.payload)
      .then((result) => sendResponse(result || { ok: true }))
      .catch((err) => sendResponse({ error: err.message || String(err) }));
    return true;
  }

});

// ---- geheugen ------------------------------------------------------------

const MEMORY_KEY = 'styleMemory';

async function getMemory() {
  const stored = await chrome.storage.local.get([MEMORY_KEY]);
  return stored[MEMORY_KEY] || ChatAssistant.memory.emptyStore();
}

async function handleRememberSent(payload) {
  const p = payload || {};
  if (!p.operatorName || !p.text) return { ok: false };

  const store = await getMemory();
  const nieuw = ChatAssistant.memory.remember(store, {
    accountKey: p.operatorName,
    text: p.text,
    // Alleen wat in één poging door alle controles kwam mag voorbeeld
    // worden. Een bericht dat herkansingen nodig had bevat per definitie
    // iets wat we niet willen aanleren.
    cleanFirstTry: p.attempts === 1,
  });

  await chrome.storage.local.set({ [MEMORY_KEY]: nieuw });
  console.log(
    '[ChatAssistant] geheugen:',
    JSON.stringify(ChatAssistant.memory.summary(nieuw))
  );
  return { ok: true };
}

// De instellingen die lokaal blijven, samengevoegd met wat de backend stuurt.
//
// DE VERDELING: WAT LOKAAL BLIJFT EN WAT CENTRAAL KAN.
//
// Lokaal: de API-sleutel (die gaat nooit ergens heen), de operatornamen van
// deze installatie, en de modus per account. Dat is van deze machine.
//
// Centraal: het model, de grenzen, de woordenlijsten, de schakelaars. Dat is
// beleid en hoort bij te kunnen zonder dat er iemand met een USB-stick langs
// hoeft.
//
// De lokale keuze wint van de centrale waar dat logisch is — kiest de operator
// in de popup een model, dan gebeurt dat. De centrale allowedModels blijft
// daarbovenop het plafond.
async function getSettings() {
  const stored = await chrome.storage.local.get([
    'apiKey',
    'model',
    'accounts',
    'globalBlocklist',
  ]);

  const config = await ChatAssistant.configService.current();
  const toegestaan =
    (config.ai && config.ai.allowedModels) || ChatAssistant.configDefaults.ai.allowedModels;
  const standaard = (config.ai && config.ai.model) || DEFAULT_MODEL;

  // Een opgeslagen model dat niet meer mag, mag ook niet meer gebruikt worden.
  // Stil terugvallen zou betekenen dat je Opus-tarief blijft betalen zolang je
  // de popup niet opent en opslaat.
  let model = stored.model || standaard;
  if (toegestaan.indexOf(model) === -1) {
    console.warn(
      `[ChatAssistant] model "${model}" wordt niet meer gebruikt — teruggevallen op ` +
        `${standaard}. Sla je instellingen op om dit definitief te maken.`
    );
    model = standaard;
  }

  // De algemene verboden woorden uit de popup plus wat de backend voor alle
  // klanten toevoegt.
  const extra = (config.style && config.style.extraBlocklist) || [];

  return {
    apiKey: stored.apiKey || '',
    model,
    accounts: stored.accounts || {},
    globalBlocklist: ChatAssistant.blocklist.merge(stored.globalBlocklist || '', extra),
    config,
  };
}

function findAccountConfig(accounts, operatorName) {
  if (!operatorName) return null;
  return accounts[operatorName] || null;
}

// Eén object in plaats van een rij losse parameters. Die rij groeide van drie
// naar acht, en bij acht positionele booleans is een verwisseling geen risico
// meer maar een kwestie van tijd — en een verwisselde emoji-vlag levert een
// bericht op dat het platform weigert.
function buildSystemPrompt(opts) {
  const {
    account,
    blockedItems,
    limits,
    allowsEmoji,
    allowsContactDetails,
    allowsSexInitiative,
    masksContactDetails,
    customerNames,
    isNewConversation,
    lastGreeting,
    examples,
    recentOpenings,
    logbookCategories,
    personaLogbookCategories,
    logbookPriority,
  } = opts || {};

  const lines = [];
  lines.push('Je beantwoordt chatberichten namens een persona op een datingplatform.');
  lines.push('Schrijf kort, natuurlijk, alsof een echt mens dit typt — geen AI-toon, geen opsommingen.');

  if (account) {
    if (account.language) lines.push(`Taal: ${account.language}.`);
    if (account.styleNotes) lines.push(`Stijl: ${account.styleNotes}`);
    // Een platformverbod wint van de voorkeuren per account: dan heeft het
    // geen zin het model een lijstje toegestane emoji voor te houden.
    if (allowsEmoji === false) {
      // niets — de harde regel staat hieronder
    } else if (account.emojiAllow && account.emojiAllow.length) {
      lines.push(`Toegestane emoji: ${account.emojiAllow.join(' ')}`);
    }
    if (account.emojiBlock && account.emojiBlock.length) {
      lines.push(`Gebruik nooit deze emoji: ${account.emojiBlock.join(' ')}`);
    }
    if (account.abbreviations && account.abbreviations.length) {
      lines.push(`Gebruikelijke afkortingen die passen bij deze persona: ${account.abbreviations.join(', ')}`);
    }
  } else {
    lines.push('Geen accountinstellingen gevonden voor deze operatornaam — schrijf neutraal.');
  }

  // ER KOMT NOOIT EEN ECHTE AFSPRAAK. Dat geldt op elke balk en in elk
  // gesprek — ook waar datinggericht schrijven wel mag, is dat een spel met
  // gemaskeerde gegevens en geen ontmoeting die daadwerkelijk plaatsvindt.
  lines.push(
    'Er komt nooit een echte ontmoeting tot stand. Begin er zelf nooit over, ' +
      'en zeg nooit een tijd, een plaats of een dag toe waarop je er echt zou ' +
      'zijn. Wil de klant concreet afspreken, verzin dan een reden waarom het ' +
      'nu niet gaat — druk op het werk, de kinderen, een dienst — en draai er ' +
      'speels omheen. Niet toezeggen, maar ook niet hard afwijzen.'
  );

  if (allowsContactDetails === false) {
    lines.push(
      'Geef ook nooit contactgegevens. Geen adres, geen langskomen, geen ' +
        'telefoonnummer, geen WhatsApp, geen social media, geen mailadres.'
    );
    lines.push(
      'Plaag, hou de spanning erin en breng het gesprek terug naar de ' +
        'fantasie. Fantaseren en flirten mag volop.'
    );
  } else {
    // De blauwe balk: de klant heeft geen credits meer. Dit is het enige
    // moment waarop het bureau juist wél datinggericht wil schrijven.
    lines.push(
      'Bij deze klant mag je contactgegevens aanbieden — een nummer of een ' +
        'mailadres. Dat is het enige wat hier extra mag.'
    );
    lines.push(
      'Stel nog steeds GEEN concrete afspraak voor. Geen "zullen we dit ' +
        'weekend", geen dag, geen tijd, geen plaats. Contactgegevens ' +
        'uitwisselen en een ontmoeting afspreken zijn twee verschillende ' +
        'dingen; alleen het eerste mag.'
    );
    if (masksContactDetails) {
      lines.push(
        'Schrijf een telefoonnummer of mailadres nooit echt uit. Zet er zes ' +
          'sterretjes voor in de plaats: ******. De site verwacht die vorm.'
      );
    }
  }

  // Bij een nieuwe klant (gele balk) begint het bureau nooit zelf over seks.
  // Meegaan als de klant erover begint mag wel — vandaar dat dit over het
  // initiatief gaat en niet over het onderwerp.
  if (allowsSexInitiative === false) {
    lines.push(
      'Begin niet zelf over seks. Heeft de klant er zelf niet over geschreven, ' +
        'houd het dan bij kennismaken, flirten en nieuwsgierigheid — geen ' +
        'expliciete beschrijvingen, geen vragen over wat hij in bed wil. ' +
        'Begint de klant er zelf over, dan mag je er volop in meegaan.'
    );
  }

  if (allowsEmoji === false) {
    lines.push(
      'Gebruik geen enkele emoji. Geen smileys, geen hartjes, geen symbolen — ' +
        'dit platform staat ze niet toe. Druk gevoel uit met woorden.'
    );
  }

  // Dezelfde twee lagen als bij de verboden woorden: vooraf meegeven scheelt
  // herkansingen, achteraf controleren is de garantie. Dit ontbrak, waardoor
  // het model werd afgerekend op een lengte-eis die het nooit had gekregen.
  if (limits && (typeof limits.minChars === 'number' || typeof limits.maxChars === 'number')) {
    const min = limits.minChars;
    const max = limits.maxChars;
    let rule;
    if (typeof min === 'number' && typeof max === 'number') {
      rule = `tussen de ${min} en ${max} tekens`;
    } else if (typeof min === 'number') {
      rule = `minstens ${min} tekens`;
    } else {
      rule = `hoogstens ${max} tekens`;
    }
    lines.push(
      `Lengte: je antwoord moet ${rule} lang zijn. Dit is een harde eis van het ` +
        'platform — een bericht dat er niet aan voldoet wordt geweigerd. Tel de ' +
        'tekens en blijf ruim binnen de grens.'
    );
  }

  // De lijst gaat vooraf mee in de prompt én wordt achteraf gecontroleerd.
  // Vooraf scheelt herkansingen; achteraf is de garantie.
  if (blockedItems && blockedItems.length) {
    lines.push(
      'Deze woorden en zinnen mag je onder geen beding gebruiken, ook niet in een ' +
        'andere vorm of vervoeging:\n' +
        blockedItems.map((item) => `- ${item}`).join('\n')
    );
    lines.push('Kun je iets niet zeggen zonder een verboden woord, formuleer het dan anders.');
  }

  lines.push(
    'Schrijf grammaticaal correct Nederlands. De site rekent fouten aan en de ' +
      'operator wordt erop aangesproken. Concreet:'
  );
  lines.push(
    '- Geen stopwoordjes of kreungeluiden: geen "xxx", "xx", "xoxo", "haha", ' +
      '"hihi", "lol", "hmmm", "mmm", "mama", "jaaahh", "mwahhh".'
  );
  lines.push(
    '- Rek geen woorden op. Niet "jaaahh", niet "neeee", niet "leukkk". Er ' +
      'bestaat geen Nederlands woord met drie dezelfde letters achter elkaar.'
  );
  lines.push(
    '- Nooit twee of meer punten achter elkaar, niet aan het eind van een zin ' +
      'en niet aan het begin van een bericht. Eén punt, of een vraagteken.'
  );
  lines.push(
    '- Elke zin begint met een hoofdletter en eindigt met een leesteken.'
  );

  // ---- huisregels van het bureau ------------------------------------------
  //
  // Deze staan bewust achteraan: wat onderaan de prompt staat weegt het
  // zwaarst, en dit zijn precies de regels waar een klein model op struikelde.
  // De code controleert ze alsnog (src/style.js), maar elke regel die hier
  // blijft plakken scheelt een herkansing van drie centen.

  if (customerNames && customerNames.length) {
    lines.push(
      `Noem de klant nooit bij zijn naam. Niet "${customerNames[0]}", en ook ` +
        'geen enkele andere naam of gebruikersnaam. Spreek hem aan met "jij", ' +
        'of met een koosnaampje dat bij de persona past. De site rekent een ' +
        'naam aan als fout.'
    );
  }

  lines.push(
    'Beloof nooit iets wat je niet kunt waarmaken. Je hebt een paar foto\'s en ' +
      'meer komen er niet: zeg dus nooit dat je er een gaat maken, dat er iets ' +
      'aankomt, of dat je later meer stuurt.'
  );

  lines.push(
    'Zeg nooit dat je "even gaat kijken", "in je agenda kijkt" of "je best ' +
      'doet". Dat is uitstel en geen antwoord. Heb je een reden nodig om iets ' +
      'af te houden, maak die dan concreet — het is druk op het werk, je hebt ' +
      'de kinderen — en breng het gesprek daarna terug naar de fantasie.'
  );

  // ---- begint dit gesprek, of loopt het al? --------------------------------
  //
  // Dit onderscheid moet hard zijn, want de twee gevallen vragen het tegen-
  // overgestelde. Zonder die scheiding kreeg het model bij élk bericht te
  // horen dat het zijn groet moest afwisselen — ook halverwege een lopend
  // gesprek. Een model dat over groeten nadenkt, produceert groeten. Vandaar
  // "hallo, hoe gaat het vandaag?" midden in een gesprek dat al een uur liep.
  if (isNewConversation) {
    // Een model dat alleen "wissel af" te horen krijgt, kiest steeds hetzelfde
    // woord — meestal "Goedemorgen". Het heeft de alternatieven nodig, niet de
    // opdracht.
    lines.push(
      'Kies je groet uit deze, en pak niet steeds dezelfde: "Hallo", "Hey", ' +
        '"Hey jij", "Hey kanjer", "Hey knappert", "Hey lieve man", "Hoi", ' +
        '"Dag jij". Of laat de groet helemaal weg en begin meteen met wat je ' +
        'te zeggen hebt — dat mag net zo goed en is vaak het beste.'
    );
    lines.push(
      '"Goedemorgen", "Goedemiddag" en "Goedenavond" mogen af en toe, maar ' +
        'niet standaard: ze vallen op als ze in elk bericht staan.'
    );

    if (lastGreeting) {
      lines.push(
        `Je vorige bericht begon met "${lastGreeting}". Gebruik die nu niet.`
      );
    }

    lines.push(
      'Dit is het begin van een gesprek met een nieuwe klant. Val niet terug ' +
        'op algemene openingszinnen zoals "laten we elkaar eerst beter leren ' +
        'kennen" of "dat maakt het juist spannend" — die staan in elk bericht ' +
        'en dat valt op. Stel in plaats daarvan een concrete vraag over iets ' +
        'uit zijn profiel of uit wat hij net schreef: zijn werk, zijn woon- ' +
        'plaats, iets uit zijn omschrijving. Laat merken dat je hem gelezen ' +
        'hebt.'
    );
  } else {
    lines.push(
      'DIT GESPREK LOOPT AL. Je valt niet binnen met een opening — je gaat ' +
        'verder waar het gebleven is. Dus geen "hallo", geen "hoe gaat het ' +
        'vandaag", geen kennismaking en geen vraag die je al eerder gesteld ' +
        'hebt. Lees terug wat er net gezegd is en reageer daar direct op: ' +
        'beantwoord zijn vraag, ga in op wat hij vertelde, of pak het ' +
        'onderwerp op waar jullie mee bezig waren.'
    );
  }

  // ---- eigen voorbeelden ---------------------------------------------------
  //
  // Dit is de sterkste hefboom voor een klein model. "Schrijf tussen de 200 en
  // 500 tekens, wissel je opening af, val niet terug op standaardzinnen" is
  // abstract; vijf echte berichten van deze persona laten alle drie die dingen
  // tegelijk zien zonder ze te benoemen.
  //
  // Het zijn berichten die eerder in één poging door alle controles kwamen en
  // ook echt verstuurd zijn — zie src/memory.js. Ze kosten geen extra
  // API-call: we bewaren wat er toch al langskwam.
  if (examples && examples.length) {
    lines.push('');
    lines.push(
      'Zo schrijft deze persona. Dit zijn eerdere berichten van jezelf die goed ' +
        'waren — neem de toon, de lengte en het ritme ervan over, maar nooit de ' +
        'inhoud of de zinnen zelf:'
    );
    examples.forEach((voorbeeld, i) => {
      lines.push('');
      lines.push(`Voorbeeld ${i + 1} (${voorbeeld.length} tekens):`);
      lines.push(voorbeeld);
    });
    lines.push('');
  }

  // De openingen die er de laatste tijd zijn geweest. Hiermee wordt afwisselen
  // concreet in plaats van een goed voornemen: het model ziet zwart-op-wit wat
  // het al gebruikt heeft.
  //
  // Alleen bij een nieuw gesprek. In een lopend gesprek hoort er helemaal geen
  // opening te zijn, en dan is "begin nu duidelijk anders" een uitnodiging om
  // er alsnog een te verzinnen.
  if (isNewConversation && recentOpenings && recentOpenings.length) {
    lines.push(
      'Je begon je laatste berichten zo: ' +
        recentOpenings.map((o) => `"${o}…"`).join(', ') +
        '. Begin nu duidelijk anders.'
    );
  }

  // ---- uitvoervorm ---------------------------------------------------------
  //
  // Zonder logboek: gewoon de tekst. Mét logboek: twee gemarkeerde blokken in
  // één antwoord, zodat er één API-call nodig is in plaats van twee. Zie de
  // toelichting boven parseCombined in src/logbook.js voor waarom dit geen
  // JSON om het geheel heen is.
  if (logbookCategories && logbookCategories.length) {
    lines.push('');
    lines.push('Geef je antwoord in precies deze twee blokken:');
    lines.push('');
    lines.push('<bericht>');
    lines.push('De tekst die naar de klant gaat. Verder niets — geen uitleg,');
    lines.push('geen aanhalingstekens, geen "Hier is je antwoord:".');
    lines.push('</bericht>');
    lines.push('<logboek>');
    lines.push('[{"categoryId":"4","text":"Woont in Maaseik"}]');
    lines.push('</logboek>');
    lines.push('');
    lines.push('In het logboekblok zet je feiten over de KLANT uit dit gesprek,');
    lines.push('als geldige JSON. Gebruik exact deze categorie-ids:');
    logbookCategories.forEach((c) => lines.push(`- ${c.id} = ${c.label}`));
    lines.push('');
    lines.push('Hier wordt in de praktijk het meest van gemist. Loop deze zes na:');
    lines.push('woonplaats, hobby\'s, familie (kinderen, broers, zussen, ouders,');
    lines.push('partner), seksuele voorkeuren, werk of beroep, en gezondheid');
    lines.push('(ziektes, klachten, medicijnen). Staat er iets over in het gesprek,');
    lines.push('dan hoort het erin — ook als het maar één woord is.');
    lines.push('');
    lines.push('ALLEEN UIT HET LAATSTE BERICHT VAN DE KLANT. Niet uit de rest van');
    lines.push('het gesprek: dat is bij eerdere beurten al gelogd. Staat er in dat');
    lines.push('ene bericht niets nieuws over hem, zet dan een lege lijst: [].');
    lines.push('');
    lines.push('Alleen wat de klant zelf gezegd heeft. Niet afleiden, niet');
    lines.push('interpreteren, niet aanvullen met wat waarschijnlijk is. Eén kort');
    lines.push('feit per regel. Sla over wat al in het dossier staat.');

    // Het eigen dossier van de persona vullen — maar alleen als het nog vrijwel
    // leeg is, en alleen met wat er in dit gesprek al over haar is gezegd.
    //
    // Dit is bewust géén vrije verzinsel-opdracht. Wat hier in komt te staan is
    // permanent en wordt door de volgende operator als waarheid gelezen; die
    // gaat erop verder. Iets neerzetten dat de persona nooit heeft gezegd,
    // maakt haar in het volgende gesprek ongeloofwaardig.
    //
    // Vandaar de vraag om vast te leggen wat er al ligt: haar profiel op de
    // pagina en wat ze in dit gesprek zelf verteld heeft.
    if (personaLogbookCategories && personaLogbookCategories.length) {
      lines.push('');
      lines.push('Voeg daarna nog een derde blok toe:');
      lines.push('');
      lines.push('<eigenlogboek>');
      lines.push('[{"categoryId":"5","text":"Werkt onregelmatig in de zorg"}]');
      lines.push('</eigenlogboek>');
      lines.push('');
      lines.push('Daarin komen feiten over JOU, de persona — haar eigen dossier is');
      lines.push('nog vrijwel leeg. Categorie-ids:');
      personaLogbookCategories.forEach((c) => lines.push(`- ${c.id} = ${c.label}`));
      lines.push('');
      lines.push('Leg alleen vast wat al vaststaat: wat in haar profiel hierboven');
      lines.push('staat, en wat zij in dit gesprek zelf over zichzelf verteld heeft.');
      lines.push('Verzin er niets bij. Wat hier in komt is permanent en wordt door');
      lines.push('de volgende operator als waar aangenomen — een verzonnen beroep');
      lines.push('maakt haar in het volgende gesprek ongeloofwaardig. Is er niets');
      lines.push('vast te leggen, zet dan [].');
    }
  } else {
    lines.push('Geef alleen de tekst van het antwoord terug. Geen aanhalingstekens, geen uitleg, geen "Hier is je antwoord:".');
  }

  return lines.join('\n');
}

function buildUserContent(payload) {
  const parts = [];

  parts.push('Klantprofiel:\n' + JSON.stringify(payload.customer || {}, null, 2));
  parts.push('Persona-profiel (jij, de operator):\n' + JSON.stringify(payload.persona || {}, null, 2));

  if (payload.attachmentsLoaded) {
    parts.push("Beschikbare foto's:\n" + JSON.stringify(payload.attachments || [], null, 2));
  }

  const history = (payload.messages || [])
    .map((m) => `${m.role === 'operator' ? 'Ik' : 'Klant'}: ${m.text}`)
    .join('\n');
  parts.push('Gesprek tot nu toe:\n' + (history || '(nog geen berichten)'));

  // HET EIGEN DOSSIER VAN DE PERSONA IS KARAKTERINFORMATIE, GEEN BIJZAAK.
  //
  // Hier staat wat er in eerdere gesprekken over deze persona is verteld: haar
  // werk, haar woonsituatie, of ze kinderen heeft. Zonder dit verzint het
  // model in elk gesprek iets nieuws, en dan werkt ze maandag in de zorg en
  // dinsdag in de horeca. Het profielpaneel (naam, leeftijd, haarkleur) dekt
  // dat niet — dit wel.
  const eigen = (payload.personaLogbook && payload.personaLogbook.existing) || [];
  if (eigen.length) {
    parts.push(
      'Wat er over JOU (de persona) in je eigen dossier staat. Dit is eerder ' +
        'aan klanten verteld, dus alles wat je schrijft moet hiermee kloppen:\n' +
        eigen.map((e) => `- ${e.text}`).join('\n')
    );
  }

  // Wat er al gelogd is moet mee, anders stelt het model feiten voor die er al
  // in staan. Die worden er in content.js wel uitgefilterd, maar dan zijn de
  // tokens al betaald en houd je soms een leeg logboek over terwijl er wél
  // iets nieuws te melden was.
  const bestaand = (payload.logbook && payload.logbook.existing) || [];
  if (payload.logbook) {
    parts.push(
      'Wat al in het dossier van deze klant staat:\n' +
        (bestaand.length
          ? bestaand.map((e) => `- ${e.text}`).join('\n')
          : '(nog niets)')
    );
  }

  // Waar het antwoord op moet slaan, apart en als laatste.
  //
  // De geschiedenis staat hierboven als één blok, en daarin verdwijnt het
  // bericht waar het nu om gaat tussen vijftig andere. Het laatste klant-
  // bericht er nog een keer uit lichten kost een paar tokens en scheelt een
  // antwoord dat nergens op slaat.
  const berichten = payload.messages || [];
  let laatsteKlant = null;
  for (let i = berichten.length - 1; i >= 0; i--) {
    if (berichten[i] && berichten[i].role === 'customer') {
      laatsteKlant = berichten[i].text;
      break;
    }
  }

  if (laatsteKlant) {
    parts.push('Hier moet je antwoord op slaan — het laatste bericht van de klant:\n' + laatsteKlant);
  }

  parts.push('Schrijf het volgende antwoord namens de persona.');
  return parts.join('\n\n');
}

// De namen waarmee de klant nooit aangesproken mag worden. Zowel de echte
// naam als de gebruikersnaam: "Pedek325" schrijft een model soms uit als
// "Pedek", en beide rekent de site aan.
function customerNamesOf(payload) {
  const klant = (payload && payload.customer) || {};
  return [klant.name, klant.nickname].filter(Boolean);
}

// Per huisregel één zin, in de taal waarin de regel bestaat. Zonder deze
// uitleg is een herkansing niet meer dan opnieuw gooien met dezelfde dobbel-
// steen.
function styleRetryParts(styleResult) {
  const issues = (styleResult && styleResult.issues) || [];
  const parts = [];

  for (const issue of issues) {
    const items = (issue.items || []).map((i) => `"${i}"`).join(', ');
    switch (issue.type) {
      case 'naam':
        parts.push(
          `Je gebruikt de naam van de klant (${items}). Dat doen we nooit — de ` +
            'site rekent het aan als fout. Schrijf het opnieuw zonder de naam; ' +
            'gebruik "jij" of een koosnaampje.'
        );
        break;
      case 'cliche':
        parts.push(
          `Dit is een standaardzin die in te veel berichten terugkomt: ${items}. ` +
            'Schrijf iets dat alleen op déze klant slaat — stel een vraag over ' +
            'iets uit zijn profiel of uit wat hij net schreef.'
        );
        break;
      case 'belofte':
        parts.push(
          `Je belooft iets wat niet waargemaakt kan worden (${items}). Er zijn ` +
            'maar een paar foto\'s en die zijn er al. Zeg nooit dat er iets ' +
            'aankomt of dat je iets gaat maken.'
        );
        break;
      case 'toezegging':
        parts.push(
          `"${(issue.items || []).join('", "')}" is uitstel, geen antwoord. Zeg ` +
            'nooit dat je gaat kijken of je best doet. Kom met een concrete ' +
            'reden waarom het nu niet gaat — druk op het werk bijvoorbeeld — en ' +
            'breng het gesprek terug naar de fantasie.'
        );
        break;
      case 'groet':
        parts.push(
          `Je begint weer met ${items}, net als de vorige keer. Kies een andere ` +
            'opening, of begin gewoon meteen met wat je te zeggen hebt.'
        );
        break;
      default:
        break;
    }
  }

  return parts;
}

// De herkansing is alleen wat waard als het model hóórt wat er mis was.
//
// Hier zat een bug: de meldingen voor emoji, afspraken en stopwoordjes stonden
// genest in `if (hits && hits.length)`. Was er geen verboden wóórd gevonden —
// het gewone geval — dan kreeg het model alleen "schrijf het opnieuw" te
// horen, zonder reden, en gokte het blind. Dat kostte structureel de tweede en
// derde call, en trof een klein model harder dan een groot.
function buildRetryMessage(
  hits,
  lengthResult,
  emojiFout,
  regelFout,
  stopwoordFout,
  styleResult,
  text
) {
  const parts = [];

  if (stopwoordFout) {
    const opgerekt = ChatAssistant.blocklist.stretchedHits(text);
    if (opgerekt.length) {
      parts.push(
        `Je rekt woorden op (${opgerekt.map((h) => `"${h}"`).join(', ')}). Er ` +
          'bestaat geen Nederlands woord met drie dezelfde letters achter ' +
          'elkaar; de site rekent dat aan als grammaticafout. Schrijf het ' +
          'normaal.'
      );
    }
    parts.push(
      'Er staan stopwoordjes in (haha, hmmm, mama, jaaahh, lol, xx, xxx, of ' +
        'twee of meer punten achter elkaar). Schrijf het opnieuw zonder die, ' +
        'en laat de toon uit de woorden zelf komen.'
    );
  }

  if (regelFout) {
    const afspraak = ChatAssistant.blocklist.dateProposalHits(text);
    if (afspraak.length) {
      parts.push(
        `Dat antwoord stelt een echte ontmoeting voor (${afspraak
          .map((h) => `"${h}"`)
          .join(', ')}). Dat mag nooit, op geen enkel moment. Verzin een reden ` +
          'waarom het nu niet gaat en draai er speels omheen.'
      );
    } else {
      parts.push(
        'Dat antwoord geeft contactgegevens, en dat mag hier niet. Schrijf het ' +
          'opnieuw zonder, en breng het gesprek terug naar de fantasie.'
      );
    }
  }

  if (emojiFout) {
    parts.push(
      'Dat antwoord bevat een of meer emoji. Dit platform staat die niet toe; ' +
        'schrijf het zonder, en druk het gevoel met woorden uit.'
    );
  }

  if (hits && hits.length) {
    parts.push(
      'Dat antwoord bevat verboden taalgebruik: ' +
        hits.map((h) => `"${h}"`).join(', ') +
        '. Vermijd die woorden en zinnen volledig, ook in een andere vervoeging ' +
        'of omschrijving.'
    );
  }

  parts.push(...styleRetryParts(styleResult));

  if (lengthResult && !lengthResult.ok) {
    parts.push(
      lengthResult.reason === 'lang'
        ? `Dat antwoord is ${lengthResult.length} tekens en dat is te lang; het maximum is ` +
            `${lengthResult.maxChars}. Kort het in met behoud van de strekking — schrap ` +
            'uitweidingen, niet de kern.'
        : `Dat antwoord is ${lengthResult.length} tekens en dat is te kort; het minimum is ` +
            `${lengthResult.minChars}. Schrijf het uit met echte inhoud — geen vulzinnen.`
    );
  }

  parts.push(
    'Schrijf het antwoord opnieuw, met dezelfde strekking en toon. Geef alleen de ' +
      'nieuwe antwoordtekst terug.'
  );

  return parts.join(' ');
}

// De ruwe JSON van de API is onleesbaar in een statusbalk van één regel, en
// juist de fouten die je zelf kunt oplossen verdienen een duidelijke zin.
// Alles wat we niet herkennen houdt zijn oorspronkelijke tekst — liever een
// lelijke melding dan een verzwegen oorzaak.
function describeApiError(status, body) {
  const raw = String(body || '');
  const lower = raw.toLowerCase();

  if (status === 401) return 'API-key ongeldig — controleer hem in de popup';
  if (status === 403) return 'API-key mag dit niet — controleer de rechten van de key';
  if (status === 429) return 'Te veel verzoeken achter elkaar — even wachten';
  if (lower.includes('credit balance')) return 'Anthropic-tegoed is op — vul het aan in de console';
  if (status === 529 || status >= 500) return `Anthropic heeft een storing (${status}) — probeer het zo nog eens`;

  return `API-fout ${status}: ${raw.slice(0, 300)}`;
}

async function callApi(settings, systemPrompt, messages, maxTokens) {
  const res = await fetch(API_URL, {
    method: 'POST',
    headers: {
      'content-type': 'application/json',
      'x-api-key': settings.apiKey,
      'anthropic-version': API_VERSION,
      // Vereist voor rechtstreekse calls vanuit een browsercontext — de API
      // weigert anders standaard, precies vanwege het risico dat een key in
      // client-side code terechtkomt. Dit was het open punt uit
      // docs/03-PROJECT.md ("Te verifiëren: accepteert de API rechtstreekse
      // calls?") — het antwoord is ja, met deze expliciete opt-in header.
      'anthropic-dangerous-direct-browser-access': 'true',
    },
    body: JSON.stringify({
      model: settings.model,
      max_tokens: maxTokens || 1024,
      system: [
        {
          type: 'text',
          text: systemPrompt,
          // DE ONDERGRENS VERSCHILT PER MODEL, EN OP HAIKU IS HIJ HOOG.
          //
          // Hier stond dat caching aanslaat boven ~1024 tokens. Dat klopt voor
          // Sonnet 5, maar niet voor Haiku 4.5: daar is de ondergrens 4096
          // tokens. Met een systeem-prompt van rond de 800 gebeurt er dus
          // niets, en betaal je bij elke herkansing opnieuw de volle prijs
          // voor exact dezelfde tekst.
          //
          // Dat is precies andersom dan je zou denken: de prompt gróter maken
          // (met voorbeelden) kan hem goedkoper maken, omdat hij dan pas boven
          // die grens komt. Zie src/memory.js.
          //
          // De ttl van een uur in plaats van vijf minuten is bewust: bij een
          // wachtrij van rond de 45 berichten per uur is een venster van vijf
          // minuten te kort om de schrijfkosten terug te verdienen.
          cache_control: { type: 'ephemeral', ttl: '1h' },
        },
      ],
      messages,
    }),
  });

  if (!res.ok) {
    const errText = await res.text().catch(() => '');
    throw new Error(describeApiError(res.status, errText));
  }

  const data = await res.json();

  if (data.stop_reason === 'refusal') {
    throw new Error('Het model heeft dit verzoek geweigerd.');
  }

  const block = (data.content || []).find((b) => b.type === 'text');
  if (!block) throw new Error('Geen tekst in het antwoord van het model.');
  return block.text.trim();
}

// ---- logboek ---------------------------------------------------------------

async function handleGenerate(payload) {
  const settings = await getSettings();

  if (!settings.apiKey) {
    throw new Error('Geen API-key ingesteld. Zet die in de popup.');
  }

  const config = settings.config || ChatAssistant.configDefaults;
  const account = findAccountConfig(settings.accounts, payload.operatorName);
  const blockedItems = ChatAssistant.blocklist.merge(
    settings.globalBlocklist,
    account && account.blocklist
  );

  // Zichtbaar maken wat er echt geldt. Een lege lijst terwijl je er woorden
  // in hebt gezet, betekent dat ze aan een ander account hangen dan het
  // account dat op deze pagina herkend is.
  console.log(
    '[ChatAssistant] account:',
    payload.operatorName,
    account ? '(gevonden)' : '(NIET in instellingen)',
    '— verboden items:',
    blockedItems.length
  );

  // Lengtegrenzen: de adapter meet ze op de pagina, maar de backend mag ze
  // overschrijven. Zo is een huisregel bij te stellen zonder uitrol.
  const perPlatform = (config.limits && config.limits.perPlatform) || {};
  const override = perPlatform[payload.platform] || {};
  const limits = Object.assign({}, payload.limits || {}, {
    minChars:
      typeof override.minChars === 'number' ? override.minChars : (payload.limits || {}).minChars,
    maxChars:
      typeof override.maxChars === 'number' ? override.maxChars : (payload.limits || {}).maxChars,
  });
  const allowsEmoji = payload.allowsEmoji !== false;
  // Twee aparte regels. Een echte afspraak voorstellen mag nergens; alleen
  // contactgegevens gaan bij een blauwe balk open, en dan gemaskeerd.
  const allowsContactDetails = payload.allowsContactDetails === true;
  const allowsDateProposal = payload.allowsDateProposal === true;
  // De gekleurde balk bepaalt deze twee. Ontbreekt de balk, dan staat
  // src/stage.js ze allebei op de strengste stand.
  const allowsSexInitiative = payload.allowsSexInitiative === true;
  const masksContactDetails = payload.masksContactDetails === true;
  // Context voor de huisregels: de naam van de klant mag nooit in een bericht
  // staan, en de groet moet afwisselen met wat er eerder is gestuurd.
  const customerNames = customerNamesOf(payload);
  const previousOperatorTexts = (payload.messages || [])
    .filter((m) => m && m.role === 'operator')
    .map((m) => m.text);
  // De woordenlijsten mogen centraal bijgestuurd worden. `null` betekent
  // "gebruik de ingebouwde lijst"; een lege array betekent "die regel staat
  // uit". Dat onderscheid komt uit src/config/schema.js.
  const cfgStyle = (config.style || {});
  const styleContext = {
    customerNames,
    previousOperatorTexts,
    cliches: cfgStyle.cliches,
    promises: cfgStyle.promises,
    hedges: cfgStyle.hedges,
  };

  // Twee berichten of minder is nog geen lopend gesprek. Juist daar viel het
  // model terug op standaardzinnen, dus juist daar sturen we op een vraag uit
  // het profiel.
  // NIEUW GESPREK OF LOPEND GESPREK
  //
  // Hier stond alleen "hooguit twee berichten". Dat is te broos: ziet de
  // adapter maar een deel van de geschiedenis — en of ChatHomeBase oudere
  // berichten pas bijlaadt bij scrollen is nooit uitgezocht — dan wordt een
  // gesprek van vijftig beurten ineens als nieuw behandeld, en valt de robot
  // binnen met "hallo, hoe gaat het vandaag?".
  //
  // Heeft de persona al iets geschreven, dan loopt het gesprek. Punt. Dat
  // signaal blijft kloppen ook als de rest van de geschiedenis ontbreekt,
  // want één eigen bericht is genoeg bewijs.
  const messageCount = (payload.messages || []).length;
  const isNewConversation = previousOperatorTexts.length === 0 && messageCount <= 2;
  const laatsteEigen = previousOperatorTexts[previousOperatorTexts.length - 1];

  // Het logboek reist mee in dezelfde call in plaats van in een tweede. Heeft
  // dit platform er geen, dan blijft de lijst leeg en vraagt de prompt er ook
  // niet om — dan is het antwoord gewone tekst zonder blokken.
  const logbookCategories = (payload.logbook && payload.logbook.categories) || [];

  // Het eigen dossier van de persona vragen we alleen als het nog vrijwel leeg
  // is. Het bureau zei dat het meestal al vol staat, en dan is het zonde van de
  // tokens en van het derde blok dat een klein model moet volhouden.
  const personaBook = payload.personaLogbook || null;
  const personaLeeg =
    personaBook &&
    (personaBook.existing || []).length <
      ((config.logbook && config.logbook.personaMinEntries) || PERSONA_LOGBOOK_MIN_ENTRIES);
  const personaLogbookCategories = personaLeeg ? personaBook.categories || [] : [];

  // Wat de extensie van eerdere goede berichten van deze persona onthouden
  // heeft. Leeg bij een nieuw account; vult zichzelf vanzelf naarmate er
  // berichten verstuurd worden.
  const memory = await getMemory();
  const examples = (config.features && config.features.memory === false)
    ? []
    : ChatAssistant.memory.examplesFor(
        memory,
        payload.operatorName,
        (config.memory && config.memory.examplesInPrompt) || 5
      );
  const recentOpenings = (config.features && config.features.memory === false)
    ? []
    : ChatAssistant.memory.openingsFor(
        memory,
        payload.operatorName,
        (config.memory && config.memory.openingsInPrompt) || 6
      );

  const systemPrompt = buildSystemPrompt({
    account,
    blockedItems,
    limits,
    allowsEmoji,
    allowsContactDetails,
    allowsSexInitiative,
    masksContactDetails,
    customerNames,
    isNewConversation,
    lastGreeting: ChatAssistant.style.greetingOf(laatsteEigen),
    examples,
    recentOpenings,
    logbookCategories,
    personaLogbookCategories,
    logbookPriority: (config.logbook && config.logbook.priorityCategories) || [],
  });

  console.log(
    `[ChatAssistant] prompt: ${systemPrompt.length} tekens, ` +
      `${examples.length} eigen voorbeeld(en), ${recentOpenings.length} opening(en)`
  );
  // Ziet de adapter het hele gesprek? Staat hier "1 bericht" terwijl er op je
  // scherm twintig staan, dan laadt de site ze pas bij bij het scrollen en
  // antwoordt het model op een halve geschiedenis.
  console.log(
    `[ChatAssistant] gesprek: ${messageCount} bericht(en) zichtbaar, waarvan ` +
      `${previousOperatorTexts.length} van de persona — ` +
      (isNewConversation ? 'behandeld als NIEUW gesprek' : 'behandeld als LOPEND gesprek')
  );
  const messages = [{ role: 'user', content: buildUserContent(payload) }];

  let text = '';
  let hits = [];
  let lengthResult = { ok: true };
  let styleResult = { ok: true, issues: [] };

  // De logboekfeiten komen uit dezelfde call als het bericht, maar alleen uit
  // de eerste poging. Een herkansing gaat over de formulering van het bericht;
  // de feiten in het gesprek veranderen daar niet van, en er opnieuw om vragen
  // zou de winst van het samenvoegen meteen weer weggeven.
  let logbookEntries = [];
  let personaLogbookEntries = [];

  const maxAttempts = (config.ai && config.ai.maxAttempts) || MAX_ATTEMPTS;

  for (let attempt = 1; attempt <= maxAttempts; attempt++) {
    const raw = await callApi(
      settings,
      systemPrompt,
      messages,
      logbookCategories.length
        ? (config.ai && config.ai.replyWithLogbookMaxTokens) || REPLY_WITH_LOGBOOK_MAX_TOKENS
        : (config.ai && config.ai.replyMaxTokens) || REPLY_MAX_TOKENS
    );

    const parsed = ChatAssistant.logbook.parseCombined(raw);
    text = parsed.reply;
    if (attempt === 1) {
      logbookEntries = parsed.entries;
      personaLogbookEntries = parsed.personaEntries;
      if (logbookCategories.length && !parsed.tagged) {
        // Het model hield zich niet aan de blokken. Het bericht is er nog —
        // parseCombined geeft dan de hele tekst terug — maar er zijn geen
        // feiten. Zichtbaar maken, want anders lijkt het logboek gewoon leeg.
        console.warn(
          '[ChatAssistant] logboek: model gebruikte de blokken niet; ' +
            'bericht is bruikbaar, feiten ontbreken'
        );
      }
    }

    // EERST REPAREREN, DAN PAS OORDELEN.
    //
    // Een emoji en een stopwoord dragen geen betekenis, dus weghalen kan de
    // strekking niet aantasten. Vroeger kostte elk van beide een volledige
    // herkansing — een hele API-call — terwijl één regexvervanging hetzelfde
    // resultaat geeft. Bij Haiku 4.5, dat er gulzig mee strooit, waren dit
    // samen de twee duurste herkansingsredenen.
    //
    // De volgorde is niet vrijblijvend: opschonen maakt het bericht korter,
    // dus de lengtecontrole moet erna komen. Andersom keuren we een bericht
    // goed dat na opschoning ineens te kort is.
    if (!allowsEmoji) text = ChatAssistant.blocklist.stripEmoji(text);
    text = ChatAssistant.blocklist.stripFillers(text);

    const result = ChatAssistant.blocklist.check(text, blockedItems);
    hits = result.hits;
    // Dezelfde functie als de noodrem in content.js gebruikt, zodat het model
    // niet op een andere regel wordt afgerekend dan het meekreeg.
    lengthResult = ChatAssistant.autosend.checkLength(text, limits);
    const emojiFout = !allowsEmoji && ChatAssistant.blocklist.hasEmoji(text);
    // Een afspraakvoorstel blokkeert altijd. Contactgegevens alleen waar ze
    // niet mogen — bij een blauwe balk zijn ze juist de bedoeling.
    const regelFout =
      ChatAssistant.blocklist.hasDateProposal(text) ||
      (!allowsContactDetails && ChatAssistant.blocklist.hasContactDetails(text));
    // Wat na het opschonen nog overblijft is niet mechanisch te herstellen —
    // "mama" bijvoorbeeld, dat een moeder kan zijn.
    const stopwoordFout = ChatAssistant.blocklist.tooManyFillers(text);
    styleResult = ChatAssistant.style.check(text, styleContext);

    if (
      result.ok &&
      lengthResult.ok &&
      !emojiFout &&
      !regelFout &&
      !stopwoordFout &&
      styleResult.ok
    ) {
      return {
        text,
        blocked: [],
        length: lengthResult,
        dateOrContact: false,
        accountFound: !!account,
        attempts: attempt,
        logbookEntries,
        personaLogbookEntries,
      };
    }

    if (attempt === maxAttempts) break;

    // De overtreding gaat terug het gesprek in, zodat het model weet wát er
    // mis was in plaats van blind opnieuw te gokken.
    messages.push({ role: 'assistant', content: text });
    messages.push({
      role: 'user',
      content: buildRetryMessage(
        hits,
        lengthResult,
        emojiFout,
        regelFout,
        stopwoordFout,
        styleResult,
        text
      ),
    });
  }

  // Drie pogingen op en het klopt nog niet. Het opschonen is in de lus al
  // gebeurd, dus dit is puur een vangnet voor het geval de laatste poging
  // alsnog een emoji opleverde — dat is de enige regel die absoluut is en
  // tegelijk veilig te repareren.
  if (!allowsEmoji) text = ChatAssistant.blocklist.stripEmoji(text);

  console.warn(
    '[ChatAssistant] na',
    maxAttempts,
    'pogingen nog niet schoon:',
    [
      hits.length ? `verboden(${hits.length})` : null,
      lengthResult.ok ? null : `lengte(${lengthResult.reason})`,
      ...(styleResult.issues || []).map((i) => i.type),
    ]
      .filter(Boolean)
      .join(', ')
  );

  return {
    text,
    blocked: hits,
    length: lengthResult,
    accountFound: !!account,
    attempts: maxAttempts,
    logbookEntries,
    personaLogbookEntries,
    // Wat er ná drie pogingen nog aan huisregels mankeert. content.js zet dit
    // in de statusbalk: liever een voorstel met een waarschuwing dan een leeg
    // veld, maar je moet wel zien waar je op moet letten.
    styleIssues: (styleResult.issues || []).map((i) => i.type),
    dateOrContact:
      ChatAssistant.blocklist.hasDateProposal(text) ||
      (!allowsContactDetails && ChatAssistant.blocklist.hasContactDetails(text)),
  };
}
