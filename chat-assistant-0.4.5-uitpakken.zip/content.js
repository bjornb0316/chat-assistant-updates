// Orchestrator: kiest de adapter, toont status, laat de trigger bepalen
// wanneer er gegenereerd wordt, en roept background.js aan.
// Bevat zelf geen platformkennis — die zit uitsluitend in de adapters.
//
// Sinds 17-08-2026 bepaalt hij ook de modus (handmatig / klaarzetten / full
// auto) en drukt hij in full auto zelf op verzenden, na een zichtbare
// afteller. Zie docs/superpowers/specs/2026-08-17-modus-per-account-en-
// moddies-design.md.

(function () {
  const CA = window.ChatAssistant;
  if (!CA || !CA.adapters) return;

  // Per tabblad, en overleeft de paginaherlading die OperatorPanel en moddies
  // na elke verzending doen. In het geheugen zou de stand daar telkens
  // terugspringen.
  const MODE_KEY = 'chat-assistant-mode';

  let statusEl = null;
  let labelEl = null;
  let modeBtn = null;
  let manualBtn = null;
  let stopBtn = null;
  let busy = false;
  let activeTrigger = null;
  let currentAdapter = null;
  let lastContext = null;

  // Het laatst gegenereerde voorstel, plus hoeveel pogingen het kostte. Wordt
  // pas gebruikt als het bericht echt verstuurd is — zie onthoudVerzonden().
  let laatsteGeneratie = null;
  let countdown = null;
  let panelEl = null;
  let bootstrapTimer = null;

  // Na een herlaad van de extensie in chrome://extensions raakt het content
  // script in al geopende tabbladen los van zijn extensie: chrome.runtime is
  // dan verdwenen. Alles wat daarna een boodschap stuurt gooit een TypeError
  // die in beeld komt als "Cannot read properties of undefined (reading
  // 'sendMessage')" — onbegrijpelijk, terwijl de oplossing simpel is.
  function extensionAlive() {
    try {
      return !!(chrome && chrome.runtime && chrome.runtime.id);
    } catch (e) {
      return false;
    }
  }

  // Losgeraakt betekent: er valt niets meer te doen tot de pagina ververst
  // wordt. Doorpollen levert alleen elke twee seconden dezelfde fout op.
  function stopEverything(message) {
    if (activeTrigger) {
      activeTrigger.stop();
      activeTrigger = null;
    }
    if (bootstrapTimer !== null) {
      clearInterval(bootstrapTimer);
      bootstrapTimer = null;
    }
    cancelCountdown(null);
    setStatus(message, true, true);
  }

  // "Sticky" betekent: dit bericht blijft staan tot de volgende generatie.
  // Zonder dat zou de tick elke 2 seconden een foutmelding of waarschuwing
  // overschrijven met alleen de accountnaam, precies wanneer je hem moet lezen.
  let statusIsSticky = false;

  // ---- instellingen ---------------------------------------------------------

  // De instellingen worden asynchroon geladen. Tot ze binnen zijn geldt
  // 'manual': er gebeurt dan even niets vanzelf. Zou de tussenstand 'draft'
  // zijn, dan kan de trigger één keer vuren vóór we weten dat dit account
  // eigenlijk op handmatig staat.
  let accounts = null;

  // ---- remote configuratie --------------------------------------------------
  //
  // De service worker haalt hem op en bewaart hem; wij lezen alleen wat er
  // ligt. Zolang er niets is geldt de ingebouwde standaard, zodat er nooit een
  // moment is waarop de extensie niets weet.
  //
  // Bij elke paginalading vragen we om een verversing. Dat is precies wat de
  // klant nodig heeft: instellingen wijzigen bij ons, F5 bij hen. De service
  // worker beslist zelf of dat een echte call wordt of dat de cache nog vers
  // genoeg is.
  let remoteConfig = CA.configDefaults;

  function feature(naam) {
    const f = (remoteConfig && remoteConfig.features) || {};
    return f[naam] !== false;
  }

  function tekst(sleutel, standaard) {
    const t = (remoteConfig && remoteConfig.ui && remoteConfig.ui.texts) || {};
    return t[sleutel] || standaard;
  }

  function pasConfigToe(config) {
    if (!config) return;
    remoteConfig = config;

    const onderhoud = config.maintenance || {};
    if (onderhoud.enabled) {
      stopEverything(
        onderhoud.message || 'Chat Assistant staat tijdelijk uit (onderhoud)'
      );
      return;
    }
    renderModeButton();
  }

  function haalConfig(force) {
    if (!extensionAlive()) return;
    try {
      chrome.runtime
        .sendMessage({ type: force ? 'refresh-config' : 'get-config' })
        .then((r) => {
          if (!r) return;
          if (r.status === 'incompatible') {
            setStatus(
              `Extensie is te oud (${r.installed}) — bijwerken naar ${r.required}`,
              true,
              true
            );
          }
          pasConfigToe(r.config);
        })
        .catch(() => {
          /* geen config is geen ramp: de standaard geldt */
        });
    } catch (e) {
      /* zie boven */
    }
  }

  chrome.storage.local.get(['accounts', 'refreshSeconds']).then(
    (stored) => {
      accounts = stored.accounts || {};
      refreshSeconds = Number(stored.refreshSeconds) || 0;
      renderModeButton();
    },
    () => {
      accounts = {};
    }
  );

  // Eén verversing per paginalading. Dit is de hele belofte van het systeem:
  // de klant hoeft alleen F5 te drukken.
  haalConfig(true);

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local') return;
    // De service worker heeft nieuwe config weggeschreven; meteen toepassen
    // zonder dat er iets herladen hoeft te worden.
    if (changes.remoteConfig) pasConfigToe(changes.remoteConfig.newValue);
    if (changes.refreshSeconds) {
      refreshSeconds = Number(changes.refreshSeconds.newValue) || 0;
    }
    if (!changes.accounts) return;
    accounts = changes.accounts.newValue || {};
    renderModeButton();
  });

  function sessionOverride() {
    try {
      return sessionStorage.getItem(MODE_KEY);
    } catch (e) {
      return null;
    }
  }

  function setSessionOverride(mode) {
    try {
      sessionStorage.setItem(MODE_KEY, mode);
    } catch (e) {
      console.warn('[ChatAssistant] modus niet opgeslagen', e);
    }
    renderModeButton();
  }

  function currentMode() {
    if (accounts === null) return 'manual';
    const name = lastContext && lastContext.operatorName;
    const account = name ? accounts[name] : null;
    return CA.autosend.effectiveMode(
      account && account.mode,
      sessionOverride(),
      currentAdapter && currentAdapter.allowsAutoSend
    );
  }

  // ---- de modusknop ---------------------------------------------------------

  const MODE_LABEL = {
    manual: 'Handmatig',
    draft: 'Klaarzetten',
    full: 'Full auto',
  };
  const MODE_COLOUR = {
    manual: '#6b7280',
    draft: '#16a34a',
    full: '#b45309',
  };
  const MODE_HINT = {
    manual: 'Er gebeurt niets vanzelf. Klik om voorstellen te laten klaarzetten.',
    draft: 'Zet een voorstel klaar bij een nieuw klantbericht. Jij verstuurt.',
    draftPanel: 'Toont een voorstel naast de chat. Dit platform weigert ingevoegde tekst, dus typ je het zelf over.',
    full: 'Zet een voorstel klaar en verstuurt het zelf na een afteller.',
  };

  // Op een platform zonder auto-verzenden bestaat 'full' niet in de rondgang.
  // Een ontbrekende stand roept geen vragen op; een uitgeschakelde nodigt uit
  // tot proberen.
  function availableModes() {
    const all = ['manual', 'draft', 'full'];
    // Twee plafonds: het platform moet het toestaan, én het mag centraal
    // uitgezet zijn. Staat automatisch verzenden centraal uit, dan bestaat
    // 'full' niet in de rondgang — precies zoals op een platform dat het niet
    // toestaat.
    const mag = currentAdapter && currentAdapter.allowsAutoSend === true && feature('autoSend');
    return mag ? all : ['manual', 'draft'];
  }

  function renderModeButton() {
    if (!modeBtn) return;
    const mode = currentMode();
    const paneelmodus = mode === 'draft' && currentAdapter && currentAdapter.allowsDraftInsert === false;
    modeBtn.textContent = paneelmodus ? 'Voorstel' : MODE_LABEL[mode];
    modeBtn.style.background = MODE_COLOUR[mode];
    modeBtn.title = paneelmodus ? MODE_HINT.draftPanel : MODE_HINT[mode];
  }

  function cycleMode() {
    const modes = availableModes();
    const index = modes.indexOf(currentMode());
    setSessionOverride(modes[(index + 1) % modes.length]);
  }

  // ---- statusbalk -----------------------------------------------------------

  function findAdapter() {
    return (
      CA.adapters.find((a) => {
        try {
          return a.isChatPage();
        } catch (e) {
          return false;
        }
      }) || null
    );
  }

  function ensureUI() {
    if (statusEl && document.body.contains(statusEl)) return;

    statusEl = document.createElement('div');
    statusEl.id = 'chat-assistant-status';
    statusEl.style.cssText =
      'position:fixed;top:8px;right:8px;z-index:2147483647;' +
      'background:#111827;color:#fff;font:12px -apple-system,BlinkMacSystemFont,sans-serif;' +
      'padding:6px 10px;border-radius:6px;display:flex;gap:8px;align-items:center;' +
      'box-shadow:0 2px 8px rgba(0,0,0,.3);max-width:60vw;';

    labelEl = document.createElement('span');
    labelEl.textContent = 'Chat Assistant';
    labelEl.style.cssText = 'white-space:nowrap;overflow:hidden;text-overflow:ellipsis;';

    const btnCss =
      'color:#fff;border:0;border-radius:4px;padding:3px 8px;' +
      'cursor:pointer;font:inherit;white-space:nowrap;';

    modeBtn = document.createElement('button');
    modeBtn.style.cssText = btnCss;
    modeBtn.addEventListener('click', cycleMode);

    manualBtn = document.createElement('button');
    manualBtn.textContent = 'Nu';
    manualBtn.title = 'Meteen een voorstel genereren, in elke stand.';
    manualBtn.style.cssText = btnCss + 'background:#2563eb;';
    manualBtn.addEventListener('click', () => {
      // Jij grijpt in, dus de reeks lege verversingen is voorbij. Zonder dit
      // blijft het verversen uit staan nadat het zichzelf heeft gestopt, en
      // is de enige uitweg het tabblad sluiten.
      resetVerversingen();
      if (currentAdapter) generate(currentAdapter);
    });

    // Alleen zichtbaar terwijl de afteller loopt.
    stopBtn = document.createElement('button');
    stopBtn.textContent = 'Stop';
    stopBtn.title = 'Houd dit bericht tegen; het blijft in het veld staan.';
    stopBtn.style.cssText = btnCss + 'background:#dc2626;';
    stopBtn.style.display = 'none';
    stopBtn.addEventListener('click', () => cancelCountdown('Gestopt — jij bent aan zet'));

    statusEl.appendChild(labelEl);
    statusEl.appendChild(modeBtn);
    statusEl.appendChild(manualBtn);
    statusEl.appendChild(stopBtn);
    document.body.appendChild(statusEl);

    renderModeButton();
  }

  function setStatus(msg, isError, sticky) {
    if (!labelEl) return;
    labelEl.textContent = msg;
    labelEl.style.color = isError ? '#fca5a5' : '#fff';
    labelEl.title = msg;
    statusIsSticky = !!sticky;
  }

  // ---- voorstelpaneel -------------------------------------------------------

  // Sommige platforms weigeren tekst die niet is getypt. Daar zetten we het
  // voorstel niet in het veld maar tonen we het ernaast, zodat jij het zelf
  // typt. De adapter geeft dat aan met allowsDraftInsert: false.
  //
  // Bewust géén kopieerknop: op zo'n platform wordt geplakte tekst alsnog
  // geweigerd, dus een kopieerknop nodigt alleen maar uit tot een melding.

  function hidePanel() {
    if (panelEl && panelEl.parentNode) panelEl.parentNode.removeChild(panelEl);
    panelEl = null;
  }

  function showPanel(replyText) {
    hidePanel();

    panelEl = document.createElement('div');
    panelEl.id = 'chat-assistant-panel';
    panelEl.style.cssText =
      'position:fixed;top:44px;right:8px;z-index:2147483646;width:380px;max-width:46vw;' +
      'max-height:60vh;overflow:auto;background:#111827;color:#f9fafb;' +
      'font:13px/1.5 -apple-system,BlinkMacSystemFont,sans-serif;' +
      'padding:10px 12px;border-radius:6px;box-shadow:0 2px 12px rgba(0,0,0,.4);';

    const head = document.createElement('div');
    head.style.cssText =
      'display:flex;justify-content:space-between;align-items:center;gap:8px;' +
      'margin-bottom:6px;font-size:11px;text-transform:uppercase;' +
      'letter-spacing:.04em;color:#9ca3af;';

    const title = document.createElement('span');
    title.textContent = `Voorstel — ${replyText.trim().length} tekens`;

    const close = document.createElement('button');
    close.textContent = '×';
    close.title = 'Sluiten';
    close.style.cssText =
      'background:none;border:0;color:#9ca3af;font-size:18px;line-height:1;' +
      'cursor:pointer;padding:0 2px;';
    close.addEventListener('click', hidePanel);

    head.appendChild(title);
    head.appendChild(close);

    const body = document.createElement('div');
    body.textContent = replyText;
    body.style.cssText = 'white-space:pre-wrap;word-break:break-word;';

    panelEl.appendChild(head);
    panelEl.appendChild(body);
    document.body.appendChild(panelEl);
  }

  // ---- automatisch verzenden ------------------------------------------------

  const WEIGERING = {
    platform: () => 'Niet verstuurd — dit platform verstuurt handmatig',
    verboden: () => 'Niet verstuurd — verboden woord',
    lengte: (d) =>
      d && d.reason === 'lang'
        ? `Niet verstuurd — te lang (${d.length} van max. ${d.maxChars})`
        : `Niet verstuurd — te kort (${d.length} van min. ${d.minChars})`,
    afspraak: () => 'Niet verstuurd — stelt een afspraak voor',
    foto: () => 'Foto van de klant — jij bent aan zet, robot gaat door',
  };

  function cancelCountdown(message) {
    if (!countdown) return;
    const stopped = countdown.cancel();
    countdown = null;
    if (stopBtn) stopBtn.style.display = 'none';
    if (stopped && message) setStatus(message, false, true);
  }

  function startCountdown() {
    if (stopBtn) stopBtn.style.display = '';
    countdown = CA.autosend.createCountdown({
      seconds:
        (remoteConfig.timings && remoteConfig.timings.countdownSeconds) ||
        CA.autosend.COUNTDOWN_SECONDS,
      onTick: (left) => {
        if (left > 0) setStatus(`Verstuurt over ${left}…`, false, true);
      },
      onFire: () => {
        countdown = null;
        if (stopBtn) stopBtn.style.display = 'none';
        if (send()) setStatus('Verstuurd', false, false);
        flushLogbook();
      },
    });
    countdown.start();
  }

  // De enige plek in de hele extensie die de verzendknop indrukt. Bereikbaar
  // via twee wegen: een echte Ctrl+Enter van de gebruiker, of een verstreken
  // afteller in full auto. Zie docs/02-ADAPTER-CONTRACT.md.
  function send() {
    if (!currentAdapter) return false;
    const button = currentAdapter.getSendButton ? currentAdapter.getSendButton() : null;
    if (!button) {
      setStatus('Verzendknop niet gevonden', true, true);
      return false;
    }
    button.click();
    onthoudVerzonden();
    return true;
  }

  // Wat er net de deur uit ging, onthouden als voorbeeld voor volgende keren.
  //
  // Dit hangt bewust aan het verzenden en niet aan het genereren: pas een
  // bericht dat daadwerkelijk is verstuurd, is een bericht dat goed genoeg
  // was. Een voorstel dat jij hebt weggegooid hoort geen voorbeeld te worden.
  //
  // Faalt dit, dan verliezen we een voorbeeld en verder niets — vandaar dat
  // het niets blokkeert en de fout alleen in de console belandt.
  function onthoudVerzonden() {
    if (!laatsteGeneratie || !laatsteGeneratie.text) return;
    if (!extensionAlive()) return;

    const wat = laatsteGeneratie;
    laatsteGeneratie = null;

    try {
      chrome.runtime
        .sendMessage({
          type: 'remember-sent',
          payload: {
            operatorName: wat.operatorName,
            text: wat.text,
            attempts: wat.attempts,
          },
        })
        .catch((e) => console.warn('[ChatAssistant] geheugen', e));
    } catch (e) {
      console.warn('[ChatAssistant] geheugen', e);
    }
  }

  // ---- logboek --------------------------------------------------------------

  // Wacht met wegschrijven zolang er een afteller loopt. Het logboekformulier
  // post via AJAX, maar mocht het ooit toch de pagina herladen, dan gaat het
  // klaargezette bericht verloren voordat het verstuurd is.
  //
  // Een lijst en geen enkel item: sinds het eigen dossier van de persona
  // erbij kwam kunnen er twee sets regels tegelijk staan te wachten, en met
  // één veld zou de tweede de eerste overschrijven.
  let logbookQueue = [];

  async function submitLogbook(adapter, entries, target) {
    const wat = target === 'persona' ? 'eigen dossier' : 'logboek';
    let gedaan = 0;
    for (const entry of entries) {
      // Kan een Promise zijn: op ChatHomeBase zit het invullen achter een
      // dialoogvenster en is het dus asynchroon.
      const gelukt = await adapter.setLogbookEntry(
        Object.assign({}, entry, { target: target || 'customer' })
      );
      if (!gelukt) {
        console.warn(
          `[ChatAssistant] ${wat}: invullen mislukt voor categorie`,
          entry.categoryId,
          '—',
          entry.text
        );
        continue;
      }
      const button = adapter.getLogbookSubmitButton
        ? adapter.getLogbookSubmitButton(target || 'customer')
        : null;
      if (!button) {
        console.warn(`[ChatAssistant] ${wat}: opslaanknop niet gevonden — gestopt`);
        break;
      }
      button.click();
      gedaan++;
      // Het formulier wordt na het posten geleegd. Even wachten, anders
      // schrijven we de volgende regel in een veld dat nog bezig is.
      await new Promise((resolve) => setTimeout(resolve, 800));
    }
    console.log(
      `[ChatAssistant] ${wat}: ${gedaan} van ${entries.length} regel(s) opgeslagen`
    );
    return gedaan;
  }

  async function flushLogbook() {
    if (!logbookQueue.length) return;
    const wachtend = logbookQueue;
    logbookQueue = [];
    for (const w of wachtend) {
      try {
        await submitLogbook(w.adapter, w.entries, w.target);
      } catch (e) {
        console.warn('[ChatAssistant] logboek', e);
      }
    }
  }

  // Het lezen van het logboekblok, met een melding bij elke uitgang.
  //
  // Dit faalde vroeger stil: op moddies werd er niets gelogd en was er niets
  // te zien waaraan je kon aflezen wáárom. Een stille mislukking in een
  // functie die "af en toe niets doen" als normaal gedrag heeft, is niet te
  // onderscheiden van werken.
  function leesLogboek(adapter, target) {
    if (!feature('logbook')) return null;
    if (target === 'persona' && !feature('personaLogbook')) return null;
    const wat = target === 'persona' ? 'eigen dossier' : 'logboek';

    if (!adapter.getLogbook) {
      console.log(`[ChatAssistant] ${wat}: dit platform heeft er geen`);
      return null;
    }

    const book = adapter.getLogbook(target);
    if (!book) {
      // Voor het persona-dossier is dit geen probleem maar de normale gang van
      // zaken op platforms waar we het nog niet gemeten hebben.
      if (target === 'persona') {
        console.log('[ChatAssistant] eigen dossier: niet beschikbaar hier');
        return null;
      }
      console.warn(
        '[ChatAssistant] logboek: blok niet gevonden op de pagina. Staat het ' +
          'dichtgeklapt, of heeft de site zijn opmaak veranderd?'
      );
      return null;
    }
    if (!book.categories || !book.categories.length) {
      console.warn(
        `[ChatAssistant] ${wat}: geen categorieën in de keuzelijst — er valt ` +
          'niets te kiezen, dus er wordt niets gelogd'
      );
      return null;
    }

    console.log(
      `[ChatAssistant] ${wat}: ${book.categories.length} categorie(ën), ` +
        `${(book.existing || []).length} bestaande regel(s)`
    );
    return book;
  }

  // De feiten komen nu mee uit dezelfde API-call als het bericht — zie
  // parseCombined in src/logbook.js. Deze functie doet dus alleen nog het
  // filteren en wegschrijven; er wordt hier niets meer opgehaald.
  async function runLogbook(adapter, book, voorgesteld, target) {
    if (!book) return;
    const wat = target === 'persona' ? 'eigen dossier' : 'logboek';

    // Het model is gevraagd terughoudend te zijn; deze laag dwingt het af.
    const entries = CA.logbook.selectEntries(voorgesteld, {
      categories: book.categories,
      existing: book.existing || [],
    });
    // Zichtbaar in de console hoeveel er is voorgesteld en hoeveel er is
    // overgebleven. Zonder dit is een gemiste categorie niet te verklaren.
    const aantalVoorgesteld = (voorgesteld || []).length;
    if (!aantalVoorgesteld && !entries.length) return;
    console.log(
      `[ChatAssistant] ${wat}: ${aantalVoorgesteld} voorgesteld, ` +
        `${entries.length} na filtering`
    );
    if (!entries.length) {
      // Voorgesteld maar niets overgebleven betekent iets anders dan niets
      // voorgesteld: dan wees het model categorieën aan die dit platform niet
      // kent, of stond het al in het dossier.
      if (aantalVoorgesteld) {
        console.warn(
          `[ChatAssistant] ${wat}: alles viel af bij het filteren. Voorstellen ` +
            'waren:',
          voorgesteld
        );
      }
      return;
    }

    if (countdown) {
      logbookQueue.push({ adapter, entries, target });
      return;
    }
    await submitLogbook(adapter, entries, target);
  }

  // Klant- en persona-dossier ACHTER ELKAAR, nooit tegelijk.
  //
  // Beide schrijven in een formulier en drukken op een opslaanknop, met een
  // wachttijd ertussen omdat het formulier na het posten geleegd wordt. Op
  // OperatorPanel staan die twee formulieren op dezelfde pagina; parallel
  // draaien zou betekenen dat de ene op opslaan drukt terwijl de andere nog
  // aan het invullen is.
  function startLogbook(adapter, book, voorgesteld, eigenBook, eigenVoorgesteld) {
    (async () => {
      await runLogbook(adapter, book, voorgesteld, 'customer');
      await runLogbook(adapter, eigenBook, eigenVoorgesteld, 'persona');
    })().catch((e) => console.warn('[ChatAssistant] logboek', e));
  }

  // ---- genereren ------------------------------------------------------------

  async function generate(adapter) {
    if (busy) return;
    busy = true;
    cancelCountdown(null);
    hidePanel();
    if (manualBtn) manualBtn.disabled = true;
    setStatus('Bezig…', false, false);

    try {
      if (!extensionAlive()) {
        stopEverything('Extensie is herladen — ververs deze pagina (F5)');
        return;
      }

      const context = adapter.getContext();
      if (!context) {
        setStatus('Kon pagina niet lezen', true, true);
        return;
      }
      if (!context.operatorName) {
        setStatus('Account niet herkend', true, true);
        return;
      }

      const extra = context.extra || {};

      // Het logboek wordt nu vóór de generatie gelezen, niet erna. De
      // categorieën gaan mee in dezelfde API-call die het bericht schrijft,
      // zodat het gesprek maar één keer betaald hoeft te worden in plaats van
      // twee keer. Zie parseCombined in src/logbook.js.
      const book = leesLogboek(adapter, 'customer');

      // Het eigen dossier van de persona. Twee dingen tegelijk: het model
      // krijgt te lezen wat er al over haar verzonnen is (anders heeft ze in
      // elk gesprek een ander beroep), en als het leeg is wordt het gevuld.
      const eigenBook = leesLogboek(adapter, 'persona');

      // DE GEKLEURDE BALK: PLAFOND MAAL BALK
      //
      // De adapter zegt of het platform het ooit toestaat; de balk zegt of het
      // nu mag. Twee lagen, en beide moeten ja zeggen.
      //
      // Die volgorde is met opzet: wordt de balk niet gevonden, of verandert
      // de site zijn opmaak, dan geeft src/stage.js de strengste stand terug
      // en is het resultaat gelijk aan hoe de extensie zich hiervóór gedroeg.
      // Een gemiste kleur kan dus nooit ineens afspreken toestaan.
      const stage = feature('stageColours')
        ? CA.stage.policyFor(context.stageColour)
        : CA.stage.STRENGST;
      // Twee aparte vragen, want het zijn twee regels. Een echte afspraak
      // voorstellen mag nergens; contactgegevens mogen alleen bij blauw, en
      // dan gemaskeerd.
      const mayContact =
        adapter.allowsContactOrDates === true && stage.allowsContactDetails === true;
      const mayProposeDate =
        adapter.allowsContactOrDates === true && stage.allowsDateProposal === true;

      const payload = {
        platform: adapter.id,
        // Platformregel, geen voorkeur: zie de adapter.
        allowsEmoji: adapter.allowsEmoji !== false,
        allowsContactDetails: mayContact,
        allowsDateProposal: mayProposeDate,
        // Mag de persona zélf over seks beginnen, of alleen meegaan als de
        // klant erover begint? Bij een nieuwe klant (geel) is dat laatste de
        // regel van het bureau.
        allowsSexInitiative: stage.allowsSexInitiative === true,
        masksContactDetails: stage.masksContactDetails === true,
        stageLabel: stage.label,
        // Zonder dit wordt het model afgerekend op een lengteregel die het
        // nooit heeft gekregen — dat was precies de fout.
        limits: {
          minChars: typeof extra.minChars === 'number' ? extra.minChars : null,
          maxChars: typeof extra.maxChars === 'number' ? extra.maxChars : null,
        },
        operatorName: context.operatorName,
        conversationId: context.conversationId,
        messages: adapter.getMessages(),
        customer: adapter.getCustomer(),
        persona: adapter.getPersona(),
        attachments: adapter.getAttachments(),
        attachmentsLoaded: context.attachmentsLoaded,
        // Null op een platform zonder logboek; dan vraagt de prompt er ook
        // niet om en blijft het antwoord gewone tekst.
        logbook: book
          ? { categories: book.categories, existing: book.existing || [] }
          : null,
        personaLogbook: eigenBook
          ? { categories: eigenBook.categories, existing: eigenBook.existing || [] }
          : null,
      };

      const response = await chrome.runtime.sendMessage({
        type: 'generate-reply',
        payload,
      });

      if (!response || response.error) {
        setStatus('Fout: ' + ((response && response.error) || 'onbekend'), true, true);
        return;
      }

      // Klaarzetten voor het geheugen. Het wordt pas echt onthouden als dit
      // bericht ook verstuurd wordt — een voorstel dat jij weggooit hoort
      // geen voorbeeld te worden voor de volgende keer.
      laatsteGeneratie = {
        operatorName: context.operatorName,
        text: response.text,
        attempts: response.attempts,
      };

      // Mag er op dit platform niet in het veld geschreven worden, dan komt
      // het voorstel in het paneel ernaast en typ jij het zelf over.
      if (adapter.allowsDraftInsert === false) {
        showPanel(response.text);
        if (response.blocked && response.blocked.length) {
          setStatus('LET OP — verboden: ' + response.blocked.join(', '), true, true);
      } else if (response.dateOrContact) {
        setStatus('LET OP — stelt een afspraak voor', true, true);
        } else {
          setStatus(`Voorstel klaar (${context.operatorName}) — typ het zelf over`, false, true);
        }
        startLogbook(
          adapter,
          book,
          response.logbookEntries,
          eigenBook,
          response.personaLogbookEntries
        );
        return;
      }

      const written = adapter.setDraft(response.text);
      if (!written) {
        // Niet kunnen schrijven mag niet betekenen dat je met lege handen
        // staat. Het voorstel is al gemaakt en betaald; het paneel is precies
        // waarvoor het bedoeld is.
        //
        // Dit is ook het vangnet voor ChatHomeBase: weigert die site de
        // ingevoegde tekst alsnog, dan zie je het voorstel gewoon naast de
        // chat in plaats van een foutmelding en niets.
        showPanel(response.text);
        setStatus(
          'Kon niet in het veld schrijven — typ het over uit het paneel',
          true,
          true
        );
        startLogbook(
          adapter,
          book,
          response.logbookEntries,
          eigenBook,
          response.personaLogbookEntries
        );
        return;
      }

      // Na twee herkansingen stond er nog een verboden item in. Het voorstel
      // gaat toch in het veld — jij past het aan — maar de melding moet
      // onmiskenbaar zijn.
      if (response.blocked && response.blocked.length) {
        setStatus('LET OP — verboden: ' + response.blocked.join(', '), true, true);
      } else {
        const lengte = CA.autosend.checkLength(response.text, extra);
        if (!lengte.ok) {
          setStatus(
            lengte.reason === 'lang'
              ? `LET OP — te lang: ${lengte.length} van max. ${lengte.maxChars}`
              : `LET OP — te kort: ${lengte.length} van min. ${lengte.minChars}`,
            true,
            true
          );
        } else {
          setStatus(`Klaar (${context.operatorName}) — Ctrl+Enter verstuurt`, false, true);
        }
      }

      startLogbook(
        adapter,
        book,
        response.logbookEntries,
        eigenBook,
        response.personaLogbookEntries
      );

      // Geen account gevonden betekent: geen persona, geen stijl en geen
      // eigen verboden woorden. Dat mag je niet pas merken aan de inhoud.
      if (response.accountFound === false) {
        setStatus(
          `Let op — '${context.operatorName}' staat niet in de instellingen`,
          true,
          true
        );
      }

      if (currentMode() !== 'full') return;

      const verdict = CA.autosend.canAutoSend({
        adapter,
        context,
        messages: payload.messages,
        reply: response.text,
        blocked: response.blocked || [],
        dateOrContact: !!response.dateOrContact,
      });

      if (!verdict.ok) {
        const say = WEIGERING[verdict.reason];
        setStatus(say ? say(verdict.detail) : 'Niet automatisch verstuurd', true, true);

        // Een foto van de klant kan de robot niet zien, dus hier houdt het
        // voor hem op: er valt niets te herschrijven. Vroeger bleef hij daar
        // staan tot iemand keek — in vol-automatisch dus soms minutenlang.
        //
        // Alleen dít gesprek geven we op, en alleen in vol-automatisch. De
        // verversing pikt het op en gaat door naar het volgende gesprek.
        if (verdict.reason === 'foto') {
          geefOp(context.conversationId);
          console.log(
            '[ChatAssistant] gesprek opgegeven (foto van de klant):',
            context.conversationId
          );
        }
        return;
      }

      startCountdown();
    } catch (e) {
      // Raakt de extensie tussen de controle en de aanroep alsnog los, dan
      // komt dat hier binnen als een TypeError over sendMessage.
      const melding = String((e && e.message) || e);
      if (/sendMessage|context invalidated|chrome\.runtime/i.test(melding)) {
        stopEverything('Extensie is herladen — ververs deze pagina (F5)');
      } else {
        setStatus('Fout: ' + melding, true, true);
      }
    } finally {
      busy = false;
      if (manualBtn) manualBtn.disabled = false;
    }
  }

  // ---- toetsenbord ----------------------------------------------------------

  function onKeyDown(e) {
    if (!e.isTrusted) return;
    if (!currentAdapter) return;

    const input = currentAdapter.getInputElement();
    if (!input || document.activeElement !== input) return;

    // Handmatig versturen wint van de afteller — je hoeft niet te wachten tot
    // hij is uitgelopen als je nu al tevreden bent.
    if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
      cancelCountdown(null);
      e.preventDefault();
      if (send()) setStatus('Verstuurd', false, false);
      return;
    }

    // Losse modificatietoetsen zijn geen "ik ga typen". Zonder deze uitzondering
    // breekt de Ctrl van Ctrl+Enter de afteller af vóór de Enter binnen is.
    if (e.key === 'Control' || e.key === 'Shift' || e.key === 'Alt' || e.key === 'Meta') return;

    // Jij bent gaan typen, dus dit gesprek is niet meer opgegeven. Zonder dit
    // zou de verversing de pagina onder je handen weghalen terwijl je een
    // antwoord op die foto zit te schrijven.
    neemOver(lastContext && lastContext.conversationId);

    // Zelf typen houdt de afteller tegen — het natuurlijkste gebaar om in te
    // grijpen, natuurlijker dan de muis naar Stop bewegen.
    if (countdown) cancelCountdown('Gestopt — jij bent aan zet');
  }

  // ---- opstarten ------------------------------------------------------------

  function attach(adapter) {
    currentAdapter = adapter;
    ensureUI();

    if (activeTrigger) activeTrigger.stop();
    activeTrigger = CA.trigger.createPolling({
      adapter,
      // Een opgegeven gesprek niet nog eens genereren. Zonder deze rem draait
      // de robot na elke verversing opnieuw een API-call op dezelfde foto —
      // dat is de lus die geld kost zonder ooit een bericht op te leveren.
      shouldFire: () =>
        currentMode() !== 'manual' &&
        !busy &&
        !countdown &&
        !isOpgegeven(lastContext && lastContext.conversationId),
      onFire: () => generate(adapter),
      onTick: (ctx) => {
        const vorigGesprek = lastContext && lastContext.conversationId;
        lastContext = ctx;
        renderModeButton();

        // Wisselt de pagina van gesprek terwijl de afteller loopt, dan hoort
        // dat bericht daar niet meer thuis. Op moddies gebeurt dit vanzelf —
        // de doorlaadpagina schuift door — en op OperatorPanel na elke
        // verzending. Zonder deze rem zou de afteller aflopen en op de
        // verzendknop van een ánder gesprek drukken.
        const nuGesprek = ctx && ctx.conversationId;
        if (countdown && nuGesprek !== vorigGesprek) {
          cancelCountdown('Gestopt — ander gesprek geladen');
          return;
        }

        // Het invoerveld verdwenen betekent dat de chatpagina weg is.
        if (countdown && !adapter.getInputElement()) {
          cancelCountdown(null);
          return;
        }

        if (busy || statusIsSticky || countdown) return;
        const name = ctx && ctx.operatorName;

        // De kleur van de balk erbij, zodat je kunt zien wat de robot denkt
        // dat er geldt. Klopt dat niet met wat jij op het scherm ziet, dan
        // weet je dat meteen — in plaats van pas bij een klant die een
        // afspraakvoorstel krijgt dat er niet had mogen zijn.
        const stage = ctx ? CA.stage.policyFor(ctx.stageColour) : null;
        const balk = stage && stage.colour ? ` · ${stage.label}` : '';

        setStatus(
          (name || `${adapter.label} — account onbekend`) + balk,
          !name,
          false
        );
      },
    });
    activeTrigger.start();
  }

  // Op sommige platforms bestaat de chatpagina nog niet wanneer Chrome dit
  // script injecteert. moddies laadt het gesprek pas via AJAX in de
  // doorlaadpagina — op `document_idle` staat daar alleen nog "Almost ready…" —
  // en ChatHomeBase toont "Waiting for conversation to be claimed..." tot er
  // een chat binnenkomt. Eén keer kijken en opgeven betekent dat de extensie
  // op die twee platforms nooit aangaat.
  //
  // Daarom blijven we kijken. Zodra er een adapter past, koppelen we alsnog.
  // Automatisch verversen zolang er geen gesprek op de pagina staat, tot er
  // wel werk is. Staat standaard uit en wordt in de popup aangezet met een
  // interval in seconden.
  //
  // Twee remmen die er bewust in zitten: hij wacht altijd minstens één hele
  // interval na het laden van de pagina, zodat een trage site geen
  // herlaadstorm wordt, en hij ververst niet als er ergens tekst in een veld
  // staat — dan ben jij bezig en zou verversen jouw werk weggooien.
  const TYPEVELDEN = "textarea, input[type=text]";
  let refreshSeconds = 0;
  const paginaGeladenOp = Date.now();

  // De gesprekken waarop de robot is vastgelopen op iets wat hij zelf niet kan
  // oplossen. Zie de weigering hierboven en de toelichting in src/refresh.js.
  //
  // DIT MOET DE VERVERSING OVERLEVEN, ANDERS KOST HET GELD.
  //
  // Na location.reload() is elke variabele in dit bestand weer leeg. Wijst de
  // site daarna hetzelfde gesprek opnieuw toe — en dat is op OperatorPanel het
  // normale geval — dan zou de robot opnieuw genereren, opnieuw weigeren op
  // diezelfde foto, opnieuw verversen: een lus die per ronde een API-call
  // kost en nooit tot een verstuurd bericht leidt.
  //
  // sessionStorage leeft per tabblad en verdwijnt als het tabblad dichtgaat.
  // Dat is precies de juiste levensduur: over een verversing heen, maar niet
  // over een werkdag heen.
  const OPGEGEVEN_KEY = 'chat-assistant-opgegeven';
  const OPGEGEVEN_MAX = 20;

  function opgegevenLijst() {
    try {
      const raw = sessionStorage.getItem(OPGEGEVEN_KEY);
      const lijst = raw ? JSON.parse(raw) : [];
      return Array.isArray(lijst) ? lijst : [];
    } catch (e) {
      // Privacymodus of een kapotte waarde mag de robot niet stilleggen.
      return [];
    }
  }

  function isOpgegeven(id) {
    return !!id && opgegevenLijst().indexOf(String(id)) !== -1;
  }

  function geefOp(id) {
    if (!id) return;
    const lijst = opgegevenLijst().filter((x) => x !== String(id));
    lijst.push(String(id));
    try {
      sessionStorage.setItem(
        OPGEGEVEN_KEY,
        JSON.stringify(lijst.slice(-OPGEGEVEN_MAX))
      );
    } catch (e) {
      /* niet kunnen onthouden is vervelend, niet fataal */
    }
  }

  // Zodra jij het overneemt is het gesprek niet meer opgegeven — anders zou de
  // verversing jouw scherm onder je handen weghalen terwijl je zit te typen.
  function neemOver(id) {
    if (!id) return;
    try {
      sessionStorage.setItem(
        OPGEGEVEN_KEY,
        JSON.stringify(opgegevenLijst().filter((x) => x !== String(id)))
      );
    } catch (e) {
      /* zie boven */
    }
  }

  // Sinds wanneer is er niets meer gebeurd.
  //
  // Was een teller van verversingen; is nu een tijdstempel, omdat de grens
  // niet meer "hoe vaak" maar "hoe lang" is. Zie MAX_IDLE_SECONDS in
  // src/refresh.js.
  //
  // Moet de herlading overleven — anders staat hij na elke verversing weer op
  // nul en stopt er nooit iets.
  const STIL_KEY = 'chat-assistant-stil-sinds';

  function stilSinds() {
    try {
      const opgeslagen = Number(sessionStorage.getItem(STIL_KEY));
      if (opgeslagen) return opgeslagen;
    } catch (e) {
      /* privacymodus */
    }
    return Date.now();
  }

  function markeerStil() {
    try {
      if (!Number(sessionStorage.getItem(STIL_KEY))) {
        sessionStorage.setItem(STIL_KEY, String(Date.now()));
      }
    } catch (e) {
      /* niet kunnen onthouden is vervelend, niet fataal */
    }
  }

  // Er is werk: de stilte is voorbij.
  function resetVerversingen() {
    try {
      sessionStorage.removeItem(STIL_KEY);
    } catch (e) {
      /* zie boven */
    }
  }

  function stilteInSeconden() {
    return (Date.now() - stilSinds()) / 1000;
  }

  function maybeRefresh() {
    const velden = Array.from(document.querySelectorAll(TYPEVELDEN));
    const huidig = lastContext && lastContext.conversationId;

    // Alleen in vol-automatisch. In "klaarzetten" kijk jij mee, en dan mag
    // een verversing jouw scherm niet onder je handen weghalen.
    const vast = isOpgegeven(huidig) && currentMode() === 'full';

    // De feiten verzamelen we hier; het oordeel valt in src/refresh.js,
    // zodat het te testen is zonder browser.
    const heeftGesprek = !!findAdapter();

    // Welk platform dit is, ook als er geen gesprek staat — juist dan speelt
    // het verversen. findAdapter() kan dat niet vertellen, want die vraagt of
    // er een gesprek is. Zie ChatAssistant.adapterForHost in adapters/index.js.
    const platform = CA.adapterForHost(location.hostname);

    // Centraal uitgezet: dan gebeurt er hier niets, ongeacht wat er in de
    // popup staat. Zo kun je het verversen bij één klant stilzetten zonder
    // dat daar iemand iets voor hoeft te doen.
    if (!feature('refresh')) return;

    // Staat er werk, dan is de reeks lege verversingen afgelopen en mag het
    // tempo terug naar wat je hebt ingesteld.
    if (heeftGesprek && !vast) resetVerversingen();

    const mag = CA.refresh.shouldRefresh({
      intervalSeconds: refreshSeconds,
      hasChat: heeftGesprek,
      secondsSinceLoad: (Date.now() - paginaGeladenOp) / 1000,
      hasTypedText: velden.some((el) => el.offsetParent && String(el.value || "").trim()),
      stuckOnChat: vast,
      idleSeconds: stilteInSeconden(),
      siteRefreshesItself: !!(platform && platform.refreshesItself),
    });

    if (!mag) {
      // Gestopt omdat er te lang niets gebeurde. Dat moet je kunnen zien —
      // anders lijkt het alsof de extensie stuk is, en dan gaat er iemand
      // zoeken naar een fout die er niet is.
      if (CA.refresh.uitgeput(stilteInSeconden()) && !statusIsSticky) {
        setStatus(
          `Verversen gestopt — ${Math.round(CA.refresh.MAX_IDLE_SECONDS / 3600)} uur geen werk. Druk op Nu.`,
          false,
          true
        );
      }
      return;
    }

    markeerStil();
    console.log(
      (vast
        ? "[ChatAssistant] vastgelopen op dit gesprek — pagina verversen"
        : "[ChatAssistant] geen gesprek — pagina verversen") +
        ` (${Math.round(stilteInSeconden())}s stil, interval ${CA.refresh.effectiveInterval(refreshSeconds)}s)`
    );
    location.reload();
  }

  const BOOTSTRAP_INTERVAL_MS = 2000;

  function bootstrap() {
    if (!extensionAlive()) {
      stopEverything('Extensie is herladen — ververs deze pagina (F5)');
      return;
    }

    const adapter = findAdapter();

    if (!adapter) {
      // De balk blijft staan, ook zonder gesprek. Anders lijkt het alsof de
      // extensie verdwenen is terwijl hij gewoon staat te wachten — en dan ga
      // je hem herladen terwijl er niets aan de hand is.
      if (currentAdapter) {
        if (activeTrigger) {
          activeTrigger.stop();
          activeTrigger = null;
        }
        currentAdapter = null;
      }

      ensureUI();
      renderModeButton();
      if (manualBtn) manualBtn.disabled = true;
      if (stopBtn) stopBtn.style.display = "none";
      // Een foutmelding niet overschrijven; die moet je kunnen lezen.
      if (!statusIsSticky) setStatus('Wachten op een gesprek…', false, false);

      maybeRefresh();
      return;
    }

    if (manualBtn) manualBtn.disabled = false;

    // Al gekoppeld: alleen nagaan of de statusbalk er nog staat. Een pagina die
    // zichzelf herrendert kan hem weggegooid hebben, en dan is de extensie
    // onzichtbaar terwijl hij gewoon draait.
    if (currentAdapter === adapter) {
      ensureUI();
      return;
    }

    attach(adapter);
  }

  document.addEventListener('keydown', onKeyDown, true);
  bootstrap();
  bootstrapTimer = setInterval(bootstrap, BOOTSTRAP_INTERVAL_MS);
})();
