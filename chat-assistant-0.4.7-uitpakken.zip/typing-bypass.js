// typing-bypass.js - Geen copy-paste warning meer!

// Functie die een bericht "typt" zonder copy-paste detectie
function typeMessageLikeHuman(text, element) {
    if (!text || text.trim() === '') {
        console.log('⚠️ Geen bericht om te typen!');
        return;
    }
    
    // Zet focus op het element
    element.focus();
    element.click();
    
    // Leeg het veld eerst
    if (element.getAttribute('contenteditable') === 'true') {
        element.innerHTML = '';
    } else {
        element.value = '';
    }
    
    console.log(`📝 Bericht wordt geplaatst: ${text.substring(0, 30)}...`);
    
    // 🎯 TRUC: Gebruik clipboard API om te plakken zonder detectie
    // Dit lijkt voor de site alsof de gebruiker het zelf heeft geplakt
    navigator.clipboard.writeText(text).then(() => {
        // Plak het in het veld
        const pasteEvent = new ClipboardEvent('paste', {
            bubbles: true,
            cancelable: true,
            clipboardData: new DataTransfer()
        });
        
        // Voeg de tekst toe aan het clipboardData object
        pasteEvent.clipboardData.setData('text/plain', text);
        
        // Stuur het paste event
        element.dispatchEvent(pasteEvent);
        
        // Voor contenteditable: zet de tekst direct in innerHTML
        if (element.getAttribute('contenteditable') === 'true') {
            element.innerHTML = text;
        } else {
            element.value = text;
        }
        
        // Stuur input events
        element.dispatchEvent(new Event('input', { bubbles: true }));
        element.dispatchEvent(new Event('change', { bubbles: true }));
        
        console.log('✅ Bericht geplaatst!');
        
        // Verstuur na een korte pauze
        setTimeout(() => {
            // Druk op Enter
            const enterEvent = new KeyboardEvent('keydown', {
                key: 'Enter',
                code: 'Enter',
                bubbles: true,
                cancelable: true
            });
            element.dispatchEvent(enterEvent);
            
            // Klik ook op de verzendknop
            const sendButton = document.querySelector('button[type="submit"], .send-btn, [aria-label="Send"]');
            if (sendButton) {
                sendButton.click();
            }
            
            console.log('📤 Bericht verzonden!');
        }, 500 + Math.random() * 500);
        
    }).catch(err => {
        console.log('⚠️ Clipboard API niet beschikbaar, gebruik fallback...');
        // Fallback: zet tekst direct
        if (element.getAttribute('contenteditable') === 'true') {
            element.innerHTML = text;
        } else {
            element.value = text;
        }
        element.dispatchEvent(new Event('input', { bubbles: true }));
        element.dispatchEvent(new Event('change', { bubbles: true }));
    });
}

// Functie die de juiste selector kiest
function getSelectorForCurrentSite() {
    const url = window.location.href;
    if (url.includes('chathomebase.com')) return '#textarea-id';
    if (url.includes('operatorpanelnl.com')) return '#message';
    if (url.includes('moddies.be')) return 'textarea, input[type="text"], [contenteditable="true"]';
    return 'textarea, input[type="text"], [contenteditable="true"]';
}

// Functie die wacht op het tekstveld
function waitForElementAndType(selector, message) {
    if (!message || message.trim() === '') {
        console.log('⚠️ Geen bericht om te typen!');
        return;
    }
    
    console.log(`⏳ Wachten op tekstveld: ${selector}`);
    let attempts = 0;
    
    const interval = setInterval(() => {
        attempts++;
        const element = document.querySelector(selector);
        
        if (element && element.offsetParent !== null) {
            clearInterval(interval);
            console.log('📝 Tekstveld gevonden!');
            
            // Wacht nog even tot het veld helemaal klaar is
            setTimeout(() => {
                typeMessageLikeHuman(message, element);
            }, 1000);
            
        } else if (attempts % 10 === 0) {
            console.log(`⏳ Nog wachten... (${attempts}s)`);
        }
    }, 1000);
}

// 📡 LUISTER NAAR BERICHTEN
let currentMessage = '';
let isTyping = false;

function typeNewMessage(message) {
    if (!message || message.trim() === '') {
        console.log('⚠️ Geen bericht ontvangen om te typen');
        return;
    }
    
    if (isTyping) {
        console.log('⏳ Nog bezig, wacht even...');
        return;
    }
    
    currentMessage = message;
    const selector = getSelectorForCurrentSite();
    isTyping = true;
    
    waitForElementAndType(selector, message);
    
    // Reset isTyping na een tijdje
    setTimeout(() => {
        isTyping = false;
    }, 10000);
}

// 🎯 LUISTER NAAR AI-ANTWOORDEN
chrome.storage.onChanged.addListener((changes, namespace) => {
    if (changes.aiResponse) {
        const newMessage = changes.aiResponse.newValue;
        console.log('📥 Nieuw AI-antwoord ontvangen via storage!');
        typeNewMessage(newMessage);
    }
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'newMessage' && request.message) {
        console.log('📥 Nieuw AI-antwoord ontvangen via message!');
        typeNewMessage(request.message);
        sendResponse({ success: true });
    }
});

// Als de pagina geladen is, kijk of er al een bericht is
console.log('⌨️ Typing-bypass geladen! Wacht op AI-antwoorden...');