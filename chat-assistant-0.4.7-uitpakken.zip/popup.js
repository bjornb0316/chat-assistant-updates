const accountsEl = document.getElementById('accounts');

function escapeHtml(s) {
  return String(s).replace(
    /[&<>"']/g,
    (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])
  );
}

function accountRow(operatorName, data) {
  data = data || {};
  const wrap = document.createElement('div');
  wrap.className = 'account';
  wrap.innerHTML = `
    <label>Operatornaam (exact zoals op de pagina)</label>
    <input class="op-name" value="${escapeHtml(operatorName || '')}" placeholder="bijv. gebruikersnaam1">

    <label>Modus</label>
    <select class="op-mode">
      <option value="manual" ${data.mode === 'manual' ? 'selected' : ''}>Volledig handmatig — alleen de Nu-knop</option>
      <option value="draft" ${!data.mode || data.mode === 'draft' ? 'selected' : ''}>Alleen klaarzetten — jij verstuurt</option>
      <option value="full" ${data.mode === 'full' ? 'selected' : ''}>Full auto — verstuurt zelf na 12 seconden</option>
    </select>

    <label>Taal</label>
    <select class="op-lang">
      ${['NL', 'EN', 'DE', 'SV', 'NO', 'ES']
        .map((l) => `<option value="${l}" ${data.language === l ? 'selected' : ''}>${l}</option>`)
        .join('')}
    </select>

    <label>Stijl / toon (vrije tekst)</label>
    <textarea class="op-style" placeholder="bijv. speels, korte zinnen, veel vragen terug">${escapeHtml(data.styleNotes || '')}</textarea>

    <label>Toegestane emoji (spatie-gescheiden)</label>
    <input class="op-emoji-allow" value="${escapeHtml((data.emojiAllow || []).join(' '))}">

    <label>Verboden emoji (spatie-gescheiden)</label>
    <input class="op-emoji-block" value="${escapeHtml((data.emojiBlock || []).join(' '))}">

    <label>Afkortingen (komma-gescheiden)</label>
    <input class="op-abbrev" value="${escapeHtml((data.abbreviations || []).join(', '))}">

    <label>Verboden woorden en zinnen — alleen dit account (één per regel)</label>
    <textarea class="op-blocklist blocklist">${escapeHtml((data.blocklist || []).join('\n'))}</textarea>

    <button type="button" class="op-remove danger">Verwijderen</button>
  `;
  wrap.querySelector('.op-remove').addEventListener('click', () => wrap.remove());
  accountsEl.appendChild(wrap);
  return wrap;
}

function collectAccounts(overgeslagen) {
  const out = {};
  accountsEl.querySelectorAll('.account').forEach((wrap) => {
    const name = wrap.querySelector('.op-name').value.trim();
    if (!name) {
      // Een rij zonder operatornaam kan nergens aan gekoppeld worden. Vroeger
      // verdween zo'n rij stil, inclusief de verboden woorden die erin stonden.
      // Nu melden we het, want dat kost anders uren zoeken.
      const inhoud = [
        wrap.querySelector('.op-style').value,
        wrap.querySelector('.op-blocklist').value,
        wrap.querySelector('.op-emoji-allow').value,
        wrap.querySelector('.op-emoji-block').value,
        wrap.querySelector('.op-abbrev').value,
      ].some((v) => String(v || "").trim());
      if (inhoud && overgeslagen) overgeslagen.push(wrap);
      return;
    }
    out[name] = {
      // manual = niets vanzelf, draft = klaarzetten, full = ook verzenden.
      // Op een platform waarvan de adapter verzenden niet toestaat zakt full
      // vanzelf terug naar draft — zie src/autosend.js.
      mode: wrap.querySelector('.op-mode').value,
      language: wrap.querySelector('.op-lang').value,
      styleNotes: wrap.querySelector('.op-style').value.trim(),
      emojiAllow: wrap.querySelector('.op-emoji-allow').value.trim().split(/\s+/).filter(Boolean),
      emojiBlock: wrap.querySelector('.op-emoji-block').value.trim().split(/\s+/).filter(Boolean),
      abbreviations: wrap
        .querySelector('.op-abbrev')
        .value.split(',')
        .map((s) => s.trim())
        .filter(Boolean),
      // Eén per regel, niet komma-gescheiden — anders kun je geen zin met een
      // komma erin verbieden.
      blocklist: ChatAssistant.blocklist.parse(wrap.querySelector('.op-blocklist').value),
    };
  });
  return out;
}

document.getElementById('addAccount').addEventListener('click', () => accountRow('', {}));

document.getElementById('save').addEventListener('click', async () => {
  const apiKey = document.getElementById('apiKey').value.trim();
  const model = document.getElementById('model').value;
  const overgeslagen = [];
  const accounts = collectAccounts(overgeslagen);
  // Alleen een bodem van 5 seconden, geen beleidsgrens. Zie src/refresh.js:
  // onder de 5 is het geen verversen meer maar een lus.
  const ingevuld = Number(document.getElementById('refreshSeconds').value) || 0;
  const refreshSeconds = ingevuld > 0 ? Math.max(ingevuld, 5) : 0;
  document.getElementById('refreshSeconds').value = refreshSeconds;
  const globalBlocklist = ChatAssistant.blocklist.parse(
    document.getElementById('globalBlocklist').value
  );
  // Het adres en de identificatie horen bij deze installatie en gaan dus in
  // dezelfde lokale opslag als de rest.
  const configEndpoint = document.getElementById('configEndpoint').value.trim();
  const customerId = document.getElementById('customerId').value.trim();
  const licenseKey = document.getElementById('licenseKey').value.trim();

  await chrome.storage.local.set({
    apiKey,
    model,
    accounts,
    globalBlocklist,
    refreshSeconds,
    configEndpoint,
    customerId,
    licenseKey,
  });
  const status = document.getElementById('status');
  if (overgeslagen.length) {
    status.textContent =
      'Opgeslagen — maar ' +
      overgeslagen.length +
      ' ingevulde rij(en) zijn NIET bewaard omdat de operatornaam leeg is.';
    status.style.color = '#b91c1c';
    return;
  }
  status.style.color = '';
  status.textContent = 'Opgeslagen.';
  setTimeout(() => {
    status.textContent = '';
  }, 2000);
});

(async function init() {
  const stored = await chrome.storage.local.get([
    'apiKey',
    'model',
    'accounts',
    'globalBlocklist',
    'refreshSeconds',
    'configEndpoint',
    'customerId',
    'licenseKey',
    'remoteConfig',
    'remoteConfigMeta',
    'installationId',
  ]);
  if (stored.apiKey) document.getElementById('apiKey').value = stored.apiKey;
  // Een opgeslagen model dat niet meer in de lijst staat — Opus 5 is er op
  // 19-08-2026 uit gehaald. Zonder deze controle toont het uitklapmenu de
  // eerste optie terwijl er iets anders opgeslagen staat, en dan denk je dat je
  // op Sonnet draait terwijl de rekening Opus zegt.
  const modelEl = document.getElementById('model');
  const toegestaan = Array.from(modelEl.options).map((o) => o.value);
  if (stored.model && toegestaan.indexOf(stored.model) !== -1) {
    modelEl.value = stored.model;
  } else if (stored.model) {
    modelEl.value = toegestaan[0];
    const melding = document.getElementById('status');
    if (melding) {
      melding.textContent =
        `Let op — "${stored.model}" wordt niet meer gebruikt. Er staat nu ` +
        `${toegestaan[0]}; klik Opslaan om dat vast te leggen.`;
      melding.style.color = '#b45309';
    }
  }
  document.getElementById('refreshSeconds').value = stored.refreshSeconds || 0;
  document.getElementById('configEndpoint').value = stored.configEndpoint || '';
  document.getElementById('customerId').value = stored.customerId || '';
  document.getElementById('licenseKey').value = stored.licenseKey || '';
  toonConfigStand(stored);
  document.getElementById('globalBlocklist').value = (stored.globalBlocklist || []).join('\n');

  const accounts = stored.accounts || {};
  const names = Object.keys(accounts);
  if (names.length === 0) {
    // Startpunt: 3 lege rijen, want de werkwijze is 3 accounts tegelijk.
    accountRow('', {});
    accountRow('', {});
    accountRow('', {});
  } else {
    names.forEach((n) => accountRow(n, accounts[n]));
  }
})();


// ---- centrale configuratie -------------------------------------------------

// Laat zien wat er nu geldt. Zonder dit is "werkt het?" niet te beantwoorden
// zonder de console open te trekken, en dat gaat een klant niet doen.
function toonConfigStand(stored) {
  const el = document.getElementById('configStatus');
  if (!el) return;

  const meta = stored.remoteConfigMeta || {};
  const versie = stored.remoteConfig ? stored.remoteConfig.configVersion : null;
  const installatie = stored.installationId ? stored.installationId.slice(0, 8) : '—';

  if (!stored.configEndpoint) {
    el.textContent = `Geen adres ingesteld — ingebouwde instellingen. Installatie ${installatie}`;
    return;
  }
  if (versie === null || versie === undefined) {
    el.textContent = `Nog niets opgehaald. Installatie ${installatie}`;
    return;
  }
  const wanneer = meta.fetchedAt ? new Date(meta.fetchedAt).toLocaleString('nl-NL') : 'onbekend';
  el.textContent = `Config v${versie}, opgehaald ${wanneer}. Installatie ${installatie}`;
}

const refreshBtn = document.getElementById('refreshConfig');
if (refreshBtn) {
  refreshBtn.addEventListener('click', async () => {
    const el = document.getElementById('configStatus');
    refreshBtn.disabled = true;
    if (el) el.textContent = 'Bezig…';

    try {
      // Eerst opslaan, anders haalt hij op met het oude adres.
      await chrome.storage.local.set({
        configEndpoint: document.getElementById('configEndpoint').value.trim(),
        customerId: document.getElementById('customerId').value.trim(),
        licenseKey: document.getElementById('licenseKey').value.trim(),
      });

      const r = await chrome.runtime.sendMessage({ type: 'refresh-config' });
      const uitleg = {
        updated: 'Bijgewerkt',
        unchanged: 'Ongewijzigd',
        cached: 'Nog vers, niets opgehaald',
        offline: 'Backend onbereikbaar — opgeslagen config blijft gelden',
        invalid: 'Ongeldig antwoord — opgeslagen config blijft gelden',
        incompatible: 'Extensie is te oud voor deze config',
        'not-configured': 'Geen adres ingesteld',
        error: 'Fout',
      };
      const tekst = uitleg[r && r.status] || 'Onbekend';
      const versie = r && r.config ? r.config.configVersion : null;
      if (el) el.textContent = versie !== null ? `${tekst} (v${versie})` : tekst;
    } catch (e) {
      if (el) el.textContent = 'Fout: ' + ((e && e.message) || e);
    } finally {
      refreshBtn.disabled = false;
    }
  });
}
