// Dit is de basis stealth-laag - vervalst de makkelijkste signalen

// 1. Zet webdriver op false (belangrijkste vlag!)
Object.defineProperty(navigator, 'webdriver', {
    get: () => false
});

// 2. Vervals het aantal CPU-cores (normale PC heeft 4-16)
Object.defineProperty(navigator, 'hardwareConcurrency', {
    get: () => 8
});

// 3. Vervals het geheugen (normale PC heeft 4-8 GB)
Object.defineProperty(navigator, 'deviceMemory', {
    get: () => 8
});

// 4. Zorg dat plugins er normaal uitzien
Object.defineProperty(navigator, 'plugins', {
    get: () => {
        return {
            length: 5,
            item: () => null,
            namedItem: () => null,
            refresh: () => {}
        };
    }
});

// 5. Zorg dat mimeTypes er normaal uitzien
Object.defineProperty(navigator, 'mimeTypes', {
    get: () => {
        return {
            length: 4,
            item: () => null,
            namedItem: () => null
        };
    }
});

console.log('🛡️ Stealth-laag geladen!');
