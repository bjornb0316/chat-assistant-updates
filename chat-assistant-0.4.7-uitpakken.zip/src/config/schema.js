// Valideert en versmelt remote configuratie. Puur: object in, object uit —
// geen netwerk, geen opslag, geen DOM. Daarom los te testen.
//
// REMOTE DATA IS ONBETROUWBARE INVOER.
//
// Wat hier binnenkomt is over het net gekomen en kan van alles zijn: een
// verkeerd type, een negatief getal, een array waar een string hoort, of een
// antwoord van een proxy die een foutpagina teruggaf. Niets wordt daarom
// overgenomen omdat het er is; alles wordt overgenomen omdat het klopt.
//
// De regel bij twijfel: de ingebouwde standaard wint. Een veld dat niet
// valideert wordt genegeerd, niet gerepareerd — half toegepaste config is
// erger dan geen config, want dan weet je niet meer wat er geldt.

(function (root) {
  'use strict';

  root.ChatAssistant = root.ChatAssistant || {};

  // ---- kleine typewachters -------------------------------------------------

  function isPlainObject(v) {
    return !!v && typeof v === 'object' && !Array.isArray(v);
  }

  function num(value, fallback, min, max) {
    const n = Number(value);
    if (!Number.isFinite(n)) return fallback;
    if (typeof min === 'number' && n < min) return fallback;
    if (typeof max === 'number' && n > max) return fallback;
    return n;
  }

  function bool(value, fallback) {
    return typeof value === 'boolean' ? value : fallback;
  }

  function str(value, fallback, maxLength) {
    if (typeof value !== 'string') return fallback;
    const s = value.trim();
    if (!s) return fallback;
    if (maxLength && s.length > maxLength) return fallback;
    return s;
  }

  // Een lijst korte teksten. Alles wat geen bruikbare string is valt eruit in
  // plaats van dat de hele lijst sneuvelt — één rotte regel mag de andere
  // negentien niet meeslepen.
  const MAX_LIST_ITEMS = 500;
  const MAX_ITEM_CHARS = 300;

  function stringList(value, fallback) {
    if (!Array.isArray(value)) return fallback;
    const out = [];
    for (const item of value) {
      if (typeof item !== 'string') continue;
      const s = item.trim();
      if (!s || s.length > MAX_ITEM_CHARS) continue;
      out.push(s);
      if (out.length >= MAX_LIST_ITEMS) break;
    }
    return out;
  }

  // ---- versievergelijking --------------------------------------------------
  //
  // "1.2.10" hoort nieuwer te zijn dan "1.2.9", en dat gaat mis zodra je
  // strings vergelijkt. Ontbrekende delen tellen als 0, zodat "1.2" en "1.2.0"
  // gelijk zijn.
  function parseVersion(value) {
    const delen = String(value == null ? '' : value)
      .trim()
      .split('.')
      .map((d) => parseInt(d, 10));
    if (!delen.length || delen.some((d) => !Number.isFinite(d) || d < 0)) return null;
    return delen;
  }

  // -1 als a ouder is, 0 gelijk, 1 als a nieuwer is. null bij onleesbaar.
  function compareVersions(a, b) {
    const va = parseVersion(a);
    const vb = parseVersion(b);
    if (!va || !vb) return null;
    const lengte = Math.max(va.length, vb.length);
    for (let i = 0; i < lengte; i++) {
      const x = va[i] || 0;
      const y = vb[i] || 0;
      if (x < y) return -1;
      if (x > y) return 1;
    }
    return 0;
  }

  // Is deze extensie nieuw genoeg voor deze config?
  //
  // Onleesbare versies laten we door. Een backend die onzin stuurt mag de
  // extensie niet uitschakelen — dat zou van een tikfout een storing maken.
  function meetsMinimumVersion(extensionVersion, minimumVersion) {
    if (minimumVersion == null || minimumVersion === '') return true;
    const uitkomst = compareVersions(extensionVersion, minimumVersion);
    if (uitkomst === null) return true;
    return uitkomst >= 0;
  }

  // ---- validatie -----------------------------------------------------------
  //
  // Geeft { config, problems } terug. `problems` is voor de logging: welke
  // velden zijn genegeerd en waarom. Een lege lijst betekent dat alles wat
  // meekwam ook is toegepast.
  function validate(remote, defaults) {
    const d = defaults || root.ChatAssistant.configDefaults;
    const problems = [];

    if (!isPlainObject(remote)) {
      return { config: d, problems: ['config is geen object — genegeerd'] };
    }

    function tak(naam) {
      if (remote[naam] === undefined) return {};
      if (!isPlainObject(remote[naam])) {
        problems.push(`${naam} is geen object — genegeerd`);
        return {};
      }
      return remote[naam];
    }

    const ai = tak('ai');
    const limits = tak('limits');
    const timings = tak('timings');
    const style = tak('style');
    const logbook = tak('logbook');
    const memory = tak('memory');
    const features = tak('features');
    const ui = tak('ui');
    const customer = tak('customer');
    const assistant = tak('assistant');

    // Onderhoud mag als object (`{enabled, message}`) of als kale boolean
    // (`"maintenance": false`). Die tweede vorm staat in de documentatie van
    // de backend, en een validator die de eigen documentatie afkeurt is een
    // validator die niemand vertrouwt.
    const maintenance =
      typeof remote.maintenance === 'boolean'
        ? { enabled: remote.maintenance }
        : tak('maintenance');

    // Modellen: de backend mag kiezen uit wat deze extensie kent, niet
    // daarbuiten. Een onbekend model zou elke call laten falen, en dan staat
    // de wachtrij stil door een tikfout in een dashboard.
    const allowedModels = stringList(ai.allowedModels, d.ai.allowedModels);
    let model = str(ai.model, d.ai.model);
    if (allowedModels.indexOf(model) === -1) {
      problems.push(`model "${model}" staat niet in allowedModels — standaard gebruikt`);
      model = d.ai.model;
    }

    const perPlatform = {};
    if (isPlainObject(limits.perPlatform)) {
      for (const key of Object.keys(limits.perPlatform)) {
        const p = limits.perPlatform[key];
        if (!isPlainObject(p)) continue;
        const min = num(p.minChars, null, 1, 100000);
        const max = num(p.maxChars, null, 1, 100000);
        // Een ondergrens boven de bovengrens is geen strenge instelling maar
        // een bericht dat nooit door de controle komt.
        if (min !== null && max !== null && min > max) {
          problems.push(`limits.perPlatform.${key}: minChars > maxChars — genegeerd`);
          continue;
        }
        perPlatform[key] = { minChars: min, maxChars: max };
      }
    }

    const config = {
      configVersion: num(remote.configVersion, d.configVersion, 0),
      minimumExtensionVersion: str(
        remote.minimumExtensionVersion,
        d.minimumExtensionVersion,
        32
      ),

      customer: {
        id: str(customer.id, d.customer.id, 128),
        name: str(customer.name, d.customer.name, 128),
      },

      assistant: { name: str(assistant.name, d.assistant.name, 128) },

      ai: {
        model,
        allowedModels,
        maxAttempts: num(ai.maxAttempts, d.ai.maxAttempts, 1, 5),
        replyMaxTokens: num(ai.replyMaxTokens, d.ai.replyMaxTokens, 256, 8192),
        replyWithLogbookMaxTokens: num(
          ai.replyWithLogbookMaxTokens,
          d.ai.replyWithLogbookMaxTokens,
          256,
          8192
        ),
      },

      limits: {
        minChars: num(limits.minChars, d.limits.minChars, 1, 100000),
        maxChars: num(limits.maxChars, d.limits.maxChars, 1, 100000),
        perPlatform,
      },

      timings: {
        countdownSeconds: num(timings.countdownSeconds, d.timings.countdownSeconds, 3, 300),
        refreshMinSeconds: num(timings.refreshMinSeconds, d.timings.refreshMinSeconds, 1, 3600),
        refreshMaxIdleSeconds: num(
          timings.refreshMaxIdleSeconds,
          d.timings.refreshMaxIdleSeconds,
          60,
          86400
        ),
        logbookGapMs: num(timings.logbookGapMs, d.timings.logbookGapMs, 100, 10000),
      },

      // null betekent "gebruik de ingebouwde lijst". Een lege array betekent
      // iets anders: die regel staat uit. Dat onderscheid moet blijven.
      style: {
        cliches: style.cliches === undefined ? d.style.cliches : stringList(style.cliches, d.style.cliches),
        promises: style.promises === undefined ? d.style.promises : stringList(style.promises, d.style.promises),
        hedges: style.hedges === undefined ? d.style.hedges : stringList(style.hedges, d.style.hedges),
        greetings: style.greetings === undefined ? d.style.greetings : stringList(style.greetings, d.style.greetings),
        extraBlocklist: stringList(style.extraBlocklist, d.style.extraBlocklist),
      },

      logbook: {
        maxPerRun: num(logbook.maxPerRun, d.logbook.maxPerRun, 1, 50),
        maxChars: num(logbook.maxChars, d.logbook.maxChars, 20, 2000),
        personaMinEntries: num(logbook.personaMinEntries, d.logbook.personaMinEntries, 0, 100),
        priorityCategories: stringList(logbook.priorityCategories, d.logbook.priorityCategories),
      },

      memory: {
        maxExamples: num(memory.maxExamples, d.memory.maxExamples, 0, 50),
        maxOpenings: num(memory.maxOpenings, d.memory.maxOpenings, 0, 50),
        examplesInPrompt: num(memory.examplesInPrompt, d.memory.examplesInPrompt, 0, 50),
        openingsInPrompt: num(memory.openingsInPrompt, d.memory.openingsInPrompt, 0, 50),
      },

      features: {
        autoSend: bool(features.autoSend, d.features.autoSend),
        logbook: bool(features.logbook, d.features.logbook),
        personaLogbook: bool(features.personaLogbook, d.features.personaLogbook),
        memory: bool(features.memory, d.features.memory),
        refresh: bool(features.refresh, d.features.refresh),
        stageColours: bool(features.stageColours, d.features.stageColours),
      },

      ui: {
        showModeButton: bool(ui.showModeButton, d.ui.showModeButton),
        showManualButton: bool(ui.showManualButton, d.ui.showManualButton),
        texts: isPlainObject(ui.texts) ? teksten(ui.texts) : d.ui.texts,
      },

      maintenance: {
        enabled: bool(maintenance.enabled, d.maintenance.enabled),
        message: str(maintenance.message, d.maintenance.message, 500) || '',
      },
    };

    return { config, problems };
  }

  // UI-teksten: alleen platte strings, en niet te lang. Wat hier in komt
  // belandt in een statusbalk, dus het moet passen en het mag geen HTML zijn —
  // vandaar dat het via textContent gezet wordt en niet via innerHTML.
  function teksten(bron) {
    const out = {};
    for (const key of Object.keys(bron)) {
      const waarde = str(bron[key], null, 300);
      if (waarde !== null) out[key] = waarde;
    }
    return out;
  }

  root.ChatAssistant.configSchema = {
    validate,
    compareVersions,
    meetsMinimumVersion,
    parseVersion,
  };
})(typeof globalThis !== 'undefined' ? globalThis : self);
