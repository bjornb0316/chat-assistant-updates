// De configuratie die in het pakket zit. Eén plek voor alles wat centraal
// bijgestuurd kan worden, en tegelijk het vangnet als de backend onbereikbaar
// is: zonder netwerk draait de extensie hierop verder.
//
// WAT HIER WEL EN NIET IN HOORT
//
// Wel: getallen, teksten, woordenlijsten, aan/uit-schakelaars. Dingen die je
// wilt kunnen wijzigen zonder een nieuwe extensie uit te rollen.
//
// Niet: uitvoerbare code. Chrome Manifest V3 verbiedt het uitvoeren van
// op afstand opgehaalde JavaScript, en dat is hier ook niet nodig — de logica
// zit in de modules, deze laag stuurt alleen hun gedrag.
//
// Niet: platformkennis. Selectors en de vraag of een site emoji toestaat zijn
// eigenschappen van die site, geen klantinstelling. Die blijven in de adapters
// staan; zie docs/02-ADAPTER-CONTRACT.md.
//
// Niet: geheimen. De API-sleutel blijft lokaal in chrome.storage en gaat nooit
// naar of via de config-backend.

(function (root) {
  'use strict';

  root.ChatAssistant = root.ChatAssistant || {};

  root.ChatAssistant.configDefaults = {
    // 0 betekent "nog nooit iets van de backend gehad". De backend telt op.
    configVersion: 0,
    // Onder deze extensieversie weigert de config zichzelf toe te passen.
    minimumExtensionVersion: '0.0.0',

    customer: { id: null, name: null },

    assistant: { name: 'Chat Assistant' },

    ai: {
      model: 'claude-sonnet-5',
      // Welke modellen deze extensie überhaupt mag gebruiken. Ook als de
      // backend iets anders stuurt, moet het hierin staan.
      allowedModels: ['claude-sonnet-5', 'claude-haiku-4-5'],
      maxAttempts: 3,
      replyMaxTokens: 1024,
      replyWithLogbookMaxTokens: 1536,
    },

    limits: {
      // Vangnet als een adapter geen eigen grenzen meldt.
      minChars: null,
      maxChars: null,
      // Per platform-id uit de adapter; overschrijft wat de adapter meet.
      perPlatform: {},
    },

    timings: {
      countdownSeconds: 12,
      refreshMinSeconds: 5,
      refreshMaxIdleSeconds: 7200,
      logbookGapMs: 800,
    },

    // De woordenlijsten uit src/style.js en src/blocklist.js. Dit is in de
    // praktijk het meest gewijzigde deel: elke nieuwe kreet die een site
    // aanrekent hoort hier bij te kunnen zonder nieuwe uitrol.
    style: {
      cliches: null,
      promises: null,
      hedges: null,
      greetings: null,
      // Extra verboden woorden bovenop de lijst in de popup, voor alle
      // klanten tegelijk.
      extraBlocklist: [],
    },

    logbook: {
      maxPerRun: 8,
      maxChars: 300,
      personaMinEntries: 4,
      // Waar in de praktijk het meest van gemist wordt; gaat mee in de prompt.
      priorityCategories: [
        'woonplaats',
        "hobby's",
        'familie (kinderen, broers, zussen, ouders, partner)',
        'seksuele voorkeuren',
        'werk of beroep',
        'gezondheid (ziektes, klachten, medicijnen)',
      ],
    },

    memory: {
      maxExamples: 8,
      maxOpenings: 12,
      examplesInPrompt: 5,
      openingsInPrompt: 6,
    },

    features: {
      autoSend: true,
      logbook: true,
      personaLogbook: true,
      memory: true,
      refresh: true,
      stageColours: true,
    },

    ui: {
      showModeButton: true,
      showManualButton: true,
      texts: {},
    },

    maintenance: { enabled: false, message: '' },
  };
})(typeof globalThis !== 'undefined' ? globalThis : self);
