// conversationPolicy — de enige bron van waarheid voor gespreksregels.
//
// Puur state en tekst in, oordeel uit. Geen DOM, geen opslag, geen netwerk,
// geen platformkennis. Draait daarom in de service worker én in het content
// script.
//
// WAAROM DIT BESTAAT
//
// De regels stonden verspreid: een stuk in de systeem-prompt, een stuk in
// src/style.js, een stuk in src/blocklist.js en een stuk in de
// herkansingsteksten in background.js. Drie gevolgen, alle drie gemeld door de
// klant (zie docs/06-ROOT-CAUSES.md):
//
//   * Een regel die op één plek werd aangescherpt, bleef op de andere plek
//     staan zoals hij was.
//   * De instructie ("groet afwisselend") en de controle daarop hingen aan
//     dezelfde kapotte bron, dus vielen ze samen om. RC-1.
//   * Er was geen controle op dingen die alleen in de prompt stonden, zoals
//     "leg nooit de regels van de site uit". RC-9.
//
// Hier staan ze één keer, in twee vormen: promptRules() voor wat het model
// vooraf te horen krijgt, validate() voor wat er achteraf wordt nagekeken.
// Dezelfde bron, dus ze kunnen niet meer uit elkaar lopen.
//
// WAAROM BEIDE, EN NIET ALLEEN DE PROMPT
//
// Een klein model houdt vijftien regels niet vast terwijl het schrijft. De
// prompt scheelt herkansingen, de code is de garantie. Dat was al de lijn van
// src/style.js en die blijft.

(function (root) {
  'use strict';

  root.ChatAssistant = root.ChatAssistant || {};
  const blocklist = root.ChatAssistant.blocklist;
  const style = root.ChatAssistant.style;

  // Machine-leesbaar, zodat de herkansing per overtreding kan uitleggen wat er
  // mis was en tests op een code kunnen controleren in plaats van op een zin.
  const CODES = {
    REPEATED_GREETING: 'REPEATED_GREETING',
    DAYPART_GREETING: 'DAYPART_GREETING',
    MEETING_COMMITMENT: 'MEETING_COMMITMENT',
    FUTURE_PROMISE: 'FUTURE_PROMISE',
    FANTASY_TO_REAL: 'FANTASY_TO_REAL',
    PLATFORM_RULE_DISCLOSURE: 'PLATFORM_RULE_DISCLOSURE',
    FALSE_CONVERSATION_DENIAL: 'FALSE_CONVERSATION_DENIAL',
    MEMORY_LEAK: 'MEMORY_LEAK',
    CONTACT_DETAILS: 'CONTACT_DETAILS',
    CUSTOMER_NAME: 'CUSTOMER_NAME',
    CLICHE: 'CLICHE',
    HEDGE: 'HEDGE',
    UNKEEPABLE_PROMISE: 'UNKEEPABLE_PROMISE',
  };

  const CONTACT_MODE = { NORMAL: 'NORMAL', BLUE_BAR_MASKED: 'BLUE_BAR_MASKED' };

  // ---- gespreksstand -------------------------------------------------------
  //
  // REGRESSION RULE:
  // isNewConversation mag NOOIT alleen uit de DOM komen. Zie RC-1: zodra de
  // adapter de eigen berichten niet zag, gold elke beurt als een nieuw gesprek,
  // kreeg het model het hele groetmenu voorgeschoteld, en begon elk bericht met
  // "Goedemorgen". De opgeslagen stand hieronder is het onafhankelijke signaal
  // dat dat niet laat gebeuren.

  // Een gat van twee weken tussen twee berichten is geen pauze meer maar een
  // nieuw contactmoment. Onder die grens telt het als hetzelfde gesprek.
  const OUD_GESPREK_DAGEN = 14;

  function parseTime(value) {
    if (!value) return null;
    const t = Date.parse(value);
    return Number.isFinite(t) ? t : null;
  }

  // Het grootste gat tussen twee opeenvolgende berichten, in dagen.
  function grootsteGat(messages) {
    const tijden = (messages || [])
      .map((m) => parseTime(m && m.timestamp))
      .filter((t) => t !== null)
      .sort((a, b) => a - b);
    let grootste = 0;
    for (let i = 1; i < tijden.length; i++) {
      const dagen = (tijden[i] - tijden[i - 1]) / 86400000;
      if (dagen > grootste) grootste = dagen;
    }
    return grootste;
  }

  // persisted: wat we zelf van dit gesprek onthouden hebben, los van de DOM.
  //   { turns, greetings: [], openings: [] }
  function buildState(payload, persisted) {
    const p = payload || {};
    const bewaard = persisted || {};
    const messages = p.messages || [];
    const eigen = messages.filter((m) => m && m.role === 'operator').map((m) => m.text);

    // Twee onafhankelijke bewijzen dat dit gesprek al loopt. Eén ervan mag
    // wegvallen zonder dat de conclusie omslaat.
    const eerderGeschreven = eigen.length > 0;
    const eerderGezien = Number(bewaard.turns || 0) > 0;
    const isNewConversation = !eerderGeschreven && !eerderGezien && messages.length <= 2;

    const gat = grootsteGat(messages);
    const hasPreviousConversation = gat >= OUD_GESPREK_DAGEN;

    // Wat wij in dit gesprek al gebruikt hebben. De opgeslagen lijst gaat
    // voorop: die overleeft een adapter die niets ziet.
    const gebruikteGroeten = (bewaard.greetings || []).concat(
      eigen.map((t) => style.greetingOf(t)).filter(Boolean)
    );

    return {
      platform: p.platform || null,
      conversationId: p.conversationId || null,
      isNewConversation,
      hasPreviousConversation,
      conversationGapDays: gat > 0 ? Math.round(gat) : 0,
      recentAssistantMessages: eigen.slice(-5),
      recentGreetings: gebruikteGroeten.slice(-6),
      greetingUsedRecently: gebruikteGroeten.length > 0,
      lastGreeting: gebruikteGroeten[gebruikteGroeten.length - 1] || null,
      // Fantasie herkennen we niet aan een vlag maar aan het gesprek. Hij dient
      // alleen om de uitleg bij een overtreding scherper te maken; de regel
      // zelf geldt hoe dan ook.
      fantasyMode: false,
      contactSharingMode: p.masksContactDetails
        ? CONTACT_MODE.BLUE_BAR_MASKED
        : CONTACT_MODE.NORMAL,
      allowsContactDetails: p.allowsContactDetails === true,
    };
  }

  // ---- groeten -------------------------------------------------------------
  //
  // Dagdeelgroeten zijn één klasse. Afwisselen tussen "goedemorgen" en
  // "goeiemorgen" is geen afwisseling, en dat was met een exacte
  // string-vergelijking niet te zien.
  const DAGDEEL = [
    'goedemorgen',
    'goeiemorgen',
    'goedemiddag',
    'goeiemiddag',
    'goedenavond',
    'goeienavond',
    'goedeavond',
  ];

  function isDaypart(groet) {
    return !!groet && DAGDEEL.indexOf(groet) !== -1;
  }

  // ---- toezeggingen --------------------------------------------------------
  //
  // REGRESSION RULE:
  // Dit is bewust GEEN lijst met zinnen. Een toezegging is een grammaticale
  // vorm — wij + toekomst + gezamenlijke handeling — en geen onderwerp. De
  // oude aanpak (een lijst zelfstandige naamwoorden in blocklist.js) miste
  // "dat gaan we zeker doen" en "wie weet staan we daar binnenkort samen",
  // precies de formuleringen waar de klant over viel. Een langere lijst lost
  // dat niet op; die maakt hem alleen langer.
  //
  // Vals alarm is hier goedkoop: dat kost één herkansing. Iets missen is duur,
  // want dan gaat er een toezegging de deur uit die niemand nakomt.

  // Samen — als onderwerp of als richting.
  const SAMEN = /\b(?:we|wij|ons|onze|samen|met je|met jou|jij en ik|elkaar)\b/i;

  // Toekomst: een hulpwerkwoord dat vooruitwijst, of een tijdsbepaling.
  const TOEKOMST =
    /\b(?:gaan|gaat|ga|zullen|zul|zal|moeten|moet|kunnen|kun|kan|willen|wil|straks|binnenkort|snel|gauw|ooit|later|nog eens|een keertje|een keer|volgende week|komende week|dit weekend|komend weekend|volgend weekend|morgen|vanavond|ergens)\b/i;

  // Een gezamenlijke handeling, of een verwijzing ernaar.
  const HANDELING =
    /\b(?:doen|afspreken|afspraak|spreken|ontmoeten|zien|treffen|drinken|eten|wandelen|fietsen|koffie|bioscoop|langskomen|langsgaan|bezoeken|daten|uitgaan|staan|zitten|liggen|beleven|meemaken)\b/i;

  // "dat", "dit", "daar" verwijzen terug naar iets wat net besproken is en
  // maken van een vaag zinnetje alsnog een toezegging over díe handeling.
  const VERWIJZING = /\b(?:dat|dit|daar|zoiets|het)\b/i;

  // Intentie zonder hulpwerkwoord: "lijkt me leuk om samen te wandelen".
  const INTENTIE =
    /\b(?:lijkt me (?:leuk|wel wat|heerlijk|spannend)|zou (?:leuk|heerlijk|mooi) zijn|heb ik wel zin in|zin om|kan niet wachten|verheug me)\b/i;

  function zinnen(value) {
    return String(value == null ? '' : value)
      .split(/(?<=[.!?])\s+|\n+/)
      .map((z) => z.trim())
      .filter(Boolean);
  }

  // Per zin beoordelen. Over een heel bericht zouden losse signalen uit
  // verschillende zinnen bij elkaar opgeteld worden en dat geeft vals alarm.
  function meetingCommitmentHits(value) {
    const out = [];
    for (const zin of zinnen(value)) {
      const samen = SAMEN.test(zin);
      if (!samen) continue;
      const vooruit = TOEKOMST.test(zin) || INTENTIE.test(zin);
      if (!vooruit) continue;
      if (HANDELING.test(zin) || VERWIJZING.test(zin)) out.push(zin);
    }
    return out;
  }

  // ---- beloftes ------------------------------------------------------------
  //
  // Ik + iets leveren + een moment. Los van de fotobeloftes die src/style.js
  // al kent; die blijven daar staan en worden hier meegenomen.
  const IK = /\b(?:ik|ikke)\b/i;
  const LEVEREN =
    /\b(?:stuur|stuurt|bel|belt|mail|mailt|app|appt|whatsapp|maak|maakt|kom|komt|regel|regelt|geef|geeft|laat weten|laat het weten|zorg)\b/i;
  const MOMENT =
    /\b(?:morgen|straks|vanavond|later|zo|zometeen|dadelijk|volgende keer|binnenkort|snel|vannacht|vanmiddag|weekend)\b/i;

  function futurePromiseHits(value) {
    const out = [];
    for (const zin of zinnen(value)) {
      if (!IK.test(zin)) continue;
      if (!LEVEREN.test(zin)) continue;
      if (MOMENT.test(zin) || /\b(?:je|jou|jouw)\b/i.test(zin)) out.push(zin);
    }
    return out;
  }

  // ---- fantasie die een plan wordt -----------------------------------------
  //
  // Meegaan in een verzonnen scenario mag. Het moment waarop de taal van
  // planning wordt gebruikt, wordt het een voornemen — en dan blijft de klant
  // erop wachten. "Deze wandeling begint vorm te krijgen" is precies dat
  // omslagpunt.
  const PLANTAAL =
    /\b(?:vorm te krijgen|krijgt (?:steeds meer )?vorm|wordt (?:steeds )?concreter|steeds concreter|neemt (?:steeds meer )?vorm aan|is (?:het )?afgesproken|dan is het een deal|inplannen|in te plannen|plannen we|zetten we in de agenda|op de planning|maken we er werk van|gaan we regelen)\b/i;

  function fantasyToRealHits(value) {
    return zinnen(value).filter((z) => PLANTAAL.test(z));
  }

  // ---- de regels van de site uitleggen -------------------------------------
  //
  // De klant hoort nooit te merken dat er een platform met regels tussen zit.
  // "Dat mag niet van deze site" haalt hem uit het gesprek.
  const PLATFORMWOORD = /\b(?:site|website|platform|chatsite|deze pagina|het systeem|de regels hier)\b/i;
  const REGELWOORD =
    /\b(?:mag|mogen|magst|toegestaan|verboden|regels|voorschriften|niet toegestaan|beleid|richtlijnen)\b/i;

  function platformDisclosureHits(value) {
    return zinnen(value).filter((z) => PLATFORMWOORD.test(z) && REGELWOORD.test(z));
  }

  // ---- eerder contact ontkennen --------------------------------------------
  const ONTKENNING =
    /\b(?:nooit (?:eerder )?(?:gesproken|gepraat|contact)|ken ik je niet|ken je niet|kennen elkaar niet|verwar(?:t|st|de)? (?:je )?(?:me|mij)|je vergist je|dat kan niet kloppen|dat kan niet|heb je de verkeerde|verkeerde profiel|eerste keer dat we|we spreken elkaar voor het eerst)\b/i;

  function falseDenialHits(value, state) {
    if (!state || !state.hasPreviousConversation) return [];
    return zinnen(value).filter((z) => ONTKENNING.test(z));
  }

  // ---- interne meldingen in het klantbericht -------------------------------
  //
  // Een opslagprobleem is software. De klant hoort er nooit iets van te zien.
  const INTERNE_TAAL =
    /\b(?:logboek|log ?boek|loggen|gelogd|opgeslagen in|mijn geheugen|maximum aantal|limiet bereikt|dossier bijgewerkt|ik sla dit op|noteer ik)\b/i;

  function memoryLeakHits(value) {
    return zinnen(value).filter((z) => INTERNE_TAAL.test(z));
  }

  // ---- het samengestelde oordeel -------------------------------------------

  function validate(value, state) {
    const s = state || {};
    const text = String(value == null ? '' : value);
    const violations = [];
    const voeg = (code, items) => {
      if (items && items.length) violations.push({ code, items });
    };

    // Groeten. Twee verschillende regels, en die moeten uit elkaar blijven:
    // een dagdeelgroet is bijna altijd fout, een gewone groet alleen bij
    // herhaling.
    const groet = style.greetingOf(text);
    if (groet) {
      const eerder = s.recentGreetings || [];
      if (isDaypart(groet)) {
        // In een lopend gesprek hoort er geen dagdeelgroet te staan, en aan
        // het begin hooguit als hij niet net gebruikt is.
        if (!s.isNewConversation || eerder.some(isDaypart)) {
          voeg(CODES.DAYPART_GREETING, [groet]);
        }
      } else if (eerder.indexOf(groet) !== -1) {
        voeg(CODES.REPEATED_GREETING, [groet]);
      }
    }

    voeg(CODES.MEETING_COMMITMENT, meetingCommitmentHits(text));
    voeg(CODES.FUTURE_PROMISE, futurePromiseHits(text));
    voeg(CODES.FANTASY_TO_REAL, fantasyToRealHits(text));
    voeg(CODES.PLATFORM_RULE_DISCLOSURE, platformDisclosureHits(text));
    voeg(CODES.FALSE_CONVERSATION_DENIAL, falseDenialHits(text, s));
    voeg(CODES.MEMORY_LEAK, memoryLeakHits(text));

    // De bestaande afspraak- en contactdetectie blijft meedoen. Ze vangt
    // andere gevallen dan de grammaticale detectie hierboven — "koffie
    // drinken" zonder "we" bijvoorbeeld.
    if (blocklist.hasDateProposal(text)) {
      voeg(CODES.MEETING_COMMITMENT, blocklist.dateProposalHits(text));
    }
    if (!s.allowsContactDetails && blocklist.hasContactDetails(text)) {
      voeg(CODES.CONTACT_DETAILS, blocklist.contactDetailHits(text));
    }

    // En de huisregels uit src/style.js, vertaald naar dezelfde codes zodat er
    // maar één soort uitkomst is.
    const stijl = style.check(text, {
      customerNames: s.customerNames,
      // De groetregel doen we hierboven zelf, met klassen en met de opgeslagen
      // stand erbij. Leeg meegeven voorkomt dat dezelfde overtreding twee keer
      // gemeld wordt.
      previousOperatorTexts: [],
      cliches: s.cliches,
      promises: s.promises,
      hedges: s.hedges,
    });
    const VERTAAL = {
      naam: CODES.CUSTOMER_NAME,
      cliche: CODES.CLICHE,
      belofte: CODES.UNKEEPABLE_PROMISE,
      toezegging: CODES.HEDGE,
    };
    for (const issue of stijl.issues || []) {
      if (VERTAAL[issue.type]) voeg(VERTAAL[issue.type], issue.items);
    }

    return { valid: violations.length === 0, violations };
  }

  // ---- uitleg voor de herkansing -------------------------------------------
  //
  // Zonder uitleg is een herkansing opnieuw gooien met dezelfde dobbelsteen.
  const UITLEG = {
    [CODES.DAYPART_GREETING]: () =>
      'Begin niet met "goedemorgen", "goedemiddag" of "goedenavond". Dat valt ' +
      'op als het in elk bericht staat. Ga gewoon verder waar het gesprek ' +
      'gebleven was, of begin met wat je te zeggen hebt.',
    [CODES.REPEATED_GREETING]: (items) =>
      `Je begint weer met "${items[0]}", net als eerder in dit gesprek. Kies ` +
      'een andere opening, of laat de groet helemaal weg — dat laatste mag ' +
      'vaker dan je denkt.',
    [CODES.MEETING_COMMITMENT]: (items) =>
      `Hierin staat een toezegging over iets wat jullie samen zouden gaan doen ` +
      `(${items.map((i) => `"${i}"`).join(', ')}). Er komt nooit een echte ` +
      'ontmoeting. Zeg niet toe dat het gebeurt, ook niet vaag of in de ' +
      'toekomst. Draai er speels omheen en houd het bij nu.',
    [CODES.FUTURE_PROMISE]: (items) =>
      `Je belooft iets te doen (${items.map((i) => `"${i}"`).join(', ')}). Zeg ` +
      'nooit dat je iets stuurt, belt, maakt of regelt. Houd het vrijblijvend.',
    [CODES.FANTASY_TO_REAL]: (items) =>
      `Je maakt van een fantasie een plan (${items.map((i) => `"${i}"`).join(', ')}). ` +
      'Meegaan in het scenario mag volop, maar het moet in gedachten blijven — ' +
      'geen planning, geen afspraak, niets wat echt gaat gebeuren.',
    [CODES.PLATFORM_RULE_DISCLOSURE]: () =>
      'Leg nooit uit wat de site wel of niet toestaat. De klant hoort niet te ' +
      'merken dat er regels zijn. Houd het bij je eigen grens: dat deel je ' +
      'liever niet, of nog niet.',
    [CODES.FALSE_CONVERSATION_DENIAL]: () =>
      'Je ontkent dat jullie eerder contact hadden, terwijl dat wel zo is. ' +
      'Erken het gewoon en maak er iets van — het is alweer even geleden, en ' +
      'hij liet ineens niets meer horen.',
    [CODES.MEMORY_LEAK]: () =>
      'Er staat iets in over opslaan, loggen of een dossier. Dat is intern; ' +
      'de klant hoort daar nooit iets van te zien. Laat het weg.',
    [CODES.CONTACT_DETAILS]: () =>
      'Er staan contactgegevens in en die mogen hier niet. Schrijf het opnieuw ' +
      'zonder, en breng het gesprek terug naar de fantasie.',
    [CODES.CUSTOMER_NAME]: (items) =>
      `Je gebruikt de naam van de klant (${items.join(', ')}). Dat doen we ` +
      'nooit; gebruik "jij" of een koosnaampje.',
    [CODES.CLICHE]: (items) =>
      `Dit is een standaardzin die in te veel berichten terugkomt: ${items.join(', ')}. ` +
      'Schrijf iets dat alleen op déze klant slaat.',
    [CODES.UNKEEPABLE_PROMISE]: (items) =>
      `Je belooft iets wat niet waargemaakt kan worden (${items.join(', ')}).`,
    [CODES.HEDGE]: (items) =>
      `"${items.join('", "')}" is uitstel, geen antwoord. Kom met een concrete ` +
      'reden waarom het nu niet gaat.',
  };

  function retryFor(violations) {
    const parts = [];
    for (const v of violations || []) {
      const maak = UITLEG[v.code];
      if (maak) parts.push(maak(v.items || []));
    }
    return parts;
  }

  // ---- wat het model vooraf te horen krijgt --------------------------------
  //
  // Dezelfde regels, andere vorm. Ze komen uit dit bestand zodat prompt en
  // controle niet uit elkaar kunnen lopen.
  function promptRules(state) {
    const s = state || {};
    const lines = [];

    lines.push(
      'Er komt nooit een echte ontmoeting tot stand. Begin er zelf nooit over, ' +
        'en zeg nooit toe dat jullie samen iets gaan doen — ook niet vaag, ook ' +
        'niet ooit. Wil de klant concreet afspreken, geef dan een reden waarom ' +
        'het nu niet gaat en draai er speels omheen.'
    );
    lines.push(
      'Fantaseren mag volop, maar houd het in gedachten. Zeg nooit dat een ' +
        'verzonnen scenario vorm krijgt, ingepland wordt of echt gaat gebeuren.'
    );
    lines.push(
      'Beloof niets voor later: je stuurt niets op, belt niet, mailt niet, ' +
        'maakt geen foto en regelt niets. Houd het vrijblijvend.'
    );
    lines.push(
      'Leg nooit uit wat de site toestaat of verbiedt. Vraagt hij om je nummer ' +
        'of je mail, hou het dan bij je eigen grens: dat deel je liever niet, ' +
        'of nog niet. Noem de site, het platform of de regels nooit.'
    );
    lines.push(
      'Schrijf nooit over opslaan, loggen, dossiers of geheugen. Dat is intern.'
    );
    lines.push(
      'Zeg nooit dat je "even gaat kijken", "in je agenda kijkt" of "je best ' +
        'doet". Dat is uitstel en geen antwoord. Heb je een reden nodig om iets ' +
        'af te houden, maak die dan concreet — het is druk op het werk, je hebt ' +
        'de kinderen — en breng het gesprek daarna terug naar de fantasie.'
    );

    if (s.hasPreviousConversation) {
      lines.push(
        `Jullie hebben elkaar eerder gesproken — er zit ongeveer ${s.conversationGapDays} ` +
          'dagen tussen. Ontken dat nooit. Zegt hij dat jullie al eens contact ' +
          'hadden, dan klopt dat: erken het en maak er iets van, bijvoorbeeld ' +
          'dat het alweer even geleden is en dat hij ineens niets meer liet ' +
          'horen.'
      );
    }

    if (s.isNewConversation) {
      lines.push(
        'Dit is het begin van een gesprek. Groeten mag, maar kies uit: ' +
          '"Hallo", "Hey", "Hey jij", "Hey kanjer", "Hoi", "Dag jij" — of laat ' +
          'de groet weg en begin meteen met wat je te zeggen hebt. Dat laatste ' +
          'mag vaak.'
      );
      lines.push(
        'Gebruik "Goedemorgen", "Goedemiddag" en "Goedenavond" hoogstens ' +
          'zelden. Ze vallen op zodra ze vaker terugkomen.'
      );
    } else {
      lines.push(
        'DIT GESPREK LOOPT AL. Je valt niet binnen met een opening. Geen ' +
          '"goedemorgen", geen "hallo", geen "hoe gaat het vandaag". Reageer ' +
          'direct op wat er net gezegd is. Vaak is helemaal geen aanspreking ' +
          'het beste: begin gewoon met je antwoord.'
      );
    }

    if (s.recentGreetings && s.recentGreetings.length) {
      lines.push(
        'Je gebruikte in dit gesprek al: ' +
          s.recentGreetings.map((g) => `"${g}"`).join(', ') +
          '. Herhaal die niet.'
      );
    }

    if (s.contactSharingMode === CONTACT_MODE.BLUE_BAR_MASKED) {
      lines.push(
        'Bij deze klant mag je een nummer of mailadres aanbieden, maar schrijf ' +
          'het nooit echt uit: zet er ****** voor in de plaats. Een concrete ' +
          'afspraak voorstellen blijft ook hier verboden.'
      );
    }

    return lines;
  }

  root.ChatAssistant.policy = {
    CODES,
    CONTACT_MODE,
    buildState,
    validate,
    retryFor,
    promptRules,
    isDaypart,
    meetingCommitmentHits,
    futurePromiseHits,
    fantasyToRealHits,
    platformDisclosureHits,
    falseDenialHits,
    memoryLeakHits,
    OUD_GESPREK_DAGEN,
  };
})(typeof globalThis !== 'undefined' ? globalThis : self);
