// Beslist of een pagina zonder gesprek zichzelf mag verversen. Pure functie:
// de feiten worden door content.js verzameld, het oordeel valt hier. Zo is de
// beslissing te testen zonder browser, net als blocklist.js en autosend.js.

globalThis.ChatAssistant = globalThis.ChatAssistant || {};

(function () {
  'use strict';

  // ---- remmen op het verversen --------------------------------------------
  //
  // Op 19-08-2026 is een moddies-account geblokkeerd en heb ik hier een
  // ondergrens van een minuut ingebouwd. Die is er op 20-08 weer uit: de
  // oorzaak van de blokkade is nooit bevestigd, en moddies moet onbewaakt
  // kunnen draaien — met een minuut ertussen loopt de wachtrij achter. De
  // operator draagt dat risico en heeft die afweging gemaakt.
  //
  // Wat blijft is een sanity-grens en een tijdslot. Geen van beide zit een
  // normale werkdag in de weg:
  //
  //   1. Minimaal 5 seconden. Niet als beleid maar als bodem: onder de 5
  //      seconden is het geen verversen meer maar een lus, en dan gaat er
  //      iets anders stuk dan wat je aan het oplossen was.
  //   2. Stoppen na twee uur zonder werk. Een tabblad dat vrijdagavond open
  //      blijft staan haalt die pagina anders het hele weekend op. Twee uur
  //      haalt geen pauze en geen dienst; een vergeten tabblad wel.
  //
  // De trapsgewijze terugloop die hier stond is weg. Die maakte het ophalen
  // rustiger, maar liet je ook tot een kwartier op een nieuw gesprek wachten
  // — precies het tegenovergestelde van waar het verversen voor is.
  const MIN_INTERVAL_SECONDS = 5;
  const MAX_IDLE_SECONDS = 2 * 60 * 60;

  function effectiveInterval(intervalSeconds) {
    return Math.max(Number(intervalSeconds) || 0, MIN_INTERVAL_SECONDS);
  }

  // Apart, zodat content.js kan laten zien dát hij gestopt is in plaats van
  // dat er stilletjes niets meer gebeurt.
  function uitgeput(idleSeconds) {
    return (Number(idleSeconds) || 0) >= MAX_IDLE_SECONDS;
  }

  function shouldRefresh(facts) {
    const f = facts || {};
    const ingesteld = Number(f.intervalSeconds) || 0;

    // 0 of ontbrekend betekent uit. Dit is de standaard.
    if (ingesteld <= 0) return false;

    // Sommige platforms halen zichzelf al op — ChatHomeBase schuift het
    // gesprek vanzelf binnen zodra er een wordt toegewezen. Onze verversing
    // komt daar dan bovenop en levert niets op: puur extra verkeer, precies
    // wat we sinds de blokkade proberen te vermijden.
    if (f.siteRefreshesItself === true) return false;

    // Opgegeven: er is te lang niets gebeurd. Zie MAX_IDLE_SECONDS.
    if (uitgeput(f.idleSeconds)) return false;

    const interval = effectiveInterval(ingesteld);

    // VASTGELOPEN OP HET HUIDIGE GESPREK
    //
    // Stuurt de klant een foto, dan weigert de robot te versturen: hij kan de
    // foto niet zien, dus elk antwoord is blind gegokt. Dat is goed. Wat niet
    // goed was: daarna stond alles stil. Er is namelijk wél een gesprek
    // (hasChat) en er staat wél tekst in het veld (het eigen concept), dus
    // allebei de remmen hieronder grepen, en in vol-automatisch — precies
    // wanneer er niemand kijkt — bleef de robot minutenlang dood staan.
    //
    // Is de robot vastgelopen, dan zijn die twee remmen juist niet van
    // toepassing: het gesprek is voor hem afgelopen en de tekst is van hem
    // zelf. Verversen is dan de enige weg naar het volgende gesprek.
    //
    // Dit wordt alleen gezet in vol-automatisch. In "klaarzetten" kijk jij
    // mee en blijft het concept dus gewoon staan.
    const vast = f.stuckOnChat === true;

    // Er staat een gesprek op de pagina; er valt niets te verversen.
    if (f.hasChat && !vast) return false;

    // Altijd minstens één hele interval wachten na het laden. Zonder deze rem
    // wordt een trage site een herlaadstorm.
    const wachtend = Number(f.secondsSinceLoad);
    if (!(wachtend >= interval)) return false;

    // Staat er ergens tekst in een veld, dan ben jij bezig en zou verversen
    // jouw werk weggooien.
    if (f.hasTypedText && !vast) return false;

    return true;
  }

  ChatAssistant.refresh = {
    shouldRefresh,
    effectiveInterval,
    uitgeput,
    MIN_INTERVAL_SECONDS,
    MAX_IDLE_SECONDS,
  };
})();
