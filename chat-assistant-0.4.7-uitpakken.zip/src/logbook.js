// Filtert wat het model als logboekfeiten teruggeeft, vóór er iets in het
// dossier van een klant belandt. Geen DOM, geen netwerk, geen opslag — dus
// los te testen, net als blocklist.js en autosend.js.
//
// Waarom deze laag bestaat: een logboekregel is permanent en wordt later door
// collega's als waarheid gelezen. Een model dat "ik werk in de zorg" tot
// "verpleegkundige" maakt, of hetzelfde feit twee keer aanlevert, mag dat niet
// ongefilterd wegschrijven. De prompt vraagt om terughoudendheid; deze laag
// dwingt het af.

globalThis.ChatAssistant = globalThis.ChatAssistant || {};

(function () {
  'use strict';

  const MAX_PER_RUN = 8;
  const MAX_CHARS = 300;

  // ---- één call in plaats van twee ----------------------------------------
  //
  // Het antwoord schrijven en de feiten uit het gesprek halen waren twee
  // aparte API-calls. Beide kregen hetzelfde gesprek mee, dus de helft van
  // wat er betaald werd was dezelfde tekst twee keer versturen.
  //
  // Nu vraagt één call om allebei, in twee gemarkeerde blokken:
  //
  //   <bericht>
  //   De eigenlijke tekst van het antwoord.
  //   </bericht>
  //   <logboek>
  //   [{"categoryId":"4","text":"Woont in Maaseik"}]
  //   </logboek>
  //
  // GEEN JSON OM HET GEHEEL HEEN, EN DAT IS EEN BEWUSTE KEUZE.
  //
  // Het antwoord in een JSON-veld persen betekent dat elke aanhalingsteken en
  // regelovergang ontsnapt moet worden, en modellen schrijven merkbaar
  // stijver zodra ze binnen JSON formuleren. Dat is precies het verkeerde
  // offer voor een tekst die menselijk moet klinken. Met losse blokken
  // schrijft het model eerst gewoon het bericht en pas daarna de feiten.
  //
  // HET BERICHT MOET EEN KAPOT LOGBOEK OVERLEVEN.
  //
  // Gaat het logboekdeel stuk — ontbrekende haak, verzonnen veldnaam, model
  // dat de tags vergeet — dan is er nog steeds een antwoord om te versturen.
  // Andersom zou een fout in een bijzaak de hoofdzaak kosten.
  const REPLY_RE = /<bericht>([\s\S]*?)<\/bericht>/i;
  const LOG_RE = /<logboek>([\s\S]*?)<\/logboek>/i;
  // Het eigen dossier van de persona. Wordt alleen gevraagd als dat nog
  // vrijwel leeg is, dus dit blok ontbreekt meestal — en dat is normaal.
  const PERSONA_LOG_RE = /<eigenlogboek>([\s\S]*?)<\/eigenlogboek>/i;

  function stripFences(value) {
    return String(value || '')
      .replace(/^\s*```(?:json)?/i, '')
      .replace(/```\s*$/, '')
      .trim();
  }

  function parseEntries(value) {
    const tekst = stripFences(value);
    if (!tekst) return [];

    try {
      const data = JSON.parse(tekst);
      // Zowel een kale lijst als {"entries": [...]} accepteren; modellen
      // wisselen daartussen en het onderscheid draagt geen betekenis.
      const lijst = Array.isArray(data)
        ? data
        : data && Array.isArray(data.entries)
          ? data.entries
          : [];
      return lijst.filter((e) => e && typeof e === 'object');
    } catch (e) {
      return [];
    }
  }

  // Geeft altijd een bruikbaar antwoord terug, ook als er geen enkele tag in
  // staat: dan is de hele tekst het bericht. Dat is precies het geval bij een
  // herkansing, waarin alleen om nieuwe berichttekst wordt gevraagd.
  function parseCombined(raw) {
    const tekst = String(raw == null ? '' : raw).trim();

    const berichtMatch = REPLY_RE.exec(tekst);
    const logMatch = LOG_RE.exec(tekst);
    const eigenMatch = PERSONA_LOG_RE.exec(tekst);

    const entries = logMatch ? parseEntries(logMatch[1]) : [];
    const personaEntries = eigenMatch ? parseEntries(eigenMatch[1]) : [];

    if (!berichtMatch) {
      // Geen tags: alles is het bericht. Wel eerst de logboekblokken eraf
      // halen, anders belandt die JSON in het invoerveld van de klant.
      let zonderLog = tekst;
      if (logMatch) zonderLog = zonderLog.replace(LOG_RE, '');
      if (eigenMatch) zonderLog = zonderLog.replace(PERSONA_LOG_RE, '');
      return {
        reply: stripFences(zonderLog.trim()),
        entries,
        personaEntries,
        tagged: false,
      };
    }

    return {
      reply: berichtMatch[1].trim(),
      entries,
      personaEntries,
      tagged: true,
    };
  }

  // Voor het vergelijken van "staat dit er al": hoofdletters, leestekens en
  // dubbele spaties mogen het verschil niet maken.
  function normalise(value) {
    return String(value || '')
      .toLowerCase()
      .replace(/[.,;:!?'"()\-]/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
  }

  function selectEntries(proposed, options) {
    const opts = options || {};
    const categories = opts.categories || [];
    const existing = opts.existing || [];
    const max = typeof opts.max === 'number' ? opts.max : MAX_PER_RUN;
    const maxChars = typeof opts.maxChars === 'number' ? opts.maxChars : MAX_CHARS;

    // Een categorie die dit platform niet kent kunnen we niet kiezen in de
    // keuzelijst, dus zo'n regel is onbruikbaar.
    //
    // We accepteren zowel het id als de naam. Modellen geven geregeld "Werk"
    // terug waar "5" werd gevraagd, en dat stilzwijgend weggooien kostte
    // eerder hele categorieën aan gelogde feiten.
    const known = new Map();
    for (const c of categories) {
      if (!c || c.id === undefined || c.id === null) continue;
      const id = String(c.id);
      known.set(id.toLowerCase().trim(), id);
      if (c.label) known.set(String(c.label).toLowerCase().trim(), id);
    }

    // Alles wat al gelogd is telt als gezien. Daar komt elke geaccepteerde
    // regel bij, zodat het model niet twee varianten van hetzelfde feit in
    // dezelfde ronde kwijt kan.
    const seen = new Set();
    for (const item of existing) {
      const key = normalise(item && item.text);
      if (key) seen.add(key);
    }

    const out = [];
    for (const item of proposed || []) {
      if (out.length >= max) break;

      // Ook `category` accepteren; niet elk model houdt zich aan de veldnaam.
      const gevraagd = (item && (item.categoryId !== undefined ? item.categoryId : item.category)) || '';
      const categoryId = known.get(String(gevraagd).toLowerCase().trim());
      const text = String((item && item.text) || '').trim();

      if (!categoryId) continue;
      if (!text) continue;
      // Een feit is één korte zin. Wat langer is, is een samenvatting en dat
      // hoort niet in een dossierveld.
      if (text.length > maxChars) continue;

      const key = normalise(text);
      if (!key || seen.has(key)) continue;

      seen.add(key);
      out.push({ categoryId, text });
    }

    return out;
  }

  ChatAssistant.logbook = {
    selectEntries,
    normalise,
    parseCombined,
    MAX_PER_RUN,
    MAX_CHARS,
  };
})();
