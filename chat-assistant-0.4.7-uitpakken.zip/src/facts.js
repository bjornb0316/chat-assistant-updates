// Wat er wél en niet in het dossier van een klant terechtkomt.
//
// Puur tekst in, oordeel uit — geen DOM, geen opslag, geen netwerk. Draait
// daarom zowel in het content script als in de service worker.
//
// WAAROM DEZE LAAG BESTAAT
//
// src/logbook.js filtert op vorm: kent het platform deze categorie, is de tekst
// niet leeg, staat hij er niet al letterlijk. Dat is te weinig gebleken. Wat er
// misging (zie docs/06-ROOT-CAUSES.md, RC-4 t/m RC-7):
//
//   * "Ik moet morgen werken" werd opgeslagen. Dat is geen dossierfeit maar de
//     dagplanning van iemand; volgende week klopt het niet meer.
//   * "Nijmegen", "Woont in Nijmegen" en "Woonplaats Nijmegen" werden drie
//     losse regels, want ze verschillen als string.
//   * Een verhuizing leverde een tweede woonplaats op naast de eerste, waarna
//     het dossier zichzelf tegensprak.
//   * Wat het profiel van de persona over zichzelf zei, kon in het dossier van
//     de klant belanden. Dat werd alleen door de prompt tegengehouden.
//
// DE KERNGEDACHTE
//
// Een feit is geen zin maar een tripel: categorie, sleutel, waarde. Pas als je
// dat hebt kun je zien dat twee zinnen hetzelfde zeggen, en dat een derde zin
// hetzelfde veld een nieuwe waarde geeft.

(function (root) {
  'use strict';

  root.ChatAssistant = root.ChatAssistant || {};

  // Waar een kandidaat-feit vandaan komt. Alleen CUSTOMER mag ooit in het
  // klantdossier belanden — zie attest() hieronder, dat het niet gelooft maar
  // nakijkt.
  const SOURCE = {
    CUSTOMER: 'CUSTOMER',
    OPERATOR_PROFILE: 'OPERATOR_PROFILE',
    ASSISTANT: 'ASSISTANT',
  };

  // ---- duurzaamheid --------------------------------------------------------
  //
  // Een dossierfeit moet volgende maand nog kloppen. "Ik ga zo douchen" is
  // waar op het moment van schrijven en daarna nooit meer.

  // Verwijzingen naar een moment dat voorbijgaat.
  const VLUCHTIG_TIJD = new RegExp(
    '\\b(?:vandaag|vanavond|vanmiddag|vanochtend|vannacht|morgen|overmorgen|' +
      'gisteren|straks|zometeen|zo meteen|dadelijk|zojuist|net even|nu even|' +
      'op dit moment|momenteel|vanmorgen)\\b',
    'i'
  );

  // Toestanden en handelingen die per definitie tijdelijk zijn.
  const VLUCHTIG_TOESTAND = new RegExp(
    '\\b(?:moe|slaperig|honger|dorst|verveelt|verveeld|ziek vandaag|' +
      'gaat(?: zo| straks| even| nog| dadelijk| zometeen)* (?:slapen|eten|douchen|koken|sporten)|' +
      'ligt op de bank|kijkt tv|' +
      'net wakker|aan het (?:werk|eten|koken|douchen)|onderweg naar huis|' +
      'moet (?:nog )?(?:werken|weg|opruimen)|heeft dienst)\\b',
    'i'
  );

  // Herhaling maakt iets juist wél duurzaam: "speelt iedere zondag tennis" gaat
  // over een gewoonte, niet over aanstaande zondag. Dit signaal wint van de
  // tijdswoorden hierboven.
  const HERHALING = new RegExp(
    '\\b(?:altijd|meestal|vaak|regelmatig|elke|iedere|elk|ieder|dagelijks|' +
      'wekelijks|maandelijks|jaarlijks|al jaren|sinds|van jongs af)\\b',
    'i'
  );

  function isDurable(value) {
    const tekst = String(value == null ? '' : value);
    if (!tekst.trim()) return { durable: false, reason: 'leeg' };
    if (HERHALING.test(tekst)) return { durable: true, reason: 'gewoonte' };
    if (VLUCHTIG_TIJD.test(tekst)) return { durable: false, reason: 'tijdelijk' };
    if (VLUCHTIG_TOESTAND.test(tekst)) return { durable: false, reason: 'toestand' };
    return { durable: true, reason: 'duurzaam' };
  }

  // ---- categorie en sleutel ------------------------------------------------
  //
  // De categorielabels komen van het platform en verschillen per site. We
  // vertalen ze naar een eigen, stabiele sleutel, zodat dedupliceren werkt
  // ongeacht hoe de site zijn keuzelijst noemt.

  const CATEGORIE_PATRONEN = [
    { key: 'name', re: /\b(?:naam|voornaam|roepnaam)\b/i },
    { key: 'location', re: /\b(?:woonplaats|woon|plaats|locatie|regio|adres|stad)\b/i },
    { key: 'family', re: /\b(?:familie|gezin|kinderen|partner|relatie|burgerlijke)\b/i },
    { key: 'work', re: /\b(?:werk|beroep|baan|functie|opleiding|studie)\b/i },
    { key: 'hobby', re: /\b(?:hobby|hobbys|interesse|sport|vrije tijd)\b/i },
    { key: 'health', re: /\b(?:gezondheid|ziekte|medisch|klachten|medicijn)\b/i },
    { key: 'preference', re: /\b(?:voorkeur|voorkeuren|seksueel|seksuele|fantasie)\b/i },
  ];

  // Uit de tekst zelf, voor als het label niets prijsgeeft.
  const TEKST_PATRONEN = [
    { key: 'location', re: /\b(?:woont?|woonachtig|komt uit|afkomstig uit|woonplaats)\b/i },
    { key: 'name', re: /\b(?:heet|naam is|genaamd)\b/i },
    { key: 'family', re: /\b(?:dochter|dochters|zoon|zonen|kind|kinderen|broer|zus|vrouw|man|partner|getrouwd|gescheiden)\b/i },
    { key: 'work', re: /\b(?:werkt|beroep|baan|monteur|verpleeg|docent|chauffeur|zzp)\b/i },
    { key: 'hobby', re: /\b(?:speelt|sport|voetbal|tennis|fietst|wandelt|vist|leest|muziek|motorrijden)\b/i },
  ];

  function categoryOf(text, categoryLabel) {
    const label = String(categoryLabel || '');
    for (const p of CATEGORIE_PATRONEN) if (p.re.test(label)) return p.key;
    const tekst = String(text || '');
    for (const p of TEKST_PATRONEN) if (p.re.test(tekst)) return p.key;
    return 'other';
  }

  // Woorden waarmee een dossierregel wordt ingeleid. Ze dragen geen inhoud —
  // "Woont in Arnhem" en "Arnhem" zijn hetzelfde feit.
  const INLEIDING = new RegExp(
    '^(?:(?:de |die )?klant |hij |zij |deze man )?' +
      '(?:woont? in |woont |woonachtig in |woonplaats(?: is)? |komt uit |' +
      'afkomstig uit |heet |naam is |zijn naam is |werkt als |werkt in |' +
      'werkt bij |werkt |beroep(?: is)? |hobby(?:\'s)?(?: is| zijn)? |' +
      'houdt van |speelt |heeft |is )',
    'i'
  );

  function stripLead(value) {
    let tekst = String(value == null ? '' : value).trim();
    // Meerdere lagen kunnen erop staan: "De klant woont in Arnhem".
    for (let i = 0; i < 3; i++) {
      const korter = tekst.replace(INLEIDING, '');
      if (korter === tekst) break;
      tekst = korter.trim();
    }
    return tekst;
  }

  function normaliseValue(value) {
    return stripLead(value)
      .toLowerCase()
      .replace(/[.,;:!?'"()\-]/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
  }

  // categorie + genormaliseerde waarde. Dit is wat "hetzelfde feit" betekent.
  function factOf(text, categoryLabel) {
    const value = normaliseValue(text);
    if (!value) return null;
    const category = categoryOf(text, categoryLabel);
    return { category, value, key: `${category}:${value}`, text: String(text).trim() };
  }

  // ---- herkomst controleren ------------------------------------------------
  //
  // REGRESSION RULE:
  // Een feit hoort alleen in het klantdossier als het ook echt uit de mond van
  // de klant komt. Dat wordt hier NAGEKEKEN, niet aangenomen — de prompt vroeg
  // er al om en dat bleek niet genoeg (RC-4). Haal deze controle niet weg
  // zonder test/facts.test.js aan te passen.
  //
  // Woorden waarmee een dossierregel geformuleerd wordt tellen niet mee; die
  // staan zelden letterlijk in het bericht van de klant. Alles wat overblijft
  // moet wél terug te vinden zijn.
  const FRAMEWOORDEN = new Set([
    'heet', 'naam', 'woont', 'woon', 'woonplaats', 'werkt', 'werk', 'beroep',
    'hobby', 'hobbys', 'houdt', 'heeft', 'speelt', 'doet', 'is', 'zijn', 'in',
    'van', 'de', 'het', 'een', 'met', 'en', 'op', 'te', 'als', 'bij', 'klant',
    'hij', 'zij', 'die', 'dat', 'voor', 'uit', 'aan', 'om', 'ook',
  ]);

  function woorden(value) {
    return String(value || '')
      .toLowerCase()
      .replace(/[^\p{L}\p{N}\s]/gu, ' ')
      .split(/\s+/)
      .filter(Boolean);
  }

  // Staat dit woord, of een vervoeging ervan, in de tekst? Vergelijken op de
  // eerste vier letters vangt woont/woon en speelt/speel — precies het verschil
  // tussen hoe een dossierregel en een chatbericht geformuleerd zijn.
  function woordKomtVoor(woord, hooiberg) {
    const stam = woord.slice(0, 4);
    return hooiberg.some((h) => h.startsWith(stam) || woord.startsWith(h.slice(0, 4)));
  }

  function attest(text, customerText) {
    const hooiberg = woorden(customerText);
    if (!hooiberg.length) return { attested: false, missing: ['(geen klanttekst)'] };

    const missing = woorden(stripLead(text)).filter(
      (w) => w.length >= 3 && !FRAMEWOORDEN.has(w) && !woordKomtVoor(w, hooiberg)
    );
    return { attested: missing.length === 0, missing };
  }

  // ---- geldige bestaande regels --------------------------------------------
  //
  // Lege, verwijderde en kapotte records tellen niet mee. Zie requirement K/L:
  // een leeg logboek mag nooit als vol gelden.
  function validEntries(existing) {
    return (existing || []).filter(
      (e) => e && typeof e.text === 'string' && e.text.trim().length > 0
    );
  }

  function countValid(existing) {
    return validEntries(existing).length;
  }

  function limitReached(existing, max) {
    if (typeof max !== 'number' || !(max > 0)) return false;
    return countValid(existing) >= max;
  }

  // ---- het samenvoegen -----------------------------------------------------
  //
  // candidates: [{ categoryId, text }] zoals het model ze voorstelt
  // options: { categories, existing, customerText, max }
  //
  // Geeft terug wat er geschreven mag worden, en waarom de rest afvalt. Die
  // reden is geen luxe: "er is niets gelogd" was niet te onderscheiden van
  // "er viel niets te loggen", en dat heeft een klant een week gekost.
  function reconcile(candidates, options) {
    const opts = options || {};
    const categories = opts.categories || [];
    const existing = validEntries(opts.existing);
    const customerText = opts.customerText || '';
    const max = typeof opts.max === 'number' ? opts.max : 8;
    // Voor het eigen dossier van de persona geldt de herkomstcontrole niet:
    // die feiten hóren juist niet uit het klantbericht te komen. Duurzaamheid
    // en deduplicatie gelden daar wel gewoon.
    const requireAttestation = opts.requireAttestation !== false;

    const labelVan = new Map();
    for (const c of categories) {
      if (!c || c.id === undefined || c.id === null) continue;
      labelVan.set(String(c.id), String(c.label || ''));
    }

    // Wat er al ligt, als feit. Zo herkennen we niet alleen letterlijke
    // herhaling maar ook "Nijmegen" tegenover "Woont in Nijmegen".
    const bestaand = new Map();
    for (const e of existing) {
      const f = factOf(e.text, '');
      if (f) bestaand.set(f.key, f);
    }
    // Per categorie de waarde die er nu staat — nodig om een wijziging te
    // herkennen in plaats van er een duplicaat van te maken.
    const perCategorie = new Map();
    for (const f of bestaand.values()) {
      if (f.category !== 'other') perCategorie.set(f.category, f.value);
    }

    const toWrite = [];
    const skipped = [];
    // Op WAARDE, niet op categorie+waarde. Bestaande regels komen als kale
    // tekst van het platform en dragen geen categorie mee: "Arnhem" wordt
    // 'other' en "Woont in Arnhem" wordt 'location'. Vergelijken op de sleutel
    // liet die twee dus langs elkaar heen gaan — precies het duplicaat dat de
    // klant zag. Dezelfde waarde is hetzelfde feit, ongeacht onder welk kopje
    // het gezet wordt.
    const gezien = new Set();
    for (const f of bestaand.values()) gezien.add(f.value);

    for (const kandidaat of candidates || []) {
      const categoryId = String(
        (kandidaat && (kandidaat.categoryId !== undefined ? kandidaat.categoryId : kandidaat.category)) || ''
      );
      const tekst = String((kandidaat && kandidaat.text) || '').trim();
      const meld = (reason, detail) =>
        skipped.push({ text: tekst, categoryId, reason, detail });

      if (!tekst) {
        meld('leeg');
        continue;
      }
      if (toWrite.length >= max) {
        meld('maximum-per-ronde');
        continue;
      }

      const label = labelVan.has(categoryId) ? labelVan.get(categoryId) : null;
      if (label === null) {
        meld('onbekende-categorie');
        continue;
      }

      const duurzaam = isDurable(tekst);
      if (!duurzaam.durable) {
        meld('niet-duurzaam', duurzaam.reason);
        continue;
      }

      if (requireAttestation) {
        const bewijs = attest(tekst, customerText);
        if (!bewijs.attested) {
          meld('niet-uit-klantbericht', bewijs.missing.join(', '));
          continue;
        }
      }

      const feit = factOf(tekst, label);
      if (!feit) {
        meld('leeg');
        continue;
      }
      if (gezien.has(feit.value)) {
        meld('staat-er-al');
        continue;
      }

      // Zelfde veld, andere waarde: dat is een wijziging en die hoort erin.
      // Een tweede woonplaats naast de eerste is geen duplicaat maar nieuws.
      const oud = perCategorie.get(feit.category);
      const isWijziging = feit.category !== 'other' && oud !== undefined && oud !== feit.value;

      gezien.add(feit.value);
      if (feit.category !== 'other') perCategorie.set(feit.category, feit.value);
      toWrite.push({
        categoryId,
        text: tekst,
        category: feit.category,
        value: feit.value,
        change: isWijziging ? { from: oud, to: feit.value } : null,
      });
    }

    return { toWrite, skipped };
  }

  root.ChatAssistant.facts = {
    SOURCE,
    isDurable,
    categoryOf,
    normaliseValue,
    stripLead,
    factOf,
    attest,
    validEntries,
    countValid,
    limitReached,
    reconcile,
  };
})(typeof globalThis !== 'undefined' ? globalThis : self);
