// Verboden woorden en zinnen. Puur tekst in, oordeel uit — geen DOM, geen
// opslag, geen netwerk. Draait daarom zowel in het content script als in de
// service worker (vandaar globalThis in plaats van window).
//
// Zie docs/superpowers/specs/ voor het ontwerp.

(function (root) {
  'use strict';

  root.ChatAssistant = root.ChatAssistant || {};

  // Alles wat een letter of cijfer is telt als "onderdeel van een woord".
  // Zo werkt de woordgrens ook bij accenten (café, hé) — \b doet dat niet.
  const WORD_CHAR = '[\\p{L}\\p{N}_]';

  function escapeRegExp(s) {
    return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  }

  // Eén item per regel. Lege regels en dubbele items vallen weg.
  // Accepteert zowel een tekstvak-inhoud als een al opgeslagen array, zodat
  // de popup en de service worker dezelfde functie kunnen gebruiken.
  function parse(input) {
    if (!input) return [];
    const lines = Array.isArray(input) ? input : String(input).split(/\r?\n/);
    const seen = new Set();
    const out = [];
    lines
      .forEach((line) => {
        const item = line.trim().replace(/\s+/g, ' ');
        if (!item) return;
        const key = item.toLowerCase();
        if (seen.has(key)) return;
        seen.add(key);
        out.push(item);
      });
    return out;
  }

  // Bevat het item een spatie, dan is het een zin en zoeken we hem als
  // fragment (met soepele witruimte). Anders is het één woord en moet het
  // een heel woord zijn — "aan" mag niet aanslaan binnen "daarvan".
  function toRegExp(item) {
    const tokens = item.split(/\s+/).filter(Boolean).map(escapeRegExp);
    if (tokens.length === 0) return null;

    if (tokens.length > 1) {
      return new RegExp(tokens.join('\\s+'), 'iu');
    }
    return new RegExp(`(?<!${WORD_CHAR})${tokens[0]}(?!${WORD_CHAR})`, 'iu');
  }

  // items: array uit parse(), of een string die we zelf nog parsen.
  // Geeft { ok, hits } — hits bevat de items die aansloegen, niet de
  // gevonden tekst, zodat de melding leesbaar blijft.
  function check(text, items) {
    const list = Array.isArray(items) ? items : parse(items);
    const subject = String(text == null ? '' : text);
    const hits = [];

    list.forEach((item) => {
      let re;
      try {
        re = toRegExp(item);
      } catch (e) {
        // Een item dat geen geldige regex oplevert slaan we over in plaats
        // van de hele controle te laten klappen. Contractregel 1.
        console.warn('[ChatAssistant] blocklist-item overgeslagen:', item, e);
        return;
      }
      if (re && re.test(subject)) hits.push(item);
    });

    return { ok: hits.length === 0, hits };
  }

  // Algemene lijst + accountlijst samengevoegd, zonder dubbelen.
  function merge(globalItems, accountItems) {
    return parse(parse(globalItems).concat(parse(accountItems)));
  }

  // ---- emoji ---------------------------------------------------------------
  //
  // Sommige platforms verbieden emoji volledig. Dat is een eigenschap van het
  // platform en staat daarom op de adapter (allowsEmoji), niet in de
  // accountinstellingen — anders is het een vinkje dat per ongeluk om kan.
  //
  // Extended_Pictographic dekt de emoji zelf. Huidskleur-modifiers,
  // variatieselectors, de zero-width joiner en vlagletters horen erbij,
  // anders blijven er losse onzichtbare tekens achter na het verwijderen.
  const EMOJI_RE =
    /[\p{Extended_Pictographic}\p{Regional_Indicator}\u{1F3FB}-\u{1F3FF}]|[\u{FE0F}\u{FE0E}\u{200D}\u{20E3}]/gu;

  function hasEmoji(value) {
    EMOJI_RE.lastIndex = 0;
    return EMOJI_RE.test(String(value || ''));
  }

  // Verwijderen is veilig: anders dan tekst inkorten breekt het geen zin. Wel
  // de dubbele spaties en de spatie vóór een leesteken opruimen die
  // achterblijven op de plek waar de emoji stond.
  function stripEmoji(value) {
    return String(value || '')
      .replace(EMOJI_RE, '')
      .replace(/[ \t]{2,}/g, ' ')
      .replace(/ +([.,!?;:])/g, '$1')
      .trim();
  }

  // ---- afspraken -----------------------------------------------------------
  //
  // Meerdere platforms verbieden het voorstellen van een echte ontmoeting.
  // moddies zet het zelf in rood boven de chat: wel verleiden, niet
  // misleiden. Fantaseren mag, een concrete afspraak niet.
  //
  // Dit hergebruikt bewust dezelfde matching als de verboden woorden: losse
  // woorden op woordgrens, zinnen als tekstfragment met soepele witruimte.
  // Geen tweede mechanisme dat apart stuk kan gaan.
  //
  // Vals alarm is hier goedkoop — dan wordt er één keer opnieuw gegenereerd.
  // Iets missen is duur, want dan gaat er een verboden bericht de deur uit.
  // TWEE LIJSTEN, WANT HET ZIJN TWEE REGELS.
  //
  // Ze stonden samen in één lijst, en dat werkte zolang beide altijd verboden
  // waren. Sinds de blauwe balk klopt dat niet meer: bij een klant zonder
  // credits mogen contactgegevens wél (gemaskeerd met sterretjes), maar een
  // concrete afspraak voorstellen nog steeds niet.
  //
  // Eén vlag voor twee regels betekende dat blauw ze allebei openzette. Dus:
  // apart.

  // Een echte ontmoeting. Nooit toegestaan, op geen enkele balk.
  const DATE_PHRASES = [
    'afspreken',
    'afspraak',
    'afspraakje',
    'afspreekt',
    'ontmoeten',
    'ontmoeting',
    'ontmoet elkaar',
    'elkaar zien',
    'zien we elkaar',
    'langskomen',
    'langs komen',
    'langs te komen',
    'bij mij thuis',
    'bij jou thuis',
    'naar mij toe',
    'naar jou toe',
    'uit eten',
    'koffie drinken',
    'wat drinken samen',
    'in het echt zien',
    'in real life',
    'dit weekend samen',
    'morgen samen',
    'vanavond samen',
  ];

  // Contact buiten het platform om. Verboden, behalve bij een blauwe balk —
  // en dan alleen gemaskeerd. Een echt telefoonnummer blijft ook daar
  // verboden; dat vangt PHONE_RE hieronder.
  const CONTACT_PHRASES = [
    'adres',
    'telefoonnummer',
    'mijn nummer',
    'je nummer',
    'jouw nummer',
    'nummer geven',
    'nummer wisselen',
    'nummers wisselen',
    'nummer sturen',
    'whatsapp',
    'whatsappen',
    'snapchat',
    'instagram',
    'telegram',
    'mailadres',
    'emailadres',
    'e-mailadres',
    'mobiel nummer',
  ];

  // De twee samen, voor de gevallen waarin allebei verboden is.
  const DATE_CONTACT_PHRASES = DATE_PHRASES.concat(CONTACT_PHRASES);

  // Een telefoonnummer is geen woord maar een cijferreeks, dus die valt
  // buiten de zinnenlijst. Acht of meer cijfers achter elkaar, eventueel met
  // spaties of streepjes ertussen, is in een chatbericht vrijwel altijd een
  // nummer.
  const PHONE_RE = /(?:\d[\s.-]?){8,}/;

  function hasPhoneNumber(value) {
    return PHONE_RE.test(String(value || ''));
  }

  // Stelt dit bericht een echte ontmoeting voor?
  function hasDateProposal(value) {
    return check(value, DATE_PHRASES).hits.length > 0;
  }

  function dateProposalHits(value) {
    return check(value, DATE_PHRASES).hits;
  }

  // Staan er contactgegevens in? Een echt telefoonnummer telt altijd mee —
  // ook waar contactgegevens mogen, want daar horen ze gemaskeerd te zijn.
  function hasContactDetails(value) {
    return check(value, CONTACT_PHRASES).hits.length > 0 || hasPhoneNumber(value);
  }

  function contactDetailHits(value) {
    return check(value, CONTACT_PHRASES).hits;
  }

  function hasDateOrContact(value) {
    return hasDateProposal(value) || hasContactDetails(value);
  }

  function dateOrContactHits(value) {
    return check(value, DATE_CONTACT_PHRASES).hits;
  }

  // ---- stopwoordjes --------------------------------------------------------
  //
  // "haha", "xxx" en familie zijn op zichzelf niet verboden, maar een model
  // strooit er graag mee en dan gaat elk bericht op elkaar lijken. De grens
  // staat daarom op nul: het model krijgt drie kansen om het anders te
  // formuleren.
  //
  // Het blijft een stijlregel, geen platformverbod. Lukt het na drie
  // pogingen echt niet, dan gaat het bericht alsnog door — een bericht
  // tegenhouden om een "haha" staat niet in verhouding tot het stilleggen
  // van de wachtrij.
  // De lijst is uitgebreid met wat het bureau in de praktijk terugzag:
  // "hmmm", "mama", "jahhh", "mwahhh" en rijen puntjes. De site rekent die
  // aan als grammaticafout, dus het is geen smaakkwestie meer.
  //
  // TWEE KLASSEN, EN WAAROM DAT MOET
  //
  // Een stopwoord wegstrepen is alleen veilig als het woord nooit betekenis
  // draagt. "haha" en "mwahhh" voldoen daaraan. "mama" niet: dat is meestal
  // een kreun, maar soms een moeder, en dan levert wegstrepen "Mijn is ziek
  // geweest" op — een kapotte zin, erger dan het stopwoord zelf.
  //
  // Zulke woorden tellen daarom wel mee als overtreding (het model schrijft
  // het opnieuw) maar worden nooit automatisch verwijderd. Dat kost soms een
  // herkansing; een onleesbaar bericht kost een klant.
  // Let op `ja+h+` en niet `jah+`: het gaat om "jaaahh" net zo goed als om
  // "jahh". De `+` op de a is wat "jaaahh" pakt. Losse "ja" blijft buiten
  // schot omdat er minstens één h achter moet staan.
  const STRIP_FILLER_RE =
    /\b(?:ha(?:ha)+h?|hi(?:hi)+|he(?:he)+|ho(?:ho)+|h+m{2,}|m{3,}|mwah+|ja+h+|ne+h+|lol|x{2,}|xoxo)\b/gi;

  const FLAG_ONLY_FILLER_RE = /\b(?:mama)\b/gi;

  // Twee of meer punten achter elkaar. Was drie; twee is ook al fout en de
  // site rekent het aan. Wegstrepen doen we niet — dan plakken twee zinnen
  // aan elkaar. Vervangen door één punt houdt de zinsgrens intact.
  const PUNCT_FILLER_RE = /\.{2,}/g;

  // ---- opgerekte woorden ---------------------------------------------------
  //
  // "jaaahh", "neeee", "leukkk", "echttt". Er bestaat geen Nederlands woord
  // met drie dezelfde letters achter elkaar, dus dit is altijd fout — en de
  // site rekent het aan als grammaticafout.
  //
  // ALLEEN SIGNALEREN, NIET REPAREREN.
  //
  // Terugbrengen naar twee letters werkt voor "neeee" (wordt "nee") maar niet
  // voor "jaaahh" (wordt "jaah") of "leukkk" (wordt "leukk"). Het model moet
  // het dus zelf opnieuw schrijven. De bekende kreten hierboven worden wél
  // weggestreept; deze regel is het vangnet voor alles wat we niet op naam
  // kennen.
  const STRETCHED_RE = /(\p{L})\1{2,}/gu;

  function stretchedHits(value) {
    const treffers = String(value || '').match(STRETCHED_RE);
    return treffers ? Array.from(new Set(treffers.map((t) => t.toLowerCase()))) : [];
  }

  const MAX_FILLERS = 0;

  // Tellen op positie, niet per regel.
  //
  // "hmmm" slaat op twee regels tegelijk aan: het staat in de stopwoordenlijst
  // én het heeft drie dezelfde letters. Optellen zou dat als twee problemen
  // rapporteren terwijl er één woord fout is. Dat getal komt in de console
  // terecht en moet dus kloppen — een diagnostiek die overdrijft stuurt je de
  // verkeerde kant op.
  //
  // Overlappende treffers tellen daarom als één.
  function countFillers(value) {
    const subject = String(value || '');
    const ranges = [];

    for (const bron of [
      STRIP_FILLER_RE,
      FLAG_ONLY_FILLER_RE,
      PUNCT_FILLER_RE,
      STRETCHED_RE,
    ]) {
      // Een eigen exemplaar per ronde: deze regexes hebben de g-vlag en dus
      // een lastIndex die tussen aanroepen blijft staan.
      const re = new RegExp(bron.source, bron.flags);
      let m;
      while ((m = re.exec(subject)) !== null) {
        if (m[0] === '') { re.lastIndex++; continue; }
        ranges.push([m.index, m.index + m[0].length]);
      }
    }

    ranges.sort((a, b) => a[0] - b[0]);

    let n = 0;
    let tot = -1;
    for (const [start, eind] of ranges) {
      if (start >= tot) {
        n++;
        tot = eind;
      } else if (eind > tot) {
        tot = eind;
      }
    }
    return n;
  }

  function tooManyFillers(value, max) {
    const grens = typeof max === 'number' ? max : MAX_FILLERS;
    return countFillers(value) > grens;
  }

  // Weghalen in plaats van opnieuw laten schrijven. Een stopwoord draagt per
  // definitie geen betekenis, dus het weglaten kan de strekking niet
  // aantasten — anders dan inkorten, wat wel inhoud kost.
  //
  // Dit scheelt een hele API-call per overtreding. Bij Haiku 4.5, dat er
  // gulzig mee strooit, was dit de duurste herkansingsreden van allemaal.
  //
  // De opruiming eromheen is het echte werk: "Haha! Jij bent snel" wordt
  // anders "! Jij bent snel", en dat is een grammaticafout in plaats van een
  // oplossing.
  function stripFillers(value) {
    let out = String(value || '')
      .replace(STRIP_FILLER_RE, '')
      // Eén punt in plaats van niets, anders plakken twee zinnen aan elkaar.
      .replace(PUNCT_FILLER_RE, '.');

    out = out
      // Leestekens die alleen nog aan het weggehaalde stopwoord hingen.
      .replace(/^[\s!?,.;:-]+/, '')
      .replace(/([!?,.;:])[\s]*\1+/g, '$1')
      .replace(/\s+([!?,.;:])/g, '$1')
      .replace(/[ \t]{2,}/g, ' ')
      // Een lege regel waar het stopwoord op zijn eentje stond.
      .replace(/\n{3,}/g, '\n\n')
      .trim();

    // Zonder dit staat er een kleine letter waar het stopwoord stond, en
    // dat is precies de grammaticafout die de site aanrekent.
    out = out.replace(/([.!?])\s+(\p{Ll})/gu, (m, leesteken, letter) =>
      `${leesteken} ${letter.toUpperCase()}`
    );
    if (out) out = out.charAt(0).toUpperCase() + out.slice(1);
    return out;
  }

  root.ChatAssistant.blocklist = {
    parse,
    check,
    merge,
    hasEmoji,
    stripEmoji,
    hasDateOrContact,
    hasPhoneNumber,
    countFillers,
    tooManyFillers,
    stripFillers,
    stretchedHits,
    MAX_FILLERS,
    dateOrContactHits,
    hasDateProposal,
    dateProposalHits,
    hasContactDetails,
    contactDetailHits,
    DATE_PHRASES,
    CONTACT_PHRASES,
    DATE_CONTACT_PHRASES,
  };
})(typeof globalThis !== 'undefined' ? globalThis : self);
