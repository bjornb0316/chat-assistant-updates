// Wat de gekleurde balk boven de wachtrij betekent voor wat er wel en niet in
// een bericht mag. Puur kleur in, beleid uit — geen DOM, geen opslag, geen
// netwerk. De adapter leest alleen de kleur; de betekenis staat hier, op één
// testbare plek.
//
// DE KLEUREN, ZOALS HET BUREAU ZE GEBRUIKT (opgegeven 19-08-2026)
//
//   geel  — nieuwe klant, begin van een gesprek. Nooit zelf over seks
//           beginnen; volgt de klant erin mee, dan mag het wel.
//   rood  — seks mag, ook als wij ermee beginnen.
//   blauw — de klant heeft geen credits meer. Contactgegevens uitwisselen mag
//           hier wél, gemaskeerd met sterretjes.
//
// EN OP ALLE DRIE: NOOIT EEN ECHTE AFSPRAAK VOORSTELLEN.
//
// Dat stond hier eerst anders. Blauw zou "datinggericht" zijn, inclusief
// "kunnen we dit weekend afspreken". Op 20-08-2026 gecorrigeerd door het
// bureau: gegevens uitwisselen en een ontmoeting voorstellen zijn twee
// verschillende dingen. Het eerste mag bij blauw, het tweede nergens.
//
// WAAROM ONBEKEND HET STRENGST IS
//
// Deze kleuren zijn niet geverifieerd tegen een live rode of blauwe balk — er
// was alleen een gele om naar te kijken. Verandert de site de opmaak, of
// wordt de balk niet gevonden, dan levert raden een fout bericht op bij een
// echte klant. Vandaar: alles wat we niet herkennen valt terug op de
// strengste stand, en die is gelijk aan hoe de extensie zich hiervóór altijd
// gedroeg. Een gemiste kleur kan dus nooit iets erger maken dan het al was.

(function (root) {
  'use strict';

  root.ChatAssistant = root.ChatAssistant || {};

  // De strengste stand, en tegelijk het gedrag van vóór de kleurbalk.
  // allowsDateProposal staat NERGENS op true. Een echte ontmoeting voorstellen
  // mag op geen enkele balk — opgegeven door het bureau op 20-08-2026. Het
  // veld staat er wel, zodat de bedoeling in de code zichtbaar is en niet
  // alleen in de afwezigheid van iets.
  const STRENGST = {
    colour: null,
    label: 'onbekend',
    allowsDateProposal: false,
    allowsContactDetails: false,
    allowsSexInitiative: false,
    masksContactDetails: false,
  };

  const BELEID = {
    yellow: {
      colour: 'yellow',
      label: 'geel — nieuwe klant',
      allowsDateProposal: false,
      allowsContactDetails: false,
      // De harde regel van het bureau: bij een nieuwe klant beginnen wij er
      // nooit zelf over. Begint de klant, dan mag meegaan.
      allowsSexInitiative: false,
      masksContactDetails: false,
    },
    red: {
      colour: 'red',
      label: 'rood — seks toegestaan',
      allowsDateProposal: false,
      allowsContactDetails: false,
      allowsSexInitiative: true,
      masksContactDetails: false,
    },
    blue: {
      colour: 'blue',
      label: 'blauw — klant zonder credits',
      // Het enige geval waarin contactgegevens gewenst zijn — gemaskeerd met
      // sterretjes, dus er lekt niets echts weg.
      //
      // Maar een concrete afspraak voorstellen mag hier NIET. Dat was eerst
      // wel zo en is op 20-08-2026 gecorrigeerd: gegevens uitwisselen en een
      // ontmoeting voorstellen zijn twee verschillende dingen, en alleen het
      // eerste hoort bij een blauwe balk.
      allowsDateProposal: false,
      allowsContactDetails: true,
      allowsSexInitiative: true,
      masksContactDetails: true,
    },
  };

  // Browsers geven een inline `background-color:yellow` terug als "yellow",
  // maar een gestileerde variant als "rgb(255, 255, 0)". Beide moeten werken,
  // en een tint die er net naast zit ook — de site kan morgen #FFEB3B
  // gebruiken zonder dat dat iets betekent.
  const NAMEN = {
    yellow: 'yellow',
    gold: 'yellow',
    red: 'red',
    crimson: 'red',
    firebrick: 'red',
    blue: 'blue',
    dodgerblue: 'blue',
    royalblue: 'blue',
    lightblue: 'blue',
    cornflowerblue: 'blue',
  };

  function parseRgb(value) {
    const m = /rgba?\(\s*(\d+)[,\s]+(\d+)[,\s]+(\d+)/i.exec(value);
    if (!m) return null;
    return [Number(m[1]), Number(m[2]), Number(m[3])];
  }

  function parseHex(value) {
    const m = /^#([0-9a-f]{3}|[0-9a-f]{6})$/i.exec(String(value).trim());
    if (!m) return null;
    let h = m[1];
    if (h.length === 3) h = h[0] + h[0] + h[1] + h[1] + h[2] + h[2];
    return [
      parseInt(h.slice(0, 2), 16),
      parseInt(h.slice(2, 4), 16),
      parseInt(h.slice(4, 6), 16),
    ];
  }

  // Welke van de drie kleuren ligt het dichtst bij wat er staat? Bewust grof:
  // we hoeven alleen geel van rood van blauw te onderscheiden, en die liggen
  // ver uit elkaar. Is niets duidelijk dominant — grijs, wit, zwart — dan
  // geven we niets terug en valt het beleid terug op de strengste stand.
  function classifyRgb(rgb) {
    const [r, g, b] = rgb;
    const max = Math.max(r, g, b);
    const min = Math.min(r, g, b);

    // Te weinig kleur om iets van te zeggen.
    if (max - min < 40) return null;

    if (b === max && b - Math.max(r, g) > 30) return 'blue';
    if (r === max && g > 150 && Math.abs(r - g) < 90 && b < Math.min(r, g) - 40) {
      return 'yellow';
    }
    if (r === max && r - Math.max(g, b) > 40) return 'red';
    return null;
  }

  // value: wat de adapter uit de stijl van de balk haalt. Mag een naam
  // ("yellow"), een rgb-string of een hexcode zijn.
  function normalise(value) {
    const raw = String(value == null ? '' : value).trim().toLowerCase();
    if (!raw) return null;

    if (NAMEN[raw]) return NAMEN[raw];

    const rgb = parseRgb(raw) || parseHex(raw);
    return rgb ? classifyRgb(rgb) : null;
  }

  function policyFor(value) {
    const kleur = normalise(value);
    return kleur && BELEID[kleur] ? BELEID[kleur] : STRENGST;
  }

  root.ChatAssistant.stage = {
    policyFor,
    normalise,
    STRENGST,
  };
})(typeof globalThis !== 'undefined' ? globalThis : self);
