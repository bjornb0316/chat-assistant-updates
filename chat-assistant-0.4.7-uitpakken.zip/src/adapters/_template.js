// Sjabloon voor een nieuwe adapter. NIET geregistreerd in manifest.json —
// kopieer dit bestand, vul in, en zet het pas in manifest.json + index.js
// zodra hij werkt. Zie docs/02-ADAPTER-CONTRACT.md.

window.ChatAssistant = window.ChatAssistant || {};
ChatAssistant._factories = window.ChatAssistant._factories || [];

(function () {
  const { setNativeValue, qs, qsa, text, safe, emptyProfile } = ChatAssistant.dom;

  const SEL = {
    input: '', // TODO
    sendButton: '', // TODO
  };

  function createTemplateAdapter() {
    const adapter = {
      id: '', // TODO — stabiele sleutel, gebruikt in instellingen
      label: '', // TODO — wat de gebruiker ziet
      matches: [], // TODO — host_permissions-patroon

      // Mag de extensie het voorstel in het invoerveld schrijven? Zet dit op
      // false als de site ingevoegde tekst weigert; het voorstel komt dan in
      // een paneel naast de chat en de operator typt het zelf over.
      allowsDraftInsert: true,

      // Mag het antwoord emoji bevatten? Verbiedt het platform ze, zet dit
      // dan op false; de extensie haalt ze er dan gegarandeerd uit.
      allowsEmoji: true,

      // Mag het antwoord een echte afspraak voorstellen? Bij twijfel false:
      // de meeste platforms verbieden dit.
      allowsContactOrDates: false,

      // Mag de extensie op dit platform zelf op verzenden drukken?
      // Bij twijfel: false. Dit is een eigenschap van het platform, geen
      // voorkeur van de gebruiker, en is daarom niet in te stellen via de popup.
      allowsAutoSend: false,

      isChatPage() {
        return safe(() => !!qs(document, SEL.input), false);
      },

      isReady() {
        return safe(() => !!qs(document, SEL.input), false);
      },

      getConversationId() {
        return safe(() => null, null); // TODO
      },

      getMessages() {
        return safe(() => [], []); // TODO
      },

      getCustomer() {
        return safe(() => emptyProfile(), emptyProfile()); // TODO
      },

      getPersona() {
        return safe(() => emptyProfile(), emptyProfile()); // TODO
      },

      getAttachments() {
        return safe(() => [], []); // TODO
      },

      getContext() {
        return safe(
          () => ({
            conversationId: adapter.getConversationId(),
            platform: adapter.id,
            attachmentsLoaded: false,
            operatorName: null, // TODO — hier hangt accountherkenning aan
            extra: {},
          }),
          null
        );
      },

      // Logboek nog niet gemeten op dit platform; null betekent: sla over.
      getLogbook() {
        return null;
      },

      getInputElement() {
        return safe(() => qs(document, SEL.input), null);
      },

      // Alleen teruggeven, nooit zelf indrukken — zie contractregel in
      // docs/02-ADAPTER-CONTRACT.md.
      getSendButton() {
        return safe(() => qs(document, SEL.sendButton), null);
      },

      setDraft(replyText) {
        return safe(() => setNativeValue(adapter.getInputElement(), replyText), false);
      },

      getStatusAnchor() {
        return safe(() => document.body, null);
      },
    };
    return adapter;
  }

  ChatAssistant._factories.push(createTemplateAdapter);
})();
