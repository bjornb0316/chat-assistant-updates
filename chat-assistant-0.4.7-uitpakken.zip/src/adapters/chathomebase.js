// Adapter: ChatHomeBase — zie docs/02-ADAPTER-CONTRACT.md
//
// Vue/Vuetify-SPA. Geen paginaherlading bij verzenden: het DOM wordt bijgewerkt,
// dus de adapter blijft gewoon leven. Dat is precies andersom dan bij
// OperatorPanel.
//
// Selectors geverifieerd tegen de live site op 17-08-2026, ingelogd in een
// geclaimde chat op /chat/claimed. Deze site is veel netter gelabeld dan
// OperatorPanel: bijna alles is met een data-testid te pakken, en de rol staat
// expliciet als class op de berichtbubbel in plaats van dat je hem moet
// afleiden.
//
// Wat er is nagekeken en klopt:
//   * De berichten staan OUD -> NIEUW (12:07 boven, 13:08 eronder) — dus
//     precies zoals het contract wil, geen omdraaien nodig. Let op het
//     verschil met OperatorPanel, waar het andersom is.
//   * De rol staat als class op de bubbel: `message-customer` is de klant,
//     `message-profile` is het profiel waarachter we zitten.
//   * De twee profielkolommen zijn `.profile-drawer`. Welke van de twee wie is,
//     is te bepalen aan de logboek-knop erin: `-customer` versus
//     `-entertainmentProfile`. Niet op volgorde vertrouwen.
//   * De ingelogde operatornaam staat in `usernameText` (bijv. "YOPSNL99196").
//     Dat is een inlognaam, geen mensennaam — vul in de popup exact die string
//     in.
//
// Nog NIET geverifieerd (zie docs/02-ADAPTER-CONTRACT.md):
//   * Of `messagesList` oudere berichten pas bijlaadt bij omhoogscrollen. De
//     geteste chat had er maar twee. Zo ja, dan ziet het model alleen wat er
//     op dat moment in het DOM staat.
//   * De losse profielregels (haar, ogen, lengte) hebben geen eigen testid; die
//     worden op tekstpatroon herkend. Wat daar niet uit komt, blijft via `raw`
//     alsnog beschikbaar voor het model.

window.ChatAssistant = window.ChatAssistant || {};
ChatAssistant._factories = window.ChatAssistant._factories || [];

(function () {
  const { setNativeValue, qs, qsa, text, safe, emptyProfile } = ChatAssistant.dom;

  const SEL = {
    input: 'textarea[data-testid="messageTextArea"]',
    sendButton: '[data-testid="sendChatMessageButton"]',
    messagesList: '[data-testid="messagesList"]',
    messageItem: '[data-testid="messageItem"]',
    messageBulb: '[data-testid^="messageBulb-"]',
    messageContent: 'span.message-content',
    messageAttachment: '[data-testid="messageAttachment"]',
    createdAt: '.created-at',
    chatId: '[data-testid="chat-id"]',
    operatorName: '[data-testid="usernameText"]',
    tenantId: '[data-testid="tenantId"]',
    // Profielkolommen. De anchors zijn de logboek-knoppen: die zeggen als
    // enige hard wélke kolom van wie is.
    profileDrawer: '.profile-drawer',
    customerAnchor: '[data-testid="addNewLogbookButton-customer"]',
    personaAnchor: '[data-testid="addNewLogbookButton-entertainmentProfile"]',
    profileName: '[data-testid="profileNameItem"]',
    profileRealName: '[data-testid="profileRealName"]',
    profileCivilStatus: '[data-testid="profileCivilStatus"]',
    // Logboek. Gemeten 18-08-2026 op een geclaimde chat.
    logbookAdd: '[data-testid="addNewLogbookButton-customer"]',
    logbookCategoryBlock: '[data-testid^="logbookCategory-"]',
    logbookComment: '[data-testid^="logbookComment-"]',
    logbookDialog: '.v-overlay--active',
    logbookDialogText: 'textarea',
    logbookDialogSelect: 'input[type="text"]',
    logbookMenuItem: '.v-list-item',
    logbookSave: '[data-testid="logbookSaveButton"]',
    logbookCancel: '[data-testid="logbookCancelButton"]',
  };

  // "12:07 Mon, Aug 17, 2026 — an hour ago"
  const CREATED_AT_RE = /^(\d{1,2}:\d{2})\s+\w{3},\s+(\w{3})\s+(\d{1,2}),\s+(\d{4})/;
  const MONTHS = {
    Jan: '01', Feb: '02', Mar: '03', Apr: '04', May: '05', Jun: '06',
    Jul: '07', Aug: '08', Sep: '09', Oct: '10', Nov: '11', Dec: '12',
  };

  // "Celine, 34" -> naam + leeftijd. Een streepje betekent "niet ingevuld".
  const REAL_NAME_RE = /^(.*?),\s*(\d{1,3})$/;

  function createChathomebaseAdapter() {
    // Een half geopend dialoogvenster laten staan is erger dan niets doen:
    // dan zit de operator met een venster dat hij zelf moet wegklikken.
    function abort() {
      const dialog = qs(document, SEL.logbookDialog);
      const cancel = dialog ? qs(dialog, SEL.logbookCancel) : null;
      if (cancel) cancel.click();
      return false;
    }

    function wait(ms) {
      return new Promise((resolve) => setTimeout(resolve, ms));
    }

    // ---- profielkolommen ---------------------------------------------------

    function drawer(anchorSel) {
      const anchor = qs(document, anchorSel);
      return anchor ? anchor.closest(SEL.profileDrawer) : null;
    }

    // Een streepje op deze site betekent "leeg"; het contract wil dan null.
    function clean(value) {
      if (!value) return null;
      const trimmed = value.trim();
      if (!trimmed || trimmed === '—' || trimmed === '-') return null;
      return trimmed;
    }

    function buildProfile(col) {
      const profile = emptyProfile();
      if (!col) return profile;

      profile.nickname = clean(text(qs(col, SEL.profileName)));
      profile.maritalStatus = clean(text(qs(col, SEL.profileCivilStatus)));

      const realName = text(qs(col, SEL.profileRealName));
      const m = REAL_NAME_RE.exec(realName || '');
      if (m) {
        profile.name = clean(m[1]);
        profile.age = Number(m[2]);
      }

      // De overige velden staan als losse regels zonder eigen testid. Ze zijn
      // Engelstalig en volgen een vast patroon, dus op patroon te herkennen.
      const lines = (col.innerText || '')
        .split('\n')
        .map((line) => line.trim())
        .filter(Boolean);

      for (const line of lines) {
        const upper = line.toUpperCase();

        if (upper.startsWith('TIMEZONE:')) {
          profile.timezone = clean(line.slice(line.indexOf(':') + 1));
          continue;
        }
        if (upper.startsWith('LOCALITY:')) {
          profile.location = clean(line.slice(line.indexOf(':') + 1));
          continue;
        }
        if (/^Age:\s*\d+/i.test(line)) {
          profile.age = profile.age || Number(/(\d+)/.exec(line)[1]);
          continue;
        }
        if (/^\d{4}-\d{2}-\d{2}$/.test(line)) {
          profile.birthdate = line;
          continue;
        }
        if (/\bhair$/i.test(line)) {
          profile.hairColour = line;
          continue;
        }
        if (/\beyes$/i.test(line)) {
          profile.eyeColour = line;
          continue;
        }
        if (/^\d{2,3}\s*-\s*\d{2,3}\s*cm$/i.test(line)) {
          profile.heightLabel = line;
          const low = /(\d+)/.exec(line);
          if (low) profile.height = Number(low[1]);
          continue;
        }
        if (/smoking$/i.test(line)) {
          profile.smoker = line;
          continue;
        }
      }

      // Vangnet uit het contract: alles wat we niet apart uitlezen hoort hier
      // alsnog in te staan.
      profile.raw = text(col);
      return profile;
    }

    // ---- adapter -----------------------------------------------------------

    const adapter = {
      id: 'chathomebase',
      label: 'ChatHomeBase',
      matches: ['*://*.chathomebase.com/*'],

      // Deze site haalt zichzelf al op — het gesprek verschijnt vanzelf zodra
      // er een wordt toegewezen. Onze eigen verversing zou daar bovenop komen
      // en is dus puur extra verkeer zonder dat er iets mee opschiet.
      refreshesItself: true,

      // Stond op `false` vanwege "You triggered our copy paste warning. Your
      // text won't be inserted." Op 19-08-2026 meldde de operator dat die
      // waarschuwing er niet is en dat de tekst gewoon in het veld belandt —
      // de eerdere waarneming was een misverstand.
      //
      // Daarom weer aan, maar niet op goed vertrouwen: setDraft hieronder
      // kijkt zelf na of de tekst er ook echt in blijft staan. Weigert de site
      // hem alsnog, dan geeft setDraft `false` terug en valt content.js terug
      // op het paneel. Zo hoeft niemand te gokken en gaat er niets stuk als de
      // controle er tóch blijkt te zijn.
      //
      // Dit is nadrukkelijk geen omzeiling: als het platform nee zegt,
      // accepteren we dat nee. Zie docs/01-SCOPE.md.
      allowsDraftInsert: true,
      allowsEmoji: true,

      // Een concrete ontmoeting voorstellen mag hier niet. Fantaseren wel.
      allowsContactOrDates: false,

      // Blijft uit, ook nu invoegen weer aan staat.
      //
      // Dat invoegen kan, betekent niet dat zelf verzenden moet. Vandaag is er
      // een moddies-account geblokkeerd; dit is niet het moment om op een
      // derde platform meer te automatiseren. Jij drukt hier op verzenden, of
      // op Ctrl+Enter.
      allowsAutoSend: false,

      isChatPage() {
        return safe(() => !!qs(document, SEL.input), false);
      },

      isReady() {
        return safe(() => !!qs(document, SEL.input) && !!qs(document, SEL.messagesList), false);
      },

      getConversationId() {
        return safe(() => {
          const el = qs(document, SEL.chatId);
          const value = text(el);
          return value || null;
        }, null);
      },

      getMessages() {
        return safe(() => {
          const items = qsa(document, SEL.messageItem);
          const messages = [];

          for (const item of items) {
            const bulb = qs(item, SEL.messageBulb);
            const bulbClass = bulb ? String(bulb.className || '') : '';

            // De expliciete class is de bron. Uitlijning is alleen een
            // achtervang voor als de site die classnaam ooit hernoemt.
            let role = null;
            if (bulbClass.includes('message-customer')) role = 'customer';
            else if (bulbClass.includes('message-profile')) role = 'operator';
            else if (item.className.includes('align-start')) role = 'customer';
            else if (item.className.includes('align-end')) role = 'operator';
            if (!role) continue; // niet gokken — zie contractregel

            // De bubbel bevat ook een type-label ("poke") en de tijd; alleen
            // de content-span is de eigenlijke berichttekst.
            const body = text(qs(item, SEL.messageContent));
            const hasImage = !!qs(item, SEL.messageAttachment);
            if (!body && !hasImage) continue;

            messages.push({
              role,
              text: body,
              timestamp: parseCreatedAt(text(qs(item, SEL.createdAt))),
              hasImage,
            });
          }

          // Geen reverse: deze site zet het nieuwste onderaan, wat al de
          // volgorde is die het contract vraagt.
          return messages;
        }, []);
      },

      getCustomer() {
        return safe(() => buildProfile(drawer(SEL.customerAnchor)), emptyProfile());
      },

      getPersona() {
        return safe(() => buildProfile(drawer(SEL.personaAnchor)), emptyProfile());
      },

      getAttachments() {
        // v2-scope (zie docs/01-SCOPE.md) — v1 stuurt altijd attachmentsLoaded: false.
        return safe(() => [], []);
      },

      getContext() {
        return safe(() => {
          const customer = drawer(SEL.customerAnchor);
          const persona = drawer(SEL.personaAnchor);

          return {
            conversationId: adapter.getConversationId(),
            platform: 'chathomebase',
            attachmentsLoaded: false,
            // Inlognaam van de operator, bijv. "YOPSNL99196".
            operatorName: text(qs(document, SEL.operatorName)) || null,
            extra: {
              tenantId: text(qs(document, SEL.tenantId)) || null,
              personaNickname: persona ? text(qs(persona, SEL.profileName)) || null : null,
              customerNickname: customer ? text(qs(customer, SEL.profileName)) || null : null,
            },
          };
        }, null);
      },

      // ---- logboek ---------------------------------------------------
      //
      // Anders dan de andere twee zit het invullen hier achter een
      // dialoogvenster met een Vuetify-keuzelijst. Die is niet met een
      // waarde te zetten; je moet het menu openen en de regel aanklikken.
      // Daarom is setLogbookEntry hier asynchroon.
      //
      // Het tekstveld van het logboek accepteert wél ingevoegde tekst —
      // gemeten, zonder de copy-paste-waarschuwing die het berichtveld wel
      // geeft. De blokkade van deze site zit dus alleen op berichten.

      // Het dossier van de persona is op deze site nooit gemeten. De knop
      // heet `addNewLogbookButton-customer`, dus er is waarschijnlijk een
      // tegenhanger — maar waarschijnlijk is niet genoeg om persona-feiten op
      // te schrijven. Zonder deze regel zou een aanroep met 'persona' hier
      // stilzwijgend het KLANTdossier teruggeven en zouden verzonnen feiten
      // over de persona in het dossier van een echte klant belanden.
      getLogbook(target) {
        if (target === 'persona') return null;
        return safe(() => {
          const anchor = qs(document, SEL.logbookAdd);
          if (!anchor) return null;
          const col = anchor.closest(SEL.profileDrawer);
          if (!col) return null;

          // De categorieën staan als eigen blokken in de kolom, met hun
          // sleutel in het testid en hun naam in de bijbehorende titel.
          const categories = qsa(col, SEL.logbookCategoryBlock).map((el) => {
            const slug = (el.getAttribute('data-testid') || '').replace('logbookCategory-', '');
            const title = qs(col, '[data-testid="logbookCategoryTitle-' + slug + '"]');
            return { id: slug, label: text(title) || slug };
          });

          const existing = qsa(col, SEL.logbookComment)
            .map((el) => ({ text: text(el) }))
            .filter((e) => e.text);

          return { categories, existing };
        }, null);
      },

      // Geeft een Promise terug in plaats van een boolean; content.js wacht
      // erop. Zie docs/02-ADAPTER-CONTRACT.md.
      async setLogbookEntry(entry) {
        if (entry && entry.target === 'persona') return false;
        try {
          if (!entry || !entry.categoryId || !entry.text) return false;

          const book = adapter.getLogbook();
          const category = book && book.categories.find(
            (c) => String(c.id) === String(entry.categoryId)
          );
          if (!category) return false;

          const add = qs(document, SEL.logbookAdd);
          if (!add) return false;
          add.click();
          await wait(500);

          const dialog = qs(document, SEL.logbookDialog);
          if (!dialog) return false;

          // Categorie kiezen: menu openen en de regel met deze naam klikken.
          const trigger = qs(dialog, SEL.logbookDialogSelect);
          if (!trigger) return abort();
          trigger.click();
          await wait(500);

          const item = qsa(document, SEL.logbookMenuItem).find(
            (el) => text(el).toLowerCase() === String(category.label).toLowerCase()
          );
          if (!item) return abort();
          item.click();
          await wait(300);

          const field = qsa(dialog, SEL.logbookDialogText).find((t) => !t.readOnly);
          if (!field) return abort();
          return setNativeValue(field, entry.text);
        } catch (e) {
          console.warn('[ChatAssistant]', e);
          return abort();
        }
      },

      getLogbookSubmitButton(target) {
        // Zie getLogbook: het dossier van de persona is hier niet gemeten.
        if (target === 'persona') return null;
        return safe(() => {
          const dialog = qs(document, SEL.logbookDialog);
          return dialog ? qs(dialog, SEL.logbookSave) : null;
        }, null);
      },


      getInputElement() {
        return safe(() => qs(document, SEL.input), null);
      },

      // Alleen teruggeven, nooit zelf indrukken — zie contractregel in
      // docs/02-ADAPTER-CONTRACT.md. content.js drukt hem in, en alleen na
      // een echte toetsaanslag van de gebruiker.
      getSendButton() {
        return safe(() => qs(document, SEL.sendButton), null);
      },

      // Schrijven én nakijken. Deze site heeft ooit ingevoegde tekst geweigerd
      // met een zichtbare waarschuwing; of dat nog zo is weten we niet zeker.
      // In plaats van dat te gokken, controleren we het resultaat: staat de
      // tekst er niet, dan is dit mislukt en hoort de operator het paneel te
      // krijgen.
      //
      // De controle is bewust simpel — alleen kijken of het veld bevat wat we
      // erin gezet hebben. Dat vangt zowel een leeggemaakt veld als een veld
      // dat de site heeft teruggedraaid.
      setDraft(replyText) {
        return safe(() => {
          const el = adapter.getInputElement();
          if (!el) return false;

          if (!setNativeValue(el, replyText)) return false;

          const gewenst = String(replyText || '').trim();
          const staat = String(el.value || '').trim();
          if (staat !== gewenst) {
            console.warn(
              '[ChatAssistant] ChatHomeBase heeft de ingevoegde tekst niet ' +
                'geaccepteerd — het voorstel gaat naar het paneel.'
            );
            return false;
          }
          return true;
        }, false);
      },

      getStatusAnchor() {
        return safe(() => document.body, null);
      },
    };

    return adapter;
  }

  // "12:07 Mon, Aug 17, 2026 — an hour ago" -> "2026-08-17T12:07".
  // De site geeft geen tijdzone mee, dus die laten we eraf.
  function parseCreatedAt(value) {
    const m = CREATED_AT_RE.exec(value || '');
    if (!m) return null;
    const month = MONTHS[m[2]];
    if (!month) return null;
    const day = m[3].padStart(2, '0');
    const time = m[1].padStart(5, '0');
    return `${m[4]}-${month}-${day}T${time}`;
  }

  ChatAssistant._factories.push(createChathomebaseAdapter);
})();
