// Adapter: moddies.be — zie docs/02-ADAPTER-CONTRACT.md
//
// Server-gerenderd (UIkit). Bijzonder aan deze site is de doorlaadpagina: je
// krijgt één gesprek tegelijk en de pagina schuift vanzelf door naar het
// volgende als er niets gebeurt. De URL blijft daarbij altijd
// /doorlaadpagina — die is dus onbruikbaar als gesprek-ID.
//
// Selectors geverifieerd tegen de live site op 17-08-2026.
// Wat daar bleek:
//   * Berichten staan NIEUWSTE BOVENAAN — omdraaien, net als bij
//     OperatorPanel en andersom dan bij ChatHomeBase.
//   * De rol staat als class: `bg-blue` op de binnenste grid is ons bericht,
//     zonder die class is het de klant. Bevestigd over 10 berichten.
//   * Bij onze berichten staat in `span.uk-label` wie het tikte (bijv.
//     Oper366). Meerdere operators delen één gesprek; dat is hier normaal.
//   * `#dt_start` bevat "Customer 209 / Length 0 / Min 75 / Max 500" — daar
//     komen zowel het gesprek-ID als de lengtegrenzen vandaan.
//   * De ingelogde operatornaam staat in `span.ingelogd-als`.

window.ChatAssistant = window.ChatAssistant || {};
ChatAssistant._factories = window.ChatAssistant._factories || [];

(function () {
  const { setNativeValue, qs, qsa, text, safe, emptyProfile } = ChatAssistant.dom;

  const SEL = {
    input: '#emojioneTextarea',
    sendButton: '#bt-send',
    messages: 'li[id^="msg-"]',
    messagesList: 'ul.messages-list',
    meta: '#dt_start',
    operatorName: 'span.ingelogd-als',
    personaAnchor: '#from-actueel-input',
    customerAnchor: '#to-actueel-input',
    profileColumn: 'div.uk-width-1-5',
    // De tekstkolom van een bericht. De linkerkolom (uk-width-1-6) bevat de
    // avatar; die mag NOOIT als bijlage tellen, anders slaat de fotonoodrem
    // bij elk bericht aan.
    messageBody: 'div.uk-width-5-6',
    // De eigenlijke berichttekst staat in een kaal <div> in die kolom. De rest
    // eromheen is strong/span/a met de afzender, de operatorcode en de tijd —
    // die horen niet in de tekst die het model te zien krijgt.
    messageText: 'div.uk-width-5-6 > div',
    // Afbeeldingen in de tekstkolom die géén bijlage zijn: het leesvinkje, en
    // emoji — deze site rendert die als plaatje in plaats van als teken.
    // Gemeten 17-08-2026: zónder deze uitzondering zou één emoji van de klant
    // de fotonoodrem intrappen.
    nonAttachment: 'img.message-status, img.joypixels',
    // Logboek. De klantkolom heeft twee blokken: "Events" (met datum) en
    // "Logs" (losse feiten). Wij gebruiken alleen Logs — Events gaan over
    // afspraken en vragen een datum, en die verzinnen we niet.
    logbookBlock: '#to-notitie-input',
    // Het profiel van de persona heeft zijn eigen notitieblok. De site
    // gebruikt overal het paar to-/from- voor klant en persona (zie
    // personaAnchor en customerAnchor hierboven), dus dit is de te
    // verwachten naam. Bestaat hij niet, dan geeft getLogbook('persona')
    // gewoon null terug en gebeurt er niets — geen gok die stuk kan.
    personaLogbookBlock: '#from-notitie-input',
    logbookText: 'textarea',
    logbookCategory: 'select',
    logbookSubmit: 'button',
  };

  const META_RE = {
    customer: /Customer\s+(\d+)/i,
    min: /Min\s+(\d+)/i,
    max: /Max\s+(\d+)/i,
  };

  // "Daltons68 36 CREDITS" -> "Daltons68"
  // Een bestaande logregel ziet eruit als "Oper130 17 aug'26 17-08-2026 19:03
  // <de tekst>". Voor het ontdubbelen willen we alleen de tekst, zonder de
  // operator en de tijdstempels ervoor.
  const LOG_PREFIX_RE = /^\S+\s+\d{1,2}\s+\w{3}'\d{2}\s+\d{2}-\d{2}-\d{4}\s+\d{2}:\d{2}\s+/;

  const CREDITS_RE = /\s+\d+\s+CREDITS\s*$/i;

  function createModdiesAdapter() {
    function meta() {
      return text(qs(document, SEL.meta));
    }

    function metaNumber(re) {
      const m = re.exec(meta());
      return m ? Number(m[1]) : null;
    }

    function column(anchorSel) {
      const anchor = qs(document, anchorSel);
      return anchor ? anchor.closest(SEL.profileColumn) : null;
    }

    function columnLines(col) {
      if (!col) return [];
      return (col.innerText || '')
        .split('\n')
        .map((line) => line.trim())
        .filter(Boolean);
    }

    // Emoji zijn hier <img class="joypixels" alt="💋">, geen tekens. Gewone
    // textContent laat ze dus volledig vallen — en dan ziet het model geen
    // enkele emoji, terwijl de emoji-regels per account daar juist op sturen.
    // Daarom lopen we de knopen zelf af en zetten we de alt-tekst terug.
    function readText(el) {
      if (!el) return '';
      let out = '';
      const walk = (node) => {
        for (const child of node.childNodes) {
          if (child.nodeType === 3) {
            out += child.textContent;
          } else if (child.nodeType === 1) {
            if (child.tagName === 'IMG') {
              if (child.classList && child.classList.contains('joypixels')) {
                out += child.getAttribute('alt') || '';
              }
            } else {
              walk(child);
            }
          }
        }
      };
      walk(el);
      return out.replace(/\s+/g, ' ').trim();
    }

    // Bij twijfel géén bijlage. Een fout-positief legt full auto stil op elk
    // bericht; een fout-negatief kost alleen deze ene noodrem.
    function isAttachment(img) {
      try {
        return !img.matches(SEL.nonAttachment);
      } catch (e) {
        return false;
      }
    }

    function nickname(col) {
      const lines = columnLines(col);
      if (!lines.length) return null;
      return lines[0].replace(CREDITS_RE, '').trim() || null;
    }

    function buildProfile(col) {
      const profile = emptyProfile();
      if (!col) return profile;

      profile.nickname = nickname(col);

      // De kolom is een lijst van label/waarde-paren op opeenvolgende regels.
      const lines = columnLines(col);
      const field = {};
      for (let i = 1; i < lines.length - 1; i++) {
        field[lines[i]] = lines[i + 1];
      }

      const value = (label) => {
        const v = field[label];
        if (!v) return null;
        const trimmed = String(v).trim();
        return trimmed && trimmed !== '-' ? trimmed : null;
      };
      const number = (label) => {
        const v = value(label);
        if (!v) return null;
        const m = /(\d+)/.exec(v);
        return m ? Number(m[1]) : null;
      };

      profile.name = value('Naam');
      profile.gender = value('Geslacht');
      profile.age = number('Leeftijd');
      profile.birthdate = value('Geb.datum');
      profile.location = value('Woonplaats');
      profile.region = value('Provincie');
      profile.country = value('Land');
      profile.maritalStatus = value('Relatie');
      profile.housing = value('Woonsituatie');
      profile.car = value('Vervoer');
      profile.job = value('Beroep');
      profile.heightLabel = value('Lengte');
      profile.height = number('Lengte');
      profile.bodyType = value('Lichaamsbouw');
      profile.eyeColour = value('Oogkleur');
      profile.hairColour = value('Haarkleur');
      profile.smoker = value('Roken');
      profile.aboutMe = value('Over mij');

      profile.raw = text(col);
      return profile;
    }

    const adapter = {
      id: 'moddies',
      label: 'Moddies',
      matches: ['*://moddies.be/*', '*://*.moddies.be/*'],

      allowsDraftInsert: true,
      allowsEmoji: true,

      // Een concrete ontmoeting voorstellen mag hier niet. Fantaseren wel.
      allowsContactOrDates: false,
      allowsAutoSend: true,

      isChatPage() {
        return safe(() => !!qs(document, SEL.input), false);
      },

      isReady() {
        return safe(() => !!qs(document, SEL.input) && !!qs(document, SEL.messagesList), false);
      },

      // De URL is altijd /doorlaadpagina en verandert dus niet per gesprek.
      // Een bericht-ID kan ook niet: dat verandert bij elk nieuw bericht en
      // zou de trigger elke beurt laten denken dat er een nieuw gesprek is.
      getConversationId() {
        return safe(() => {
          const persona = nickname(column(SEL.personaAnchor));
          const m = META_RE.customer.exec(meta());
          if (m) return `${persona || '?'}#${m[1]}`;
          const customer = nickname(column(SEL.customerAnchor));
          if (persona || customer) return `${persona || '?'}#${customer || '?'}`;
          return null;
        }, null);
      },

      getMessages() {
        return safe(() => {
          const nodes = qsa(document, SEL.messages);
          const messages = [];

          for (const li of nodes) {
            const grid = li.children[0];
            if (!grid) continue;

            // `bg-blue` = ons bericht. `latest-msg` staat op het nieuwste
            // bericht ongeacht wie het stuurde en zegt dus niets over de rol.
            const isOperator = String(grid.className || '').includes('bg-blue');

            const body = qs(li, SEL.messageBody);
            const value = readText(qs(li, SEL.messageText));

            // Een bijlage is een afbeelding in de tekstkolom die geen
            // leesvinkje en geen emoji is. De avatar staat in de kolom ernaast
            // en telt sowieso niet mee.
            const hasImage = !!body && qsa(body, 'img').some(isAttachment);

            if (!value && !hasImage) continue;

            messages.push({
              role: isOperator ? 'operator' : 'customer',
              text: value,
              timestamp: null,
              hasImage,
            });
          }

          // De site zet het nieuwste bovenaan; het contract wil oud -> nieuw.
          return messages.reverse();
        }, []);
      },

      getCustomer() {
        return safe(() => buildProfile(column(SEL.customerAnchor)), emptyProfile());
      },

      getPersona() {
        return safe(() => buildProfile(column(SEL.personaAnchor)), emptyProfile());
      },

      getAttachments() {
        // v2-scope — v1 stuurt altijd attachmentsLoaded: false.
        return safe(() => [], []);
      },

      getContext() {
        return safe(
          () => ({
            conversationId: adapter.getConversationId(),
            platform: 'moddies',
            attachmentsLoaded: false,
            operatorName: text(qs(document, SEL.operatorName)) || null,
            extra: {
              // Hier leunt de lengte-noodrem op. Deze site is de enige van de
              // drie die harde grenzen opgeeft.
              minChars: metaNumber(META_RE.min),
              maxChars: metaNumber(META_RE.max),
              personaNickname: nickname(column(SEL.personaAnchor)),
              customerNickname: nickname(column(SEL.customerAnchor)),
            },
          }),
          null
        );
      },

      // ---- logboek ---------------------------------------------------

      _logbookBlock(target) {
        return qs(
          document,
          target === 'persona' ? SEL.personaLogbookBlock : SEL.logbookBlock
        );
      },

      getLogbook(target) {
        return safe(() => {
          const block = adapter._logbookBlock(target);
          if (!block) return null;

          const select = qs(block, SEL.logbookCategory);
          const categories = select
            ? Array.from(select.options)
                .filter((o) => o.value)
                .map((o) => ({ id: String(o.value), label: text(o) }))
            : [];

          // Bestaande regels staan verspreid over accordeons in dezelfde
          // kolom. Ze zijn te herkennen aan het operator- en tijdvoorvoegsel;
          // dat halen we eraf zodat vergelijken met een nieuw feit werkt.
          // REGRESSION RULE: nooit terugvallen op `document`.
          // Zie docs/06-ROOT-CAUSES.md, RC-2. Paginabreed verzamelen mengt de
          // regels van de persona met die van de klant; die belanden dan in de
          // seen-set van selectEntries en onderdrukken echte nieuwe
          // klantfeiten. Liever geen dedupe-context dan de verkeerde.
          const column = block.closest(SEL.profileColumn);
          const existing = (column ? qsa(column, 'li') : [])
            .map((el) => text(el))
            .filter((t) => LOG_PREFIX_RE.test(t))
            .map((t) => ({ text: t.replace(LOG_PREFIX_RE, '') }))
            .filter((e) => e.text);

          return { categories, existing };
        }, null);
      },

      setLogbookEntry(entry) {
        return safe(() => {
          if (!entry || !entry.categoryId || !entry.text) return false;
          const block = adapter._logbookBlock(entry.target);
          if (!block) return false;

          const select = qs(block, SEL.logbookCategory);
          const field = qs(block, SEL.logbookText);
          if (!select || !field) return false;

          const option = Array.from(select.options).find(
            (o) => String(o.value) === String(entry.categoryId)
          );
          if (!option) return false;

          select.value = option.value;
          select.dispatchEvent(new Event('change', { bubbles: true }));
          return setNativeValue(field, entry.text);
        }, false);
      },

      // Alleen teruggeven, nooit zelf indrukken. De knop heeft de class
      // "ajax", dus opslaan herlaadt de pagina niet.
      getLogbookSubmitButton(target) {
        return safe(() => {
          const block = adapter._logbookBlock(target);
          return block ? qs(block, SEL.logbookSubmit) : null;
        }, null);
      },


      getInputElement() {
        return safe(() => qs(document, SEL.input), null);
      },

      // Alleen teruggeven, nooit zelf indrukken — zie contractregel in
      // docs/02-ADAPTER-CONTRACT.md.
      getSendButton() {
        return safe(() => qs(document, SEL.sendButton), null);
      },

      setDraft(replyText) {
        return safe(() => setNativeValue(adapter.getInputElement(), replyText), false);
      },

      getStatusAnchor() {
        return safe(() => document.body, null);
      },
    };

    return adapter;
  }

  ChatAssistant._factories.push(createModdiesAdapter);
})();
