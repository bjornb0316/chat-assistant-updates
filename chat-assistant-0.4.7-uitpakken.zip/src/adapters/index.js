// Registreert elke geladen adapter-fabriek. Zie docs/02-ADAPTER-CONTRACT.md,
// stap 5 van "Een nieuw platform toevoegen".

window.ChatAssistant = window.ChatAssistant || {};

ChatAssistant.adapters = (ChatAssistant._factories || []).map((factory) => factory());

// ---- welke adapter hoort bij deze pagina, ook zonder gesprek --------------
//
// findAdapter() in content.js vraagt isChatPage(): "staat er nu een gesprek?".
// Dat is precies de verkeerde vraag zodra je iets wilt weten over het platform
// terwijl er géén gesprek is — en dat is nou net wanneer het verversen speelt.
//
// Vandaar deze tweede ingang, op de host. Hij leest het `matches`-veld dat
// elke adapter toch al heeft voor de manifest-patronen, zodat er geen tweede
// lijst met domeinen ontstaat die uit de pas kan gaan lopen.
//
// Bewust simpel: van een patroon als `*://*.chathomebase.com/*` gebruiken we
// alleen het hostgedeelte, en we vergelijken op gelijk-of-subdomein. Padden en
// schema's doen er hier niet toe — de extensie draait sowieso alleen op de
// hosts die in het manifest staan.
(function () {
  function hostOfPattern(pattern) {
    const m = /^[^:]+:\/\/([^/]+)/.exec(String(pattern || ''));
    if (!m) return null;
    return m[1].replace(/^\*\./, '').toLowerCase();
  }

  function hostMatches(pattern, hostname) {
    const host = hostOfPattern(pattern);
    if (!host) return false;
    const kandidaat = String(hostname || '').toLowerCase();
    return kandidaat === host || kandidaat.endsWith('.' + host);
  }

  function adapterForHost(hostname) {
    return (
      ChatAssistant.adapters.find((a) =>
        (a.matches || []).some((p) => hostMatches(p, hostname))
      ) || null
    );
  }

  ChatAssistant.adapterForHost = adapterForHost;
  ChatAssistant.hostMatches = hostMatches;
})();
