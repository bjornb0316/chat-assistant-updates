// Wat de extensie onthoudt van zijn eigen goede berichten, per persona.
// Pure functies over een gewoon object: het lezen en schrijven naar
// chrome.storage gebeurt in background.js, het oordeel valt hier. Zo is het
// te testen zonder browser, net als de andere modules in deze map.
//
// WAAROM DIT BESTAAT
//
// Een klein model volgt instructies matig maar imiteert voorbeelden goed. Dat
// is geen tekortkoming maar de manier waarop het werkt: "schrijf tussen de 200
// en 500 tekens, wissel je opening af, val niet terug op standaardzinnen" is
// abstract, terwijl vijf echte berichten van deze persona alle drie die dingen
// tegelijk laten zien zonder ze te benoemen.
//
// Vandaar dit geheugen. Het kost geen extra API-call: we bewaren wat er toch
// al langskwam.
//
// TWEE DINGEN DIE HET NIET DOET
//
// Het bewaart geen klantberichten. Alleen wat de persona zelf verstuurde —
// dat is onze eigen tekst, en het scheelt een berg gevoelige gegevens op de
// schijf van de operator.
//
// En het bewaart alleen berichten die in ÉÉN poging door alle controles
// kwamen. Een bericht dat pas na twee herkansingen goed was, is precies het
// soort tekst dat we niet willen voorleggen: dan leert het model zijn eigen
// fouten aan.

(function (root) {
  'use strict';

  root.ChatAssistant = root.ChatAssistant || {};

  // Hoeveel we bewaren per persona. Genoeg om stijl over te brengen, weinig
  // genoeg om de prompt niet te laten ontsporen.
  const MAX_EXAMPLES = 8;
  // Openingen zijn kort, dus daar kunnen er meer bij. Hoe langer deze lijst,
  // hoe beter de robot zijn groeten afwisselt.
  const MAX_OPENINGS = 12;
  // Een bericht dat hier ver buiten valt is geen goed voorbeeld van huisstijl.
  const MIN_EXAMPLE_CHARS = 120;
  const MAX_EXAMPLE_CHARS = 900;

  function emptyStore() {
    return { accounts: {} };
  }

  function accountOf(store, key) {
    const s = store && store.accounts ? store : emptyStore();
    const naam = String(key || '').trim();
    if (!naam) return null;
    return s.accounts[naam] || { examples: [], openings: [] };
  }

  // De eerste paar woorden, ontdaan van leestekens. Genoeg om te zien dat twee
  // berichten hetzelfde beginnen, kort genoeg om er twaalf van te bewaren.
  const OPENING_WORDS = 4;

  function openingOf(value) {
    const woorden = String(value == null ? '' : value)
      .trim()
      .replace(/[^\p{L}\p{N}\s']/gu, ' ')
      .split(/\s+/)
      .filter(Boolean)
      .slice(0, OPENING_WORDS);
    return woorden.length ? woorden.join(' ').toLowerCase() : null;
  }

  // Geeft een nieuwe store terug; muteert de oude niet. Dat maakt het
  // testbaar en voorkomt dat een half gelukte opslag een half bijgewerkt
  // object achterlaat.
  //
  // entry: { accountKey, text, cleanFirstTry }
  function remember(store, entry) {
    const s = store && store.accounts ? store : emptyStore();
    const e = entry || {};
    const naam = String(e.accountKey || '').trim();
    const tekst = String(e.text == null ? '' : e.text).trim();

    if (!naam || !tekst) return s;

    const huidig = s.accounts[naam] || { examples: [], openings: [] };
    const openings = huidig.openings.slice();
    const examples = huidig.examples.slice();

    // De opening onthouden we altijd, ook bij een bericht dat herkansingen
    // nodig had: het punt is dát hij hem gebruikt heeft, niet of hij goed was.
    const opening = openingOf(tekst);
    if (opening) {
      const zonderDubbel = openings.filter((o) => o !== opening);
      zonderDubbel.push(opening);
      openings.length = 0;
      openings.push(...zonderDubbel.slice(-MAX_OPENINGS));
    }

    // Voorbeeld worden is strenger: alleen in één keer goed, en van een
    // fatsoenlijke lengte.
    const bruikbaar =
      e.cleanFirstTry === true &&
      tekst.length >= MIN_EXAMPLE_CHARS &&
      tekst.length <= MAX_EXAMPLE_CHARS;

    if (bruikbaar && examples.indexOf(tekst) === -1) {
      examples.push(tekst);
      while (examples.length > MAX_EXAMPLES) examples.shift();
    }

    return {
      accounts: Object.assign({}, s.accounts, {
        [naam]: { examples, openings },
      }),
    };
  }

  // De nieuwste eerst: die passen het best bij hoe er nú geschreven wordt.
  function examplesFor(store, key, max) {
    const acc = accountOf(store, key);
    if (!acc) return [];
    const hoeveel = typeof max === 'number' ? max : MAX_EXAMPLES;
    return acc.examples.slice(-hoeveel).reverse();
  }

  function openingsFor(store, key, max) {
    const acc = accountOf(store, key);
    if (!acc) return [];
    const hoeveel = typeof max === 'number' ? max : MAX_OPENINGS;
    return acc.openings.slice(-hoeveel).reverse();
  }

  // Om te kunnen zien of het geheugen zich vult zonder de hele store te
  // hoeven uitprinten.
  function summary(store) {
    const s = store && store.accounts ? store : emptyStore();
    return Object.keys(s.accounts).map((naam) => ({
      account: naam,
      examples: s.accounts[naam].examples.length,
      openings: s.accounts[naam].openings.length,
    }));
  }

  root.ChatAssistant.memory = {
    emptyStore,
    remember,
    examplesFor,
    openingsFor,
    openingOf,
    summary,
    MAX_EXAMPLES,
    MAX_OPENINGS,
  };
})(typeof globalThis !== 'undefined' ? globalThis : self);
