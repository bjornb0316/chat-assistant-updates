// Haalt de klantconfiguratie op bij de backend, bewaart de laatst geldige
// lokaal, en houdt de extensie draaiend als die backend er niet is.
//
// DE HOOFDREGEL: DE BACKEND MAG NOOIT EEN SINGLE POINT OF FAILURE ZIJN.
//
// Een operator werkt in een wachtrij. Valt de config-API weg, dan hoort daar
// hooguit een regel in de console bij te horen — geen lege statusbalk, geen
// gestopte extensie, geen bericht dat niet verstuurd wordt. Vandaar de
// volgorde: verse config als het kan, opgeslagen config als het even niet
// kan, ingebouwde standaard als er nog nooit iets binnen is gekomen.
//
// WAT HIER NIET GEBEURT
//
// Er wordt geen code opgehaald en niets geëvalueerd. Chrome Manifest V3
// verbiedt remote code, en dat is hier ook niet nodig: de logica zit in de
// modules, de backend stuurt alleen getallen, teksten en schakelaars. Wat
// binnenkomt gaat eerst door src/config/schema.js voordat het iets doet.

(function (root) {
  'use strict';

  root.ChatAssistant = root.ChatAssistant || {};

  const STORAGE_KEY = 'remoteConfig';
  const META_KEY = 'remoteConfigMeta';
  const INSTALL_KEY = 'installationId';
  const ENDPOINT_KEY = 'configEndpoint';
  const CUSTOMER_KEY = 'customerId';
  const LICENSE_KEY = 'licenseKey';

  // Niet bij elke toetsaanslag opnieuw ophalen. Een kwartier is kort genoeg om
  // een wijziging dezelfde dienst nog te laten landen, en lang genoeg om niet
  // bij elk bericht het net op te gaan.
  const CACHE_TTL_MS = 15 * 60 * 1000;

  // Een operator die op een dood adres wacht is erger dan een operator zonder
  // verse config. Acht seconden en dan door met wat we hebben.
  const FETCH_TIMEOUT_MS = 8000;

  function log(...args) {
    console.log('[ChatAssistant][config]', ...args);
  }
  function warn(...args) {
    console.warn('[ChatAssistant][config]', ...args);
  }

  // ---- identiteit van deze installatie ------------------------------------
  //
  // Eén id per installatie, lokaal gegenereerd en daarna vast. Hiermee kan de
  // backend per installatie iets anders teruggeven zonder dat wij een account
  // of een inlog nodig hebben.
  //
  // Dit is nadrukkelijk geen geheim en ook geen bewijs van identiteit. Wie de
  // extensie uitpakt kan hem lezen. Moet de backend echt weten wie er belt,
  // dan hoort daar een licenseKey bij die de klant zelf invult, en de
  // uiteindelijke controle hoort aan de serverkant te staan.
  function newId() {
    if (root.crypto && typeof root.crypto.randomUUID === 'function') {
      return root.crypto.randomUUID();
    }
    const bytes = new Uint8Array(16);
    (root.crypto || {}).getRandomValues
      ? root.crypto.getRandomValues(bytes)
      : bytes.forEach((_, i) => (bytes[i] = Math.floor(Math.random() * 256)));
    return Array.from(bytes, (b) => b.toString(16).padStart(2, '0')).join('');
  }

  async function installationId() {
    const opgeslagen = await chrome.storage.local.get([INSTALL_KEY]);
    if (opgeslagen[INSTALL_KEY]) return opgeslagen[INSTALL_KEY];
    const id = newId();
    await chrome.storage.local.set({ [INSTALL_KEY]: id });
    log('nieuwe installatie-id aangemaakt');
    return id;
  }

  // ---- opslag --------------------------------------------------------------

  async function cached() {
    const opgeslagen = await chrome.storage.local.get([STORAGE_KEY, META_KEY]);
    return {
      config: opgeslagen[STORAGE_KEY] || null,
      meta: opgeslagen[META_KEY] || { fetchedAt: 0, configVersion: null },
    };
  }

  // Wat er nú geldt, zonder het net op te gaan. Dit is wat de rest van de
  // extensie aanroept; het ophalen gebeurt op de achtergrond.
  async function current() {
    const { config } = await cached();
    return config || root.ChatAssistant.configDefaults;
  }

  // ---- ophalen -------------------------------------------------------------

  function extensionVersion() {
    try {
      return chrome.runtime.getManifest().version;
    } catch (e) {
      return '0.0.0';
    }
  }

  async function endpoint() {
    const opgeslagen = await chrome.storage.local.get([ENDPOINT_KEY]);
    return opgeslagen[ENDPOINT_KEY] || '';
  }

  async function fetchRemote(url, identiteit) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), FETCH_TIMEOUT_MS);

    try {
      const doel = new URL(url);
      // Identificatie in de query, niet in het pad: dan hoeft de backend geen
      // routes per klant te kennen.
      doel.searchParams.set('installationId', identiteit.installationId);
      if (identiteit.customerId) doel.searchParams.set('customerId', identiteit.customerId);
      doel.searchParams.set('extensionVersion', identiteit.extensionVersion);

      const headers = { accept: 'application/json' };
      // De licentiesleutel gaat in een header en niet in de URL: query's
      // belanden in serverlogs en in de geschiedenis van een proxy.
      if (identiteit.licenseKey) headers['x-license-key'] = identiteit.licenseKey;

      const res = await fetch(doel.toString(), {
        method: 'GET',
        headers,
        signal: controller.signal,
        cache: 'no-store',
      });

      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      return await res.json();
    } finally {
      clearTimeout(timer);
    }
  }

  // force: sla de cache over. Voor een knop in de popup, of na het wijzigen
  // van het adres.
  //
  // Geeft { status, config } terug. status is een van:
  //   'updated'        — nieuwe config binnen en toegepast
  //   'unchanged'      — backend gaf dezelfde configVersion
  //   'cached'         — nog vers genoeg, niet opgehaald
  //   'offline'        — backend onbereikbaar, opgeslagen config gebruikt
  //   'invalid'        — antwoord klopte niet, opgeslagen config gebruikt
  //   'incompatible'   — extensie te oud voor deze config
  //   'not-configured' — er is geen adres ingesteld
  async function refresh(options) {
    const opts = options || {};
    const url = opts.endpoint || (await endpoint());

    if (!url) {
      return { status: 'not-configured', config: await current() };
    }

    const { config: opgeslagenConfig, meta } = await cached();
    const vers = Date.now() - (meta.fetchedAt || 0) < CACHE_TTL_MS;

    if (!opts.force && vers && opgeslagenConfig) {
      log('cached config gebruikt (nog vers)');
      return { status: 'cached', config: opgeslagenConfig };
    }

    const identiteit = {
      installationId: await installationId(),
      customerId: (await chrome.storage.local.get([CUSTOMER_KEY]))[CUSTOMER_KEY] || null,
      licenseKey: (await chrome.storage.local.get([LICENSE_KEY]))[LICENSE_KEY] || null,
      extensionVersion: extensionVersion(),
    };

    log('ophalen gestart —', url);

    let ruw;
    try {
      ruw = await fetchRemote(url, identiteit);
    } catch (e) {
      // Onbereikbaar is geen fout van de operator en mag niets stilleggen.
      warn('backend onbereikbaar:', (e && e.message) || e, '— opgeslagen config blijft gelden');
      return { status: 'offline', config: opgeslagenConfig || root.ChatAssistant.configDefaults };
    }

    const { config, problems } = root.ChatAssistant.configSchema.validate(
      ruw,
      root.ChatAssistant.configDefaults
    );

    if (problems.length) {
      warn('config bevatte onbruikbare velden:', problems.join(' | '));
    }

    // Te oude extensie: niet toepassen. Een config die op nieuwere velden
    // rekent half uitvoeren geeft gedrag dat niemand heeft ontworpen.
    if (
      !root.ChatAssistant.configSchema.meetsMinimumVersion(
        identiteit.extensionVersion,
        config.minimumExtensionVersion
      )
    ) {
      warn(
        `extensie ${identiteit.extensionVersion} is ouder dan de vereiste ` +
          `${config.minimumExtensionVersion} — config niet toegepast, ` +
          'werk de extensie bij'
      );
      return {
        status: 'incompatible',
        config: opgeslagenConfig || root.ChatAssistant.configDefaults,
        required: config.minimumExtensionVersion,
        installed: identiteit.extensionVersion,
      };
    }

    // Een antwoord zonder enige herkenbare configVersion is meestal geen
    // config maar een foutpagina of een inlogscherm van een proxy.
    if (!Number.isFinite(Number(ruw && ruw.configVersion))) {
      warn('antwoord bevatte geen configVersion — genegeerd');
      return { status: 'invalid', config: opgeslagenConfig || root.ChatAssistant.configDefaults };
    }

    const zelfde = meta.configVersion === config.configVersion;
    await chrome.storage.local.set({
      [STORAGE_KEY]: config,
      [META_KEY]: { fetchedAt: Date.now(), configVersion: config.configVersion },
    });

    if (zelfde) {
      log('config ongewijzigd (versie', config.configVersion + ')');
      return { status: 'unchanged', config };
    }

    log('config bijgewerkt naar versie', config.configVersion);
    return { status: 'updated', config };
  }

  root.ChatAssistant.configService = {
    current,
    refresh,
    installationId,
    STORAGE_KEY,
    META_KEY,
    ENDPOINT_KEY,
    CUSTOMER_KEY,
    LICENSE_KEY,
    INSTALL_KEY,
    CACHE_TTL_MS,
  };
})(typeof globalThis !== 'undefined' ? globalThis : self);
