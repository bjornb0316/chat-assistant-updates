// Huisregels van het bureau: wat er niet in een bericht mag staan gegeven de
// rest van het gesprek. Puur tekst en context in, oordeel uit — geen DOM,
// geen opslag, geen netwerk. Draait daarom zowel in het content script als in
// de service worker (vandaar globalThis in plaats van window).
//
// WAAROM EEN APART BESTAND NAAST blocklist.js
//
// blocklist.js beantwoordt "mag dit woord?" — een oordeel over de tekst
// alleen. Dit bestand beantwoordt "mag dit bericht, hier, nu?" en heeft
// daarvoor de klantnaam en de eerdere berichten nodig. Dat is een andere
// vraag met een andere handtekening; samenvoegen zou betekenen dat elke
// aanroep van check() ineens context moet meekrijgen die hij niet gebruikt.
//
// WAAROM DIT CODE IS EN GEEN PROMPT-REGEL
//
// Deze regels stonden eerder alleen in de systeem-prompt. Claude Opus hield
// zich er redelijk aan, Haiku 4.5 niet — dat is geen prompt-probleem maar een
// capaciteitsprobleem: vijftien regels tegelijk onthouden terwijl je schrijft
// is te veel gevraagd van een klein model. Alles wat de code kan nakijken
// hoort dus niet alleen in de prompt te blijven hangen. De prompt vraagt het
// nog steeds (dat scheelt herkansingen), maar de code is de garantie.

(function (root) {
  'use strict';

  root.ChatAssistant = root.ChatAssistant || {};

  // Zonder blocklist.js kan dit bestand niets: het hergebruikt bewust
  // dezelfde zinsherkenning, zodat er geen tweede mechanisme is dat apart
  // stuk kan gaan. Laadvolgorde is dus blocklist.js vóór style.js.
  const blocklist = root.ChatAssistant.blocklist;

  const WORD_CHAR = '[\\p{L}\\p{N}_]';

  function escapeRegExp(s) {
    return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  }

  // ---- naam van de klant ---------------------------------------------------
  //
  // "Oh Roger, wat goed van je" — de site rekent dat aan als fout en de
  // operator wordt erop aangesproken. Dit is de goedkoopste regel om
  // waterdicht te maken, want we kennen de naam uit het klantprofiel: geen
  // inschatting, geen model, gewoon zoeken.
  //
  // Namen korter dan drie letters slaan we over. "Jo" of "Ad" zit in te veel
  // gewone woorden, en een vals alarm kost een herkansing.
  const MIN_NAME_LENGTH = 3;

  function nameHits(value, names) {
    const subject = String(value == null ? '' : value);
    const out = [];
    const seen = new Set();

    (names || []).forEach((raw) => {
      const naam = String(raw == null ? '' : raw).trim();
      if (naam.length < MIN_NAME_LENGTH) return;

      const key = naam.toLowerCase();
      if (seen.has(key)) return;
      seen.add(key);

      let re;
      try {
        re = new RegExp(
          `(?<!${WORD_CHAR})${escapeRegExp(naam)}(?!${WORD_CHAR})`,
          'iu'
        );
      } catch (e) {
        // Een naam met rare tekens mag de hele controle niet laten klappen.
        console.warn('[ChatAssistant] naam overgeslagen:', naam, e);
        return;
      }
      if (re.test(subject)) out.push(naam);
    });

    return out;
  }

  // ---- openingsclichés -----------------------------------------------------
  //
  // Deze zinnen kwamen in vrijwel elk eerste bericht terug. Dat valt op bij
  // klanten die meerdere profielen aanschrijven, en het is precies het soort
  // zin waar een model op terugvalt als het niets specifieks te zeggen heeft.
  // De oplossing is tweeledig: deze zinnen verbieden, en in de prompt om een
  // vraag uit het klantprofiel vragen — anders komt er gewoon een nieuw
  // cliché voor in de plaats.
  const CLICHE_PHRASES = [
    'beter leren kennen',
    'elkaar eerst wat beter',
    'dat maakt het juist spannend',
    'dat maakt het juist spannender',
    'dit is toch spannender',
    'hoe zou je me het liefst hebben',
    'hoe je me het liefst hebt',
    'vertel eens hoe je me',
    'ik ben hier voor het spel',
    'laten we genieten van wat we nu hebben',
    'je weet hoe het gaat',
    'ik hou van je directheid',
  ];

  // ---- beloftes die we niet waar kunnen maken ------------------------------
  //
  // Er zijn drie tot vijf foto's per profiel en meer komen er niet. Een
  // toezegging dat er iets aankomt is dus altijd een leugen, en de klant
  // blijft erop wachten. Ook "stuur ik straks" valt hieronder: straks komt
  // nooit.
  const PROMISE_PHRASES = [
    'maak ik een foto',
    'maak ik er een',
    'ik maak een foto',
    'ik maak wel een',
    'foto voor je maken',
    'nieuwe foto',
    'nieuwe fotos',
    'komt eraan',
    'komt er aan',
    'stuur ik je later',
    'stuur ik straks',
    'stuur ik zo',
    'later meer',
    'volgende keer stuur ik',
  ];

  // ---- toezeggingen bij een afspraakverzoek --------------------------------
  //
  // "Oké geen probleem, laat me even in mijn agenda kijken" is geen afwijzing
  // en geen toezegging — en juist daarom fout: de klant blijft hangen op een
  // ja die nooit komt. De regel is dat er altijd een omweg is (het is druk op
  // het werk), nooit een uitstel.
  //
  // Dit staat los van de afspraak-detectie in blocklist.js, omdat het ook
  // verboden blijft op het moment dat afspreken zelf wel mag: dan hoort er
  // een concreet voorstel te staan, geen "ik kijk even".
  const HEDGE_PHRASES = [
    'mijn agenda',
    'in de agenda',
    'agenda kijken',
    'agenda kijk',
    'laat me kijken',
    'laat me even kijken',
    'ik kijk even',
    'ik kijk wel even',
    'ik kijk wat ik kan doen',
    'ik ga mijn best doen',
    'ik doe mijn best',
    'ik zal mijn best doen',
    'kijken of het lukt',
    'misschien lukt het',
  ];

  // ---- groeten -------------------------------------------------------------
  //
  // Elk bericht met "Goedemorgen" beginnen valt op. De lijst hieronder dient
  // niet om te verbieden maar om te herkennen: welke groet staat er, en stond
  // die er de vorige keer ook? Alleen herhaling is fout.
  //
  // Volgorde is van lang naar kort, zodat "hey knappert" wint van "hey".
  const GREETINGS = [
    'goedemorgen',
    'goedemiddag',
    'goedenavond',
    'goeiemorgen',
    'goeiemiddag',
    'hey knappert',
    'hey kanjer',
    'hey lekkerding',
    'hey lieve man',
    'hey lieverd',
    'hey jij',
    'dag jij',
    'hallo',
    'hoi',
    'hey',
    'hai',
    'haai',
    'dag',
  ];

  // Alleen het begin telt: "dag" midden in een zin ("een lekkere dag gehad?")
  // is geen groet.
  const GREETING_WINDOW = 24;

  function greetingOf(value) {
    const start = String(value == null ? '' : value)
      .trim()
      .slice(0, GREETING_WINDOW)
      .toLowerCase();

    for (const groet of GREETINGS) {
      if (start.startsWith(groet)) return groet;
    }
    return null;
  }

  // previous: de eerdere berichten van de operator in dit gesprek. Standaard
  // tellen de laatste drie mee — twee keer "hoi" in een lang gesprek is niet
  // erg, twee keer vlak achter elkaar wel.
  const GREETING_LOOKBACK = 3;

  function repeatsGreeting(value, previous, lookback) {
    const groet = greetingOf(value);
    if (!groet) return false;

    const hoeveel = typeof lookback === 'number' ? lookback : GREETING_LOOKBACK;
    const eerder = (previous || []).slice(-hoeveel);
    return eerder.some((tekst) => greetingOf(tekst) === groet);
  }

  // ---- samengesteld oordeel ------------------------------------------------
  //
  // Geeft een lijst issues terug in plaats van één boolean, zodat de
  // herkansing per overtreding kan uitleggen wat er mis was. Een herkansing
  // zonder die uitleg is blind gokken, en dat is precies wat een klein model
  // twee extra calls kost.
  //
  // context: { customerNames: [], previousOperatorTexts: [] }
  // Welke lijst geldt: die uit de configuratie als hij is meegegeven, anders
  // de ingebouwde. Een lege array is een geldige keuze en betekent "deze regel
  // staat uit" — dat is iets anders dan `null` of ontbreken, wat "gebruik de
  // ingebouwde lijst" betekent. Zie src/config/schema.js.
  function lijst(uitConfig, ingebouwd) {
    return Array.isArray(uitConfig) ? uitConfig : ingebouwd;
  }

  function check(value, context) {
    const ctx = context || {};
    const issues = [];

    const namen = nameHits(value, ctx.customerNames);
    if (namen.length) issues.push({ type: 'naam', items: namen });

    const cliches = blocklist.check(value, lijst(ctx.cliches, CLICHE_PHRASES)).hits;
    if (cliches.length) issues.push({ type: 'cliche', items: cliches });

    const beloftes = blocklist.check(value, lijst(ctx.promises, PROMISE_PHRASES)).hits;
    if (beloftes.length) issues.push({ type: 'belofte', items: beloftes });

    const toezeggingen = blocklist.check(value, lijst(ctx.hedges, HEDGE_PHRASES)).hits;
    if (toezeggingen.length) {
      issues.push({ type: 'toezegging', items: toezeggingen });
    }

    if (repeatsGreeting(value, ctx.previousOperatorTexts)) {
      issues.push({ type: 'groet', items: [greetingOf(value)] });
    }

    return { ok: issues.length === 0, issues };
  }

  root.ChatAssistant.style = {
    check,
    nameHits,
    greetingOf,
    repeatsGreeting,
    CLICHE_PHRASES,
    PROMISE_PHRASES,
    HEDGE_PHRASES,
    GREETINGS,
  };
})(typeof globalThis !== 'undefined' ? globalThis : self);
