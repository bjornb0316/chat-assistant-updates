// Hoe lang het antwoord hoort te worden, gegeven wat de klant schreef.
//
// Puur getallen in, getallen uit. Geen DOM, geen opslag, geen netwerk.
//
// WAAROM DIT BESTAAT
//
// De grenzen van het platform zijn vast: OperatorPanel eist minstens 171
// tekens (gemeten 18-08-2026) en het bureau maakt daar 200 van; 500 is de
// bovengrens. Die grenzen gingen ongewijzigd de prompt in, bij élk bericht.
//
// Het gevolg is precies wat er gemeld is: berichten die te lang zijn. Een
// model dat "schrijf tussen de 200 en 500 tekens" te horen krijgt, mikt op het
// midden — ook als de klant "haha ja precies" stuurde. Dan krijgt hij drie
// zinnen terug op vier woorden, en dat leest als een formulier.
//
// Een mens spiegelt. Kort bericht, kort antwoord. Lang bericht, langer
// antwoord — maar niet evenredig lang, want dan ontstaat er een wedloop.
//
// WAT DIT NIET KAN
//
// De ondergrens van het platform blijft staan. Op OperatorPanel is een
// antwoord van vier woorden onmogelijk: de site weigert het. Het kortste wat
// daar kan is rond de 200 tekens, en dat is een eigenschap van die site en
// niet iets wat hier op te lossen valt.

(function (root) {
  'use strict';

  root.ChatAssistant = root.ChatAssistant || {};

  // Hoeveel langer dan het klantbericht het antwoord mag worden. Iets meer dan
  // één op één: een antwoord dat ingaat op wat er staat heeft nu eenmaal een
  // paar woorden meer nodig dan de vraag.
  const SPIEGEL = 1.4;

  // Vaste ruimte bovenop, zodat een kort bericht niet leidt tot een antwoord
  // van vijf tekens op een platform dat dat wél toestaat.
  const BASIS = 50;

  // Het venster moet werkbaar blijven. Ligt het plafond te dicht op de
  // ondergrens, dan is er geen enkele formulering die past en gaat elke poging
  // op de lengte af.
  const SPELING = 40;

  // Waar een platform zelf geen bovengrens meldt. Niet oneindig: een bericht
  // van tweeduizend tekens is op geen van deze sites normaal.
  const STANDAARD_MAX = 500;

  // Waar we op mikken binnen het venster. Niet tegen het plafond aan, want dan
  // is er geen marge voor een zin die net iets uitloopt.
  const MIK = 0.8;

  function clamp(waarde, onder, boven) {
    return Math.max(onder, Math.min(boven, waarde));
  }

  // customerText: het laatste bericht van de klant, waar dit antwoord op slaat.
  // limits: { minChars, maxChars } zoals het platform ze meldt.
  //
  // Geeft terug: dezelfde ondergrens, een BIJGESTELDE bovengrens, en een
  // richtlengte om in de prompt te zetten.
  function targetFor(customerText, limits) {
    const lim = limits || {};
    const platformMin = typeof lim.minChars === 'number' ? lim.minChars : 0;
    const platformMax =
      typeof lim.maxChars === 'number' ? lim.maxChars : STANDAARD_MAX;

    const klant = String(customerText == null ? '' : customerText).trim().length;

    // Wat een mens ongeveer terug zou schrijven.
    const gewenst = Math.round(klant * SPIEGEL) + BASIS;

    // Binnen wat het platform toestaat, en met genoeg ruimte om te schrijven.
    const plafond = clamp(gewenst, Math.min(platformMin + SPELING, platformMax), platformMax);

    const target = clamp(Math.round(plafond * MIK), platformMin, plafond);

    return {
      minChars: platformMin,
      maxChars: plafond,
      target,
      // Voor de diagnostiek: waar kwam dit vandaan?
      customerChars: klant,
      platformMax,
      // Is de bovengrens werkelijk bijgesteld, of raakte hij het plafond van
      // het platform? Alleen in het eerste geval valt er iets te melden.
      narrowed: plafond < platformMax,
    };
  }

  // De zin die in de systeem-prompt komt. Hier en niet in background.js, zodat
  // de regel en de berekening bij elkaar staan.
  function promptRule(plan) {
    if (!plan) return null;
    const delen = [];

    if (plan.minChars > 0) {
      delen.push(
        `Lengte: schrijf tussen de ${plan.minChars} en ${plan.maxChars} tekens. ` +
          'Dit is een harde eis van het platform — een bericht dat er niet aan ' +
          'voldoet wordt geweigerd.'
      );
    } else {
      delen.push(`Lengte: schrijf hoogstens ${plan.maxChars} tekens.`);
    }

    delen.push(
      `Mik op ongeveer ${plan.target} tekens. De klant schreef ` +
        `${plan.customerChars} tekens, en een mens spiegelt dat: op een kort ` +
        'bericht antwoord je kort, op een lang bericht wat uitgebreider. Schrijf ' +
        'nooit drie zinnen terug op vier woorden — dat leest als een formulier.'
    );

    if (plan.minChars > 0 && plan.customerChars > 0 && plan.customerChars < plan.minChars) {
      // Eerlijk zijn tegen het model in plaats van het een onmogelijke opdracht
      // geven. Zonder deze zin probeert het te spiegelen en valt het onder de
      // ondergrens, wat een herkansing kost.
      delen.push(
        `Zijn bericht is korter dan wat dit platform toestaat. Blijf dus bij de ` +
          `${plan.minChars} tekens, maar houd het bij één gedachte — niet drie ` +
          'onderwerpen aansnijden om de lengte vol te maken.'
      );
    }

    return delen.join(' ');
  }

  root.ChatAssistant.length = {
    targetFor,
    promptRule,
    SPIEGEL,
    BASIS,
    SPELING,
    MIK,
    STANDAARD_MAX,
  };
})(typeof globalThis !== 'undefined' ? globalThis : self);
