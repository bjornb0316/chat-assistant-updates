// Gedeelde DOM-helpers. Elke adapter gebruikt deze — niet kopiëren, hergebruiken.
// Zie docs/02-ADAPTER-CONTRACT.md, regel 3 en 4.

window.ChatAssistant = window.ChatAssistant || {};

ChatAssistant.dom = {
  // React/Vue negeren element.value = "...". Dit gaat via de native setter,
  // zodat de framework-state ook echt bijgewerkt wordt.
  setNativeValue(el, value) {
    if (!el) return false;
    try {
      const proto =
        el.tagName === 'TEXTAREA'
          ? window.HTMLTextAreaElement.prototype
          : window.HTMLInputElement.prototype;
      const setter = Object.getOwnPropertyDescriptor(proto, 'value')?.set;
      if (setter) {
        setter.call(el, value);
      } else {
        el.value = value;
      }
      el.dispatchEvent(new Event('input', { bubbles: true }));
      el.dispatchEvent(new Event('change', { bubbles: true }));

      // Niet elke site luistert naar `input`. OperatorPanel telt zijn tekens
      // op een toetsgebeurtenis, en laat de verzendknop uitgeschakeld zolang
      // die telling niet is bijgewerkt — je moest dan zelf een spatie typen
      // om hem wakker te maken. We sturen daarom ook keydown en keyup.
      //
      // Dit omzeilt geen controle: de tekst voldoet gewoon aan de eisen van
      // de site, alleen was de teller nog niet bijgewerkt. Weigert een site
      // ingevoegde tekst bewust, dan hoort dat in de adapter met
      // allowsDraftInsert: false — niet hier.
      for (const type of ['keydown', 'keyup']) {
        try {
          el.dispatchEvent(
            new KeyboardEvent(type, { bubbles: true, key: 'Unidentified' })
          );
        } catch (err) {
          // Oudere browsers zonder KeyboardEvent-constructor: niet erg.
        }
      }
      return true;
    } catch (e) {
      console.warn('[ChatAssistant] setNativeValue mislukt', e);
      return false;
    }
  },

  text(el) {
    return el ? (el.textContent || '').replace(/\s+/g, ' ').trim() : '';
  },

  qs(root, sel) {
    try {
      return (root || document).querySelector(sel);
    } catch (e) {
      return null;
    }
  },

  qsa(root, sel) {
    try {
      return Array.from((root || document).querySelectorAll(sel));
    } catch (e) {
      return [];
    }
  },

  // Contract-regel: elke lees-functie geeft bij een fout een lege waarde terug,
  // nooit een gegooide exception. Adapters wrappen hun functies hiermee.
  safe(fn, fallback) {
    try {
      return fn();
    } catch (e) {
      console.warn('[ChatAssistant]', e);
      return fallback;
    }
  },

  emptyProfile() {
    return {
      nickname: null,
      name: null,
      age: null,
      gender: null,
      country: null,
      region: null,
      location: null,
      eyeColour: null,
      hairColour: null,
      height: null,
      heightLabel: null,
      weight: null,
      bodyType: null,
      smoker: null,
      maritalStatus: null,
      sexualPreference: null,
      job: null,
      housing: null,
      car: null,
      aboutMe: null,
      birthdate: null,
      timezone: null,
      hasPhoto: false,
      avatarUrl: null,
      raw: '',
    };
  },
};
