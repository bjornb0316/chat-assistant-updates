// Bepaalt of er automatisch verstuurd mag worden, en telt af tot het zover is.
// Bewust zonder DOM, opslag, netwerk of echte timers — daardoor los te testen,
// net als blocklist.js en trigger.js.
//
// De verantwoordelijkheid is smal: deze module beslist en telt. Hij verstuurt
// niet zelf; dat blijft op precies één plek in content.js.

// globalThis in plaats van window: dit bestand wordt door zowel het content
// script als de service worker geladen, en in een service worker bestaat
// `window` niet. Zelfde reden als bij blocklist.js.
globalThis.ChatAssistant = globalThis.ChatAssistant || {};

(function () {
  'use strict';

  const MODES = ['manual', 'draft', 'full'];
  const DEFAULT_MODE = 'draft';
  const COUNTDOWN_SECONDS = 12;

  function normalise(mode) {
    return MODES.indexOf(mode) === -1 ? null : mode;
  }

  // Drie lagen, van licht naar zwaar: accountinstelling, vensteroverride, en
  // als plafond wat het platform toestaat. Het plafond wint altijd — daarom
  // staat het als laatste.
  function effectiveMode(accountMode, sessionOverride, allowsAutoSend) {
    const chosen = normalise(sessionOverride) || normalise(accountMode) || DEFAULT_MODE;
    if (chosen === 'full' && allowsAutoSend !== true) return 'draft';
    return chosen;
  }

  // Eén definitie van "past dit binnen de grenzen", gedeeld door de noodrem
  // hieronder en door de herkansingslus in background.js. Zonder die deling
  // zou het model op een andere regel afgerekend worden dan het meekrijgt.
  // Ontbrekende grens = geen overtreding.
  function checkLength(reply, limits) {
    const value = String(reply || '').trim();
    const length = value.length;
    const lim = limits || {};
    const minChars = typeof lim.minChars === 'number' ? lim.minChars : null;
    const maxChars = typeof lim.maxChars === 'number' ? lim.maxChars : null;

    if (minChars !== null && length < minChars) {
      return { ok: false, reason: 'kort', length, minChars, maxChars };
    }
    if (maxChars !== null && length > maxChars) {
      return { ok: false, reason: 'lang', length, minChars, maxChars };
    }
    return { ok: true, length, minChars, maxChars };
  }

  // De noodrem. Vier gronden, in vaste volgorde: de zwaarste eerst, zodat de
  // melding de meest fundamentele reden noemt en niet een toevallige tweede.
  function canAutoSend(options) {
    const opts = options || {};
    const adapter = opts.adapter;
    const extra = (opts.context && opts.context.extra) || {};
    const messages = opts.messages || [];
    const blocked = opts.blocked || [];
    const reply = String(opts.reply || '');

    if (!adapter || adapter.allowsAutoSend !== true) {
      return { ok: false, reason: 'platform' };
    }

    if (blocked.length) {
      return { ok: false, reason: 'verboden', detail: { blocked } };
    }

    const lengthResult = checkLength(reply, extra);
    if (!lengthResult.ok) {
      return { ok: false, reason: 'lengte', detail: lengthResult };
    }

    // Alleen het láátste bericht telt: een foto van tien beurten geleden is
    // allang beantwoord. Het model ziet bijlagen niet (v2-scope), dus een
    // antwoord op een verse foto is blind gegokt.
    const last = messages.length ? messages[messages.length - 1] : null;
    if (last && last.role === 'customer' && last.hasImage) {
      return { ok: false, reason: 'foto' };
    }

    // Een afspraakvoorstel is niet mechanisch te verwijderen zoals een emoji;
    // het zit in de betekenis van de zin. Dus niet versturen, en jij kijkt.
    if (opts.dateOrContact) {
      return { ok: false, reason: 'afspraak' };
    }

    return { ok: true };
  }

  // De timerfuncties zijn injecteerbaar zodat de test niet hoeft te wachten.
  function createCountdown(options) {
    const opts = options || {};
    const seconds = opts.seconds || COUNTDOWN_SECONDS;
    const onTick = opts.onTick || function () {};
    const onFire = opts.onFire || function () {};
    const timer = opts.timer || {
      set: (fn, ms) => setInterval(fn, ms),
      clear: (id) => clearInterval(id),
    };

    let left = seconds;
    let id = null;
    let done = false;

    function stop() {
      if (id !== null) {
        timer.clear(id);
        id = null;
      }
    }

    return {
      start() {
        if (id !== null || done) return;
        onTick(left);
        id = timer.set(function () {
          left -= 1;
          if (left > 0) {
            onTick(left);
            return;
          }
          done = true;
          stop();
          onTick(0);
          onFire();
        }, 1000);
      },

      // Geeft terug of er daadwerkelijk iets is tegengehouden. Na het vuren is
      // dat false — er valt dan niets meer af te breken, en de statusregel moet
      // niet "gestopt" gaan zeggen over een bericht dat al weg is.
      cancel() {
        if (done) return false;
        done = true;
        stop();
        return true;
      },

      secondsLeft() {
        return left;
      },
    };
  }

  ChatAssistant.autosend = {
    effectiveMode,
    checkLength,
    canAutoSend,
    createCountdown,
    MODES,
    DEFAULT_MODE,
    COUNTDOWN_SECONDS,
  };
})();
